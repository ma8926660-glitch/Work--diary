# My Work Diary – Native Android Application (Kotlin & Jetpack Compose)

This is the production-ready native Android project for **My Work Diary** (`com.myworkdiary.app`), crafted with modern Kotlin, Jetpack Compose, Material Design 3, Room SQLite, and bilingual localization (English default & हिन्दी Hindi).

## What Was Updated
1. **Language Fix (Default English for Owners)**:
   - "Owner-wise Payments", "Add Payment", "Add Owner", "Total Received", "Total Owners", "Search by owner name, code or note...", "Code not found! Please check code or add owner."
   - All owner and payment screens are now in clean, professional English by default.

2. **Language Selector & Full Localization (English & हिन्दी)**:
   - All strings throughout the entire app (Home, Daily Diary, Labour, Work Records, Payments, Owners, Photos, Search, Summary, Settings) are extracted to string resources:
     - `res/values/strings.xml` (English, default)
     - `res/values-hi/strings.xml` (हिन्दी / Hindi)
   - Real-time language switching: User can toggle language via the top header pill button or from the Settings screen.
   - Immediate UI update via `CompositionLocalProvider(LocalContext provides localizedContext)`.
   - Persisted in `SharedPreferences` (`LanguageManager`).
   - Standard currency & number formatting: `Rs. 95,000`.
   - Extensible structure for adding future languages (Urdu, Punjabi, etc.).

3. **100% Offline Storage**:
   - Room SQLite with pre-seeded data, zero external dependencies or internet connection required.

## How to Build & Run
Open the `android/` directory in Android Studio (Koala, Ladybug or newer) or run:
```bash
./gradlew assembleDebug
```
The debug APK will be generated at:
`app/build/outputs/apk/debug/app-debug.apk`
