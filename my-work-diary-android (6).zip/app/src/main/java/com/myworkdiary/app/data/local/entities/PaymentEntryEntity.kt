package com.myworkdiary.app.data.local.entities

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "payments",
    indices = [
        Index(value = ["labourId"]),
        Index(value = ["workerId"]),
        Index(value = ["date"])
    ]
)
data class PaymentEntryEntity(
    @PrimaryKey
    val id: String = "",
    val date: String = "",
    val labourId: String = "", // Links to LabourProfileEntity.id
    val workerId: String = "",
    val workerName: String = "",
    val recipient: String = "",
    val amount: Double = 0.0,
    val paymentType: String = "Cash", // Cash, Bank, Online, Cheque, Other
    val paymentMethod: String = "Cash",
    val paymentKind: String = "Wage", // "Wage" or "Advance"
    val category: String = "Labour", // Labour, Material, Other Expense
    val isAdvance: Boolean = false,
    val reason: String = "",
    val notes: String = "",
    val receiptPhoto: String? = null,
    val project: String = "",
    val linkedWorkLineId: String? = null
)
