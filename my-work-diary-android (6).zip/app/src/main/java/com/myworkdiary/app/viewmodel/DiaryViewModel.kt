package com.myworkdiary.app.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.myworkdiary.app.MyWorkDiaryApp
import com.myworkdiary.app.data.local.LanguageManager
import com.myworkdiary.app.data.local.entities.ClientPaymentEntity
import com.myworkdiary.app.data.local.entities.DayRecordEntity
import com.myworkdiary.app.data.local.entities.LabourEntryEntity
import com.myworkdiary.app.data.local.entities.LabourProfileEntity
import com.myworkdiary.app.data.local.entities.OwnerEntity
import com.myworkdiary.app.data.local.entities.PaymentEntryEntity
import com.myworkdiary.app.data.local.entities.PhotoRecordEntity
import com.myworkdiary.app.data.local.entities.ProjectContractEntity
import com.myworkdiary.app.data.local.entities.WorkEntryEntity
import com.myworkdiary.app.model.DailyTotalsSummary
import com.myworkdiary.app.model.ProjectFinancialSummary
import com.myworkdiary.app.model.WorkerLedgerSummary
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class DiaryViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = (application as MyWorkDiaryApp).repository

    // Language state
    val currentLanguage: StateFlow<String> = LanguageManager.currentLanguage

    fun setLanguage(context: Context, langCode: String) {
        LanguageManager.setLanguage(context, langCode)
    }

    // Current Project Filter
    private val _currentProject = MutableStateFlow("ALL")
    val currentProject: StateFlow<String> = _currentProject.asStateFlow()

    // Selected Day ID for Notebook view
    private val _selectedDayId = MutableStateFlow<String?>(null)
    val selectedDayId: StateFlow<String?> = _selectedDayId.asStateFlow()

    val allDays = repository.allDays.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val allProfiles = repository.allProfiles.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val allLabourEntries = repository.allLabourEntries.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val allWorkEntries = repository.allWorkEntries.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val allPayments = repository.allPayments.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val allOwners = repository.allOwners.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val allClientPayments = repository.allClientPayments.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val allContracts = repository.allContracts.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val allPhotos = repository.allPhotos.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // Filtered by selected project
    val filteredDays = combine(allDays, currentProject) { days, proj ->
        if (proj == "ALL") days else days.filter { it.project.equals(proj, ignoreCase = true) }
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val filteredLabourEntries = combine(allLabourEntries, currentProject) { entries, proj ->
        if (proj == "ALL") entries else entries.filter { it.project.equals(proj, ignoreCase = true) }
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val filteredPayments = combine(allPayments, currentProject) { payments, proj ->
        if (proj == "ALL") payments else payments.filter { it.project.equals(proj, ignoreCase = true) }
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // Total Payments Out (सभी मज़दूरों को दी गई कुल पेमेंट का जोड़)
    val totalPaymentsOut: StateFlow<Double> = allPayments.map { payments ->
        payments.filter {
            it.category == "Labour" || it.labourId.isNotEmpty() || it.workerName.isNotEmpty()
        }.sumOf { it.amount }
    }.stateIn(viewModelScope, SharingStarted.Lazily, 0.0)

    // Valid Client Payments (केवल वे भुगतान जो वर्तमान में किसी मौजूदा मालिक से जुड़े हैं)
    val validClientPayments: StateFlow<List<ClientPaymentEntity>> = combine(allClientPayments, allOwners) { payments, owners ->
        val validOwnerIds = owners.map { it.id }.toSet()
        payments.filter { validOwnerIds.contains(it.ownerId) }
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // Total Client Received (सिर्फ़ वैध मालिकों से प्राप्त कुल रक़म)
    val totalClientReceived: StateFlow<Double> = validClientPayments.map { payments ->
        payments.sumOf { it.amount }
    }.stateIn(viewModelScope, SharingStarted.Lazily, 0.0)

    fun selectProject(project: String) {
        _currentProject.value = project
    }

    fun selectDayId(id: String) {
        _selectedDayId.value = id
    }

    // Calculations
    fun getDailyTotals(dayLabour: List<LabourEntryEntity>, dayPayments: List<PaymentEntryEntity>): DailyTotalsSummary {
        return repository.calculateDailyTotals(dayLabour, dayPayments)
    }

    fun getWorkerLedger(workerName: String): WorkerLedgerSummary {
        return repository.calculateWorkerLedger(workerName, allLabourEntries.value, allPayments.value)
    }

    fun getProjectSummary(projectName: String): ProjectFinancialSummary {
        return repository.calculateProjectSummary(
            projectName,
            allLabourEntries.value,
            allPayments.value,
            allWorkEntries.value,
            allClientPayments.value,
            allContracts.value
        )
    }

    // CRUD Handlers
    fun saveDay(day: DayRecordEntity) = viewModelScope.launch {
        repository.insertDay(day)
        _selectedDayId.value = day.id
    }

    fun deleteDay(dayId: String) = viewModelScope.launch {
        repository.deleteDay(dayId)
    }

    fun saveLabourEntry(entry: LabourEntryEntity) = viewModelScope.launch {
        repository.insertLabourEntry(entry)
    }

    fun deleteLabourEntry(id: String) = viewModelScope.launch {
        repository.deleteLabourEntry(id)
    }

    fun saveProfile(profile: LabourProfileEntity) = viewModelScope.launch {
        repository.insertProfile(profile)
    }

    fun deleteProfile(id: String) = viewModelScope.launch {
        repository.deleteProfile(id)
    }

    fun savePayment(payment: PaymentEntryEntity) = viewModelScope.launch {
        repository.insertPayment(payment)
        if (!payment.linkedWorkLineId.isNullOrEmpty()) {
            val matching = allLabourEntries.value.find { it.id == payment.linkedWorkLineId }
            if (matching != null) {
                repository.insertLabourEntry(matching.copy(paid = true, status = "Paid", linkedPaymentId = payment.id))
            }
        }
    }

    fun updatePayment(payment: PaymentEntryEntity) = viewModelScope.launch {
        repository.updatePayment(payment)
    }

    fun deletePayment(id: String) = viewModelScope.launch {
        repository.deletePayment(id)
    }

    fun getOrCreateWorkerProfile(name: String): LabourProfileEntity {
        val cleanName = name.trim()
        val existing = allProfiles.value.find { it.name.trim().equals(cleanName, ignoreCase = true) }
        if (existing != null) return existing
        val newProfile = LabourProfileEntity(
            id = "worker-${java.util.UUID.randomUUID().toString().take(8)}",
            name = cleanName,
            category = "Labour",
            role = "Worker",
            standardDailyRate = 1500.0,
            dailyRate = 1500.0,
            phone = ""
        )
        saveProfile(newProfile)
        return newProfile
    }

    // Owner Operations
    fun saveOwner(owner: OwnerEntity) = viewModelScope.launch {
        repository.insertOwner(owner)
    }

    fun deleteOwner(id: String) = viewModelScope.launch {
        repository.deleteOwner(id)
    }

    fun isOwnerCodeDuplicate(code: String, excludeId: String? = null): Boolean {
        val clean = code.trim()
        if (clean.isEmpty()) return false
        return allOwners.value.any {
            if (excludeId != null && it.id == excludeId) false
            else it.code.trim().equals(clean, ignoreCase = true)
        }
    }

    fun findOwnerByCode(code: String): OwnerEntity? {
        val clean = code.trim()
        if (clean.isEmpty()) return null
        return allOwners.value.find { it.code.trim().equals(clean, ignoreCase = true) }
    }

    fun getOwnerById(id: String): OwnerEntity? {
        return allOwners.value.find { it.id == id }
    }

    // Client Payment Operations
    fun saveClientPayment(payment: ClientPaymentEntity) = viewModelScope.launch {
        repository.insertClientPayment(payment)
    }

    fun deleteClientPayment(id: String) = viewModelScope.launch {
        repository.deleteClientPayment(id)
    }

    fun updateContractAmount(projectName: String, amount: Double) = viewModelScope.launch {
        repository.updateContract(ProjectContractEntity(projectName, amount))
    }

    // Photo Operations (safely wrapped in try/catch)
    fun savePhoto(photo: PhotoRecordEntity) = viewModelScope.launch {
        try {
            repository.insertPhoto(photo)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun deletePhoto(id: String) = viewModelScope.launch {
        try {
            repository.deletePhoto(id)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // Clear All Data
    fun clearAllData() = viewModelScope.launch {
        repository.clearAllData()
    }
}
