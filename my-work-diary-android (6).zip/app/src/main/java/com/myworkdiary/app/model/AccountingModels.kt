package com.myworkdiary.app.model

data class WorkerLedgerRow(
    val id: String = "",
    val date: String = "",
    val description: String = "",
    val amount: Double = 0.0,
    val status: String = "",
    val type: String = "Work", // "Work", "Advance", "Payment"
    val paymentKind: String? = null,
    val isAdvance: Boolean = false,
    val project: String = ""
)

data class WorkerLedgerSummary(
    val workerName: String = "",
    val totalWorkAmount: Double = 0.0,
    val totalPaid: Double = 0.0,
    val totalAdvance: Double = 0.0,
    val totalUnpaid: Double = 0.0,
    val currentBalance: Double = 0.0,
    val daysWorked: Int = 0,
    val history: List<WorkerLedgerRow> = emptyList()
)

data class DailyTotalsSummary(
    val labourWorkTotal: Double = 0.0,
    val materialTotal: Double = 0.0,
    val otherExpenses: Double = 0.0,
    val paidToday: Double = 0.0,
    val unpaidToday: Double = 0.0,
    val advancePaidToday: Double = 0.0,
    val grandTotal: Double = 0.0
)

data class ProjectFinancialSummary(
    val projectName: String = "",
    val totalLabourCost: Double = 0.0,
    val totalLabourPaid: Double = 0.0,
    val totalLabourUnpaid: Double = 0.0,
    val totalMaterialCost: Double = 0.0,
    val totalOtherExpenses: Double = 0.0,
    val grandTotalProjectCost: Double = 0.0,
    val totalPaidOut: Double = 0.0,
    val totalRemainingDue: Double = 0.0,
    // Client / Owner Financials:
    val contractAmount: Double = 0.0,
    val totalMoneyReceived: Double = 0.0,
    val remainingClientBalance: Double = 0.0,
    val projectProfit: Double = 0.0
)
