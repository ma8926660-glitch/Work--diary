package com.myworkdiary.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.myworkdiary.app.R
import com.myworkdiary.app.ui.navigation.Screen
import com.myworkdiary.app.ui.theme.*
import com.myworkdiary.app.viewmodel.DiaryViewModel

@Composable
fun HomeScreen(
    viewModel: DiaryViewModel,
    onNavigate: (String) -> Unit
) {
    val context = LocalContext.current
    val currentLang by viewModel.currentLanguage.collectAsState()
    val days by viewModel.allDays.collectAsState()
    val profiles by viewModel.allProfiles.collectAsState()
    val labourEntries by viewModel.allLabourEntries.collectAsState()
    val payments by viewModel.allPayments.collectAsState()
    val clientPayments by viewModel.allClientPayments.collectAsState()
    val owners by viewModel.allOwners.collectAsState()
    val totalPaymentsOut by viewModel.totalPaymentsOut.collectAsState()

    val validOwnerIds = remember(owners) { owners.map { it.id }.toSet() }
    val validClientPayments = remember(clientPayments, validOwnerIds) {
        clientPayments.filter { validOwnerIds.contains(it.ownerId) }
    }

    val totalDays = days.size
    val totalWorkers = profiles.size
    val totalWagesEarned = labourEntries.sumOf { it.dailyPayment }
    val totalLabourPaymentsPaid = totalPaymentsOut
    val totalClientReceived = remember(validClientPayments) { validClientPayments.sumOf { it.amount } }
    val totalClientReceipts = validClientPayments.size
    val balance = totalClientReceived - totalPaymentsOut

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(NotebookPaper)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Digital Notebook Cover Header
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = PrimaryBrownDark),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                listOf(PrimaryBrown, PrimaryBrownDark, Color(0xFF260E03))
                            )
                        )
                        .padding(16.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = Color.Black.copy(alpha = 0.4f),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = stringResource(R.string.header_contractor_notebook),
                                    color = AmberGold,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                // Language toggle pill button
                                Surface(
                                    color = Color.White.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.clickable {
                                        val newLang = if (currentLang == "en") "hi" else "en"
                                        viewModel.setLanguage(context, newLang)
                                    }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Language,
                                            contentDescription = "Switch Language",
                                            tint = Color.White,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = if (currentLang == "en") "हिन्दी" else "EN",
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.width(6.dp))

                                IconButton(
                                    onClick = { onNavigate(Screen.Settings.route) },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Settings,
                                        contentDescription = "Settings",
                                        tint = Color.White.copy(alpha = 0.85f),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = stringResource(R.string.app_name),
                            color = Color.White,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = stringResource(R.string.app_subtitle),
                            color = AmberLight.copy(alpha = 0.85f),
                            fontSize = 12.sp
                        )

                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = Color.White.copy(alpha = 0.15f))
                        Spacer(modifier = Modifier.height(10.dp))

                        // Quick Glance 4 Stat Boxes
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            GlanceBox(title = stringResource(R.string.stat_days_logged), value = "$totalDays", modifier = Modifier.weight(1f))
                            GlanceBox(title = stringResource(R.string.stat_client_recv), value = "Rs. ${totalClientReceived.toInt()}", valueColor = EmeraldLight, modifier = Modifier.weight(1.3f))
                            GlanceBox(title = stringResource(R.string.stat_wages_paid), value = "Rs. ${totalLabourPaymentsPaid.toInt()}", modifier = Modifier.weight(1.3f))
                            GlanceBox(title = stringResource(R.string.stat_balance), value = "Rs. ${balance.toInt()}", valueColor = if (balance >= 0) EmeraldLight else Color(0xFFFCA5A5), modifier = Modifier.weight(1.2f))
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            color = Color.Black.copy(alpha = 0.35f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = stringResource(R.string.stat_balance_calc, totalClientReceived.toInt(), totalLabourPaymentsPaid.toInt(), balance.toInt()),
                                color = AmberLight,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        }

        // 2. Add Today's Work Button
        item {
            Button(
                onClick = { onNavigate(Screen.AddTodayWork.route) },
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = AmberGold,
                    contentColor = Color.White
                ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.25f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = stringResource(R.string.btn_add_today_work),
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = stringResource(R.string.btn_add_today_work_sub),
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                }
            }
        }

        // 3. OWNER-WISE PAYMENTS CARD
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = EmeraldDark),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigate(Screen.ClientPayments.route) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.White.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccountBalanceWallet,
                                contentDescription = "Client Payments",
                                tint = EmeraldLight,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = stringResource(R.string.section_owner_payments_title),
                                    color = Color.White,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    color = Color.Black.copy(alpha = 0.3f),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = stringResource(R.string.badge_money_in),
                                        color = EmeraldLight,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = stringResource(
                                    R.string.owner_payments_summary_format,
                                    totalClientReceived.toInt(),
                                    totalClientReceipts
                                ),
                                color = EmeraldLight.copy(alpha = 0.9f),
                                fontSize = 11.sp
                            )
                        }
                    }
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = "Open",
                        tint = EmeraldLight
                    )
                }
            }
        }

        // 3B. LABOUR ACCOUNTS CARD
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF78350F)),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigate(Screen.LabourAccounts.route) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.White.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Payments,
                                contentDescription = "Labour Accounts",
                                tint = AmberLight,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = stringResource(R.string.section_labour_payments_title),
                                    color = Color.White,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    color = Color.Black.copy(alpha = 0.3f),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = stringResource(R.string.badge_money_out),
                                        color = AmberGold,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = stringResource(
                                    R.string.section_labour_payments_sub,
                                    totalLabourPaymentsPaid.toInt(),
                                    totalWorkers
                                ),
                                color = AmberLight.copy(alpha = 0.9f),
                                fontSize = 11.sp
                            )
                        }
                    }
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = "Open",
                        tint = AmberLight
                    )
                }
            }
        }

        // 4. Notebook Sections
        item {
            Text(
                text = stringResource(R.string.sections_header),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = TextMuted,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        item {
            MenuOptionCard(
                title = stringResource(R.string.menu_daily_diary),
                subtitle = stringResource(R.string.menu_daily_diary_sub),
                badge = "$totalDays",
                icon = Icons.Default.Book,
                iconBg = PrimaryBrown,
                onClick = { onNavigate(Screen.DailyNotebook.route) }
            )
        }

        item {
            MenuOptionCard(
                title = stringResource(R.string.menu_labour_records),
                subtitle = stringResource(R.string.menu_labour_records_sub),
                badge = "Rs. ${totalLabourPaymentsPaid.toInt()}",
                icon = Icons.Default.People,
                iconBg = Color(0xFF78350F),
                onClick = { onNavigate(Screen.LabourAccounts.route) }
            )
        }

        item {
            MenuOptionCard(
                title = stringResource(R.string.menu_work_records),
                subtitle = stringResource(R.string.menu_work_records_sub),
                badge = "Site Jobs",
                icon = Icons.Default.Build,
                iconBg = Color(0xFF292524),
                onClick = { onNavigate(Screen.WorkRecords.route) }
            )
        }

        item {
            MenuOptionCard(
                title = stringResource(R.string.menu_payment_records),
                subtitle = stringResource(R.string.menu_payment_records_sub),
                badge = "Rs. ${totalPaymentsOut.toInt()}",
                icon = Icons.Default.Payments,
                iconBg = EmeraldGreen,
                onClick = { onNavigate(Screen.Payments.route) }
            )
        }

        item {
            MenuOptionCard(
                title = stringResource(R.string.menu_site_photos),
                subtitle = stringResource(R.string.menu_site_photos_sub),
                badge = "Gallery",
                icon = Icons.Default.CameraAlt,
                iconBg = Color(0xFF0F766E),
                onClick = { onNavigate(Screen.Photos.route) }
            )
        }

        item {
            MenuOptionCard(
                title = stringResource(R.string.menu_search),
                subtitle = stringResource(R.string.menu_search_sub),
                badge = "Instant",
                icon = Icons.Default.Search,
                iconBg = Color(0xFF3730A3),
                onClick = { onNavigate(Screen.Search.route) }
            )
        }

        item {
            MenuOptionCard(
                title = stringResource(R.string.menu_monthly_summary),
                subtitle = stringResource(R.string.menu_monthly_summary_sub),
                badge = "Summary",
                icon = Icons.Default.BarChart,
                iconBg = Color(0xFF451A03),
                onClick = { onNavigate(Screen.Summary.route) }
            )
        }

        item {
            MenuOptionCard(
                title = stringResource(R.string.menu_backup_restore),
                subtitle = stringResource(R.string.menu_backup_restore_sub),
                badge = "JSON",
                icon = Icons.Default.Backup,
                iconBg = Color(0xFF475569),
                onClick = { onNavigate(Screen.Backup.route) }
            )
        }

        item {
            MenuOptionCard(
                title = stringResource(R.string.menu_settings),
                subtitle = stringResource(R.string.menu_settings_sub),
                badge = currentLang.uppercase(),
                icon = Icons.Default.Settings,
                iconBg = PrimaryBrownDark,
                onClick = { onNavigate(Screen.Settings.route) }
            )
        }
    }
}

@Composable
fun GlanceBox(title: String, value: String, modifier: Modifier = Modifier, valueColor: Color = Color.White) {
    Surface(
        color = Color.Black.copy(alpha = 0.25f),
        shape = RoundedCornerShape(10.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = title, fontSize = 9.sp, color = AmberGold, fontWeight = FontWeight.Medium)
            Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = valueColor, maxLines = 1)
        }
    }
}

@Composable
fun MenuOptionCard(
    title: String,
    subtitle: String,
    badge: String,
    icon: ImageVector,
    iconBg: Color,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(iconBg),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(text = title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextDark)
                    Text(text = subtitle, fontSize = 11.sp, color = TextMuted)
                }
            }
            Text(
                text = badge,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextMuted
            )
        }
    }
}
