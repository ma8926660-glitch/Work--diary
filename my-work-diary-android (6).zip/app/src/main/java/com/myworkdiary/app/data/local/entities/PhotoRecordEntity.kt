package com.myworkdiary.app.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "photos")
data class PhotoRecordEntity(
    @PrimaryKey
    val id: String = "",
    val filePath: String? = "",
    val caption: String? = "",
    val date: String? = "",
    val linkedType: String? = "None", // "None", "Owner", "Labour"
    val linkedId: String? = "",
    val linkedName: String? = "",
    val createdAt: String? = ""
) {
    val safeFilePath: String get() = filePath.orEmpty()
    val safeCaption: String get() = caption.orEmpty()
    val safeDate: String get() = date.orEmpty()
    val safeLinkedType: String get() = linkedType.orEmpty().ifEmpty { "None" }
    val safeLinkedId: String get() = linkedId.orEmpty()
    val safeLinkedName: String get() = linkedName.orEmpty()
    val safeCreatedAt: String get() = createdAt.orEmpty()
}
