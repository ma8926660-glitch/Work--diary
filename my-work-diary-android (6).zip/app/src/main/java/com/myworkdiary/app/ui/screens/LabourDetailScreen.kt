package com.myworkdiary.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.myworkdiary.app.R
import com.myworkdiary.app.data.local.entities.PaymentEntryEntity
import com.myworkdiary.app.ui.theme.*
import com.myworkdiary.app.viewmodel.DiaryViewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

enum class TimePeriodFilter {
    OVERALL,
    THIS_WEEK,
    LAST_WEEK,
    THIS_MONTH,
    LAST_MONTH,
    CUSTOM_MONTH
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LabourDetailScreen(
    viewModel: DiaryViewModel,
    workerName: String,
    onBack: () -> Unit
) {
    val allProfiles by viewModel.allProfiles.collectAsState()
    val allPayments by viewModel.allPayments.collectAsState()

    // Find worker profile
    val profile = remember(allProfiles, workerName) {
        allProfiles.find { it.name.trim().equals(workerName.trim(), ignoreCase = true) }
    }
    val workerId = profile?.id ?: ""

    // Strictly filter payments belonging ONLY to this labourer
    val workerPayments = remember(allPayments, workerId, workerName) {
        allPayments.filter {
            (workerId.isNotEmpty() && (it.labourId == workerId || it.workerId == workerId)) ||
                    it.workerName.trim().equals(workerName.trim(), ignoreCase = true) ||
                    it.recipient.trim().equals(workerName.trim(), ignoreCase = true)
        }.sortedByDescending { it.date }
    }

    // Time calculations
    val todayCal = Calendar.getInstance()
    val curYearMonth = SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(todayCal.time)

    val lastMonthCal = Calendar.getInstance().apply { add(Calendar.MONTH, -1) }
    val lastYearMonth = SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(lastMonthCal.time)

    // Calculate start & end of this week and last week
    val (thisWeekStart, thisWeekEnd) = remember {
        val cal = Calendar.getInstance()
        cal.firstDayOfWeek = Calendar.MONDAY
        cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val start = sdf.format(cal.time)
        cal.add(Calendar.DAY_OF_WEEK, 6)
        val end = sdf.format(cal.time)
        Pair(start, end)
    }

    val (lastWeekStart, lastWeekEnd) = remember {
        val cal = Calendar.getInstance()
        cal.firstDayOfWeek = Calendar.MONDAY
        cal.add(Calendar.WEEK_OF_YEAR, -1)
        cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val start = sdf.format(cal.time)
        cal.add(Calendar.DAY_OF_WEEK, 6)
        val end = sdf.format(cal.time)
        Pair(start, end)
    }

    // Available distinct months for custom picker
    val distinctMonths = remember(workerPayments) {
        val set = mutableSetOf(curYearMonth)
        workerPayments.forEach { p ->
            if (p.date.length >= 7) set.add(p.date.take(7))
        }
        set.sortedDescending()
    }

    var selectedPeriod by remember { mutableStateOf(TimePeriodFilter.OVERALL) }
    var customSelectedMonth by remember { mutableStateOf(curYearMonth) }
    var monthDropdownExpanded by remember { mutableStateOf(false) }

    // Dialog states
    var showAddPaymentDialog by remember { mutableStateOf(false) }
    var editingPayment by remember { mutableStateOf<PaymentEntryEntity?>(null) }
    var deletingPayment by remember { mutableStateOf<PaymentEntryEntity?>(null) }

    // Summary calculations across time periods
    val overallTotal = remember(workerPayments) { workerPayments.sumOf { it.amount } }
    val thisMonthTotal = remember(workerPayments, curYearMonth) {
        workerPayments.filter { it.date.startsWith(curYearMonth) }.sumOf { it.amount }
    }
    val thisWeekTotal = remember(workerPayments, thisWeekStart, thisWeekEnd) {
        workerPayments.filter { it.date in thisWeekStart..thisWeekEnd }.sumOf { it.amount }
    }

    // Filtered payments by selected period
    val displayedPayments = remember(workerPayments, selectedPeriod, customSelectedMonth, thisWeekStart, thisWeekEnd, lastWeekStart, lastWeekEnd, curYearMonth, lastYearMonth) {
        when (selectedPeriod) {
            TimePeriodFilter.OVERALL -> workerPayments
            TimePeriodFilter.THIS_WEEK -> workerPayments.filter { it.date in thisWeekStart..thisWeekEnd }
            TimePeriodFilter.LAST_WEEK -> workerPayments.filter { it.date in lastWeekStart..lastWeekEnd }
            TimePeriodFilter.THIS_MONTH -> workerPayments.filter { it.date.startsWith(curYearMonth) }
            TimePeriodFilter.LAST_MONTH -> workerPayments.filter { it.date.startsWith(lastYearMonth) }
            TimePeriodFilter.CUSTOM_MONTH -> workerPayments.filter { it.date.startsWith(customSelectedMonth) }
        }
    }

    val periodWages = remember(displayedPayments) {
        displayedPayments.filter { !it.isAdvance }.sumOf { it.amount }
    }
    val periodAdvances = remember(displayedPayments) {
        displayedPayments.filter { it.isAdvance }.sumOf { it.amount }
    }
    val periodTotal = remember(displayedPayments) {
        displayedPayments.sumOf { it.amount }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = workerName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = profile?.let { "${it.role.ifEmpty { it.category }} • Rs. ${it.standardDailyRate.toInt()}/day" } ?: "Worker Account",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { showAddPaymentDialog = true }) {
                        Icon(Icons.Default.Payments, contentDescription = stringResource(R.string.btn_add_labour_payment))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = PrimaryBrownDark,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddPaymentDialog = true },
                containerColor = EmeraldGreen,
                contentColor = Color.White,
                icon = { Icon(Icons.Default.Payments, contentDescription = null) },
                text = { Text(stringResource(R.string.btn_add_labour_payment), fontWeight = FontWeight.Bold) }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(NotebookPaper)
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // 1. Worker Profile Summary Card
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                        .background(PrimaryBrown.copy(alpha = 0.12f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(profile?.avatarValue?.ifEmpty { "👷" } ?: "👷", fontSize = 22.sp)
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(workerName, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = TextDark)
                                    Text(
                                        text = profile?.phone?.ifEmpty { "No phone" } ?: "Worker Profile",
                                        fontSize = 12.sp,
                                        color = TextMuted
                                    )
                                }
                            }

                            Surface(
                                color = EmeraldGreen.copy(alpha = 0.12f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = "Rs. ${profile?.standardDailyRate?.toInt() ?: 0}/day",
                                    color = EmeraldDark,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = Color(0xFFF0EAE1))
                        Spacer(modifier = Modifier.height(10.dp))

                        // Quick 3 Time Stat Columns
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(stringResource(R.string.lbl_this_week_total), fontSize = 11.sp, color = TextMuted)
                                Text(
                                    "Rs. ${thisWeekTotal.toInt()}",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextDark
                                )
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(stringResource(R.string.lbl_this_month_total), fontSize = 11.sp, color = TextMuted)
                                Text(
                                    "Rs. ${thisMonthTotal.toInt()}",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldDark
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(stringResource(R.string.lbl_overall_total), fontSize = 11.sp, color = TextMuted)
                                Text(
                                    "Rs. ${overallTotal.toInt()}",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Black,
                                    color = PrimaryBrownDark
                                )
                            }
                        }
                    }
                }
            }

            // 2. Filter Tabs (This Week, This Month, Overall, Last Week, Last Month, Pick Month)
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = stringResource(R.string.lbl_period_filter).uppercase(),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextMuted,
                        letterSpacing = 1.sp
                    )

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        item {
                            FilterChip(
                                selected = selectedPeriod == TimePeriodFilter.OVERALL,
                                onClick = { selectedPeriod = TimePeriodFilter.OVERALL },
                                label = { Text(stringResource(R.string.tab_all_time)) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = PrimaryBrownDark,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                        item {
                            FilterChip(
                                selected = selectedPeriod == TimePeriodFilter.THIS_WEEK,
                                onClick = { selectedPeriod = TimePeriodFilter.THIS_WEEK },
                                label = { Text(stringResource(R.string.tab_this_week)) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = PrimaryBrownDark,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                        item {
                            FilterChip(
                                selected = selectedPeriod == TimePeriodFilter.THIS_MONTH,
                                onClick = { selectedPeriod = TimePeriodFilter.THIS_MONTH },
                                label = { Text(stringResource(R.string.tab_this_month)) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = PrimaryBrownDark,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                        item {
                            FilterChip(
                                selected = selectedPeriod == TimePeriodFilter.LAST_WEEK,
                                onClick = { selectedPeriod = TimePeriodFilter.LAST_WEEK },
                                label = { Text(stringResource(R.string.tab_last_week)) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = PrimaryBrownDark,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                        item {
                            FilterChip(
                                selected = selectedPeriod == TimePeriodFilter.LAST_MONTH,
                                onClick = { selectedPeriod = TimePeriodFilter.LAST_MONTH },
                                label = { Text(stringResource(R.string.tab_last_month)) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = PrimaryBrownDark,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                        item {
                            Box {
                                FilterChip(
                                    selected = selectedPeriod == TimePeriodFilter.CUSTOM_MONTH,
                                    onClick = {
                                        selectedPeriod = TimePeriodFilter.CUSTOM_MONTH
                                        monthDropdownExpanded = true
                                    },
                                    label = { Text("📅 ${customSelectedMonth}") },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = AmberGold,
                                        selectedLabelColor = Color.White
                                    )
                                )
                                DropdownMenu(
                                    expanded = monthDropdownExpanded,
                                    onDismissRequest = { monthDropdownExpanded = false }
                                ) {
                                    distinctMonths.forEach { m ->
                                        DropdownMenuItem(
                                            text = { Text(m) },
                                            onClick = {
                                                customSelectedMonth = m
                                                selectedPeriod = TimePeriodFilter.CUSTOM_MONTH
                                                monthDropdownExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 3. Selected Period Breakdown Card (Wages vs Advances)
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Period Breakdown (${displayedPayments.size} entries)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextMuted
                            )
                            Text(
                                text = "Total: Rs. ${periodTotal.toInt()}",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Black,
                                color = PrimaryBrownDark
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = EmeraldGreen.copy(alpha = 0.08f),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(stringResource(R.string.lbl_wages_total), fontSize = 11.sp, color = TextMuted)
                                    Text("Rs. ${periodWages.toInt()}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = EmeraldDark)
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = AmberGold.copy(alpha = 0.1f),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(stringResource(R.string.lbl_advances_total), fontSize = 11.sp, color = TextMuted)
                                    Text("Rs. ${periodAdvances.toInt()}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = AmberGold)
                                }
                            }
                        }
                    }
                }
            }

            // 4. Payment History Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "PAYMENT RECORDS (${displayedPayments.size})",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextMuted,
                        letterSpacing = 1.sp
                    )
                }
            }

            // 5. Payment Items List
            if (displayedPayments.isEmpty()) {
                item {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = stringResource(R.string.no_payments_for_worker),
                                color = TextMuted,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            } else {
                items(displayedPayments) { payment ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        color = if (payment.isAdvance) AmberGold.copy(alpha = 0.15f) else EmeraldGreen.copy(alpha = 0.15f),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = if (payment.isAdvance) "Advance (पेशगी)" else "Wage (मज़दूरी)",
                                            color = if (payment.isAdvance) Color(0xFFB45309) else EmeraldDark,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = payment.date,
                                        fontSize = 12.sp,
                                        color = TextMuted,
                                        fontWeight = FontWeight.Medium
                                    )
                                }

                                Text(
                                    text = "Rs. ${payment.amount.toInt()}",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (payment.isAdvance) AmberGold else EmeraldDark
                                )
                            }

                            if (payment.notes.isNotEmpty() || payment.reason.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = payment.notes.ifEmpty { payment.reason },
                                    fontSize = 13.sp,
                                    color = TextDark
                                )
                            }

                            if (payment.project.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Site: ${payment.project}",
                                    fontSize = 11.sp,
                                    color = TextMuted
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            HorizontalDivider(color = Color(0xFFF5EFE6))
                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TextButton(
                                    onClick = { editingPayment = payment },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(30.dp)
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = "Edit", modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(stringResource(R.string.btn_edit), fontSize = 11.sp)
                                }

                                Spacer(modifier = Modifier.width(6.dp))

                                TextButton(
                                    onClick = { deletingPayment = payment },
                                    colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFFDC2626)),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(30.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(stringResource(R.string.btn_delete), fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Add Labour Payment Dialog
    if (showAddPaymentDialog) {
        val workerProfile = profile ?: viewModel.getOrCreateWorkerProfile(workerName)
        AddLabourPaymentDialog(
            allWorkers = listOf(workerProfile),
            initialWorker = workerProfile,
            onDismiss = { showAddPaymentDialog = false },
            onSave = { payment ->
                viewModel.savePayment(payment)
                showAddPaymentDialog = false
            }
        )
    }

    // Edit Labour Payment Dialog
    editingPayment?.let { payment ->
        EditLabourPaymentDialog(
            payment = payment,
            onDismiss = { editingPayment = null },
            onSave = { updated ->
                viewModel.updatePayment(updated)
                editingPayment = null
            }
        )
    }

    // Delete Confirmation Dialog
    deletingPayment?.let { payment ->
        AlertDialog(
            onDismissRequest = { deletingPayment = null },
            title = { Text(stringResource(R.string.btn_delete), fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    text = "${stringResource(R.string.msg_confirm_delete_payment)}\n\nRs. ${payment.amount.toInt()} (${payment.date})",
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deletePayment(payment.id)
                        deletingPayment = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text(stringResource(R.string.btn_delete))
                }
            },
            dismissButton = {
                TextButton(onClick = { deletingPayment = null }) {
                    Text(stringResource(R.string.btn_cancel))
                }
            }
        )
    }
}

@Composable
fun EditLabourPaymentDialog(
    payment: PaymentEntryEntity,
    onDismiss: () -> Unit,
    onSave: (PaymentEntryEntity) -> Unit
) {
    var amountText by remember { mutableStateOf(payment.amount.toInt().toString()) }
    var dateText by remember { mutableStateOf(payment.date) }
    var isAdvance by remember { mutableStateOf(payment.isAdvance) }
    var noteText by remember { mutableStateOf(payment.notes.ifEmpty { payment.reason }) }
    var errorMessage by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = stringResource(R.string.dialog_edit_labour_payment_title),
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Worker: ${payment.workerName}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = PrimaryBrownDark
                )

                OutlinedTextField(
                    value = amountText,
                    onValueChange = {
                        amountText = it
                        errorMessage = ""
                    },
                    label = { Text(stringResource(R.string.lbl_amount_rs)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = dateText,
                    onValueChange = { dateText = it },
                    label = { Text(stringResource(R.string.lbl_date)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    text = stringResource(R.string.lbl_payment_type),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextDark
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = !isAdvance,
                        onClick = { isAdvance = false },
                        label = { Text(stringResource(R.string.type_wage)) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = EmeraldGreen,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = isAdvance,
                        onClick = { isAdvance = true },
                        label = { Text(stringResource(R.string.type_advance)) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = AmberGold,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = noteText,
                    onValueChange = { noteText = it },
                    label = { Text(stringResource(R.string.lbl_short_note)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMessage.isNotEmpty()) {
                    Text(
                        text = errorMessage,
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 12.sp
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountText.toDoubleOrNull() ?: 0.0
                    if (amt <= 0) {
                        errorMessage = "Please enter a valid amount"
                        return@Button
                    }
                    val updated = payment.copy(
                        amount = amt,
                        date = dateText.trim().ifEmpty { payment.date },
                        isAdvance = isAdvance,
                        paymentKind = if (isAdvance) "Advance" else "Wage",
                        notes = noteText.trim(),
                        reason = noteText.trim().ifEmpty { if (isAdvance) "Advance Payment" else "Wage Payment" }
                    )
                    onSave(updated)
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen)
            ) {
                Text(stringResource(R.string.btn_save))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.btn_cancel))
            }
        }
    )
}
