package com.myworkdiary.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.myworkdiary.app.R
import com.myworkdiary.app.data.local.entities.LabourProfileEntity
import com.myworkdiary.app.data.local.entities.PaymentEntryEntity
import com.myworkdiary.app.ui.theme.*
import com.myworkdiary.app.viewmodel.DiaryViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LabourAccountsScreen(
    viewModel: DiaryViewModel,
    onBack: () -> Unit,
    onOpenWorkerLedger: (String) -> Unit
) {
    val profiles by viewModel.allProfiles.collectAsState()
    val allPayments by viewModel.allPayments.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var showAddPaymentDialog by remember { mutableStateOf(false) }
    var selectedWorkerForPayment by remember { mutableStateOf<LabourProfileEntity?>(null) }
    var showAddWorkerDialog by remember { mutableStateOf(false) }

    // Labour-only payments
    val labourPayments = remember(allPayments) {
        allPayments.filter {
            it.category == "Labour" || it.labourId.isNotEmpty() || it.workerName.isNotEmpty()
        }
    }

    val totalLabourPaidAll = remember(labourPayments) {
        labourPayments.sumOf { it.amount }
    }
    val totalWagesAll = remember(labourPayments) {
        labourPayments.filter { !it.isAdvance }.sumOf { it.amount }
    }
    val totalAdvancesAll = remember(labourPayments) {
        labourPayments.filter { it.isAdvance }.sumOf { it.amount }
    }

    // Filtered worker list
    val filteredProfiles = remember(searchQuery, profiles) {
        val q = searchQuery.trim().lowercase()
        if (q.isEmpty()) profiles
        else profiles.filter {
            it.name.lowercase().contains(q) ||
                    it.role.lowercase().contains(q) ||
                    it.category.lowercase().contains(q) ||
                    it.phone.lowercase().contains(q)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = stringResource(R.string.title_labour_accounts),
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = stringResource(R.string.subtitle_labour_accounts),
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        selectedWorkerForPayment = profiles.firstOrNull()
                        showAddPaymentDialog = true
                    }) {
                        Icon(Icons.Default.Payments, contentDescription = stringResource(R.string.btn_add_labour_payment))
                    }
                    IconButton(onClick = { showAddWorkerDialog = true }) {
                        Icon(Icons.Default.PersonAdd, contentDescription = stringResource(R.string.btn_add_worker))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = PrimaryBrownDark,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    selectedWorkerForPayment = profiles.firstOrNull()
                    showAddPaymentDialog = true
                },
                containerColor = AmberGold,
                contentColor = Color.White,
                icon = { Icon(Icons.Default.Payments, contentDescription = null) },
                text = { Text(stringResource(R.string.btn_add_labour_payment), fontWeight = FontWeight.Bold) }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(NotebookPaper)
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // 1. Grand Total Card across all workers
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = PrimaryBrownDark),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = stringResource(R.string.lbl_total_labour_paid).uppercase(),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = AmberLight,
                                letterSpacing = 1.sp
                            )
                            Surface(
                                color = Color.White.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = "${profiles.size} ${stringResource(R.string.category_labour)}",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "Rs. ${totalLabourPaidAll.toInt()}",
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = Color.White.copy(alpha = 0.15f))
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(stringResource(R.string.lbl_wages_total), fontSize = 11.sp, color = Color.White.copy(alpha = 0.8f))
                                Text(
                                    "Rs. ${totalWagesAll.toInt()}",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldLight
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(stringResource(R.string.lbl_advances_total), fontSize = 11.sp, color = Color.White.copy(alpha = 0.8f))
                                Text(
                                    "Rs. ${totalAdvancesAll.toInt()}",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AmberGold
                                )
                            }
                        }
                    }
                }
            }

            // 2. Search bar
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text(stringResource(R.string.hint_search_labour_accounts)) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextMuted) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear")
                            }
                        }
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedBorderColor = AmberGold,
                        unfocusedBorderColor = Color(0xFFD6CEBF)
                    )
                )
            }

            // 3. Section Title
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.lbl_all_labourers).uppercase(),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextMuted,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "${filteredProfiles.size} total",
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }
            }

            // 4. Worker Account Cards List
            if (filteredProfiles.isEmpty()) {
                item {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = stringResource(R.string.no_labour_accounts_match),
                                color = TextMuted,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            } else {
                items(filteredProfiles) { worker ->
                    // Calculate totals strictly for this worker
                    val workerPayments = remember(labourPayments, worker.id, worker.name) {
                        labourPayments.filter {
                            (it.labourId.isNotEmpty() && it.labourId == worker.id) ||
                                    (it.workerId.isNotEmpty() && it.workerId == worker.id) ||
                                    (it.workerName.trim().equals(worker.name.trim(), ignoreCase = true))
                        }
                    }
                    val workerTotalPaid = remember(workerPayments) {
                        workerPayments.sumOf { it.amount }
                    }
                    val workerWages = remember(workerPayments) {
                        workerPayments.filter { !it.isAdvance }.sumOf { it.amount }
                    }
                    val workerAdvances = remember(workerPayments) {
                        workerPayments.filter { it.isAdvance }.sumOf { it.amount }
                    }

                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenWorkerLedger(worker.name) }
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(44.dp)
                                            .clip(CircleShape)
                                            .background(PrimaryBrown.copy(alpha = 0.12f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = worker.avatarValue.ifEmpty { "👷" },
                                            fontSize = 20.sp
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = worker.name,
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = TextDark
                                        )
                                        Text(
                                            text = "${worker.role.ifEmpty { worker.category }} • Rs. ${worker.standardDailyRate.toInt()}/day",
                                            fontSize = 12.sp,
                                            color = TextMuted
                                        )
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "Rs. ${workerTotalPaid.toInt()}",
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Black,
                                        color = EmeraldDark
                                    )
                                    Text(
                                        text = stringResource(R.string.lbl_payments_count, workerPayments.size),
                                        fontSize = 11.sp,
                                        color = TextMuted
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            HorizontalDivider(color = Color(0xFFF0EAE1))
                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                    Column {
                                        Text(
                                            text = stringResource(R.string.lbl_wages_total),
                                            fontSize = 10.sp,
                                            color = TextMuted
                                        )
                                        Text(
                                            text = "Rs. ${workerWages.toInt()}",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = EmeraldGreen
                                        )
                                    }
                                    Column {
                                        Text(
                                            text = stringResource(R.string.lbl_advances_total),
                                            fontSize = 10.sp,
                                            color = TextMuted
                                        )
                                        Text(
                                            text = "Rs. ${workerAdvances.toInt()}",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = AmberGold
                                        )
                                    }
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(
                                        onClick = {
                                            selectedWorkerForPayment = worker
                                            showAddPaymentDialog = true
                                        },
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        modifier = Modifier.height(34.dp)
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(stringResource(R.string.lbl_quick_pay), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }

                                    Button(
                                        onClick = { onOpenWorkerLedger(worker.name) },
                                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryBrownDark),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        modifier = Modifier.height(34.dp)
                                    ) {
                                        Text("View", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(12.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Add Labour Payment Dialog
    if (showAddPaymentDialog) {
        AddLabourPaymentDialog(
            allWorkers = profiles,
            initialWorker = selectedWorkerForPayment,
            onDismiss = { showAddPaymentDialog = false },
            onSave = { payment ->
                viewModel.savePayment(payment)
                showAddPaymentDialog = false
            }
        )
    }

    // Add Worker Profile Dialog
    if (showAddWorkerDialog) {
        var newName by remember { mutableStateOf("") }
        var newRole by remember { mutableStateOf("Plumber") }
        var newRate by remember { mutableStateOf("2000") }
        var newPhone by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddWorkerDialog = false },
            title = { Text(stringResource(R.string.btn_add_worker), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        label = { Text("Worker Name *") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newRole,
                        onValueChange = { newRole = it },
                        label = { Text("Trade / Role") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newRate,
                        onValueChange = { newRate = it },
                        label = { Text("Standard Daily Rate (Rs.)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newPhone,
                        onValueChange = { newPhone = it },
                        label = { Text("Phone Number") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val trimmed = newName.trim()
                        if (trimmed.isNotEmpty()) {
                            val rate = newRate.toDoubleOrNull() ?: 2000.0
                            val profile = LabourProfileEntity(
                                id = "worker-${UUID.randomUUID().toString().take(8)}",
                                name = trimmed,
                                category = newRole.trim().ifEmpty { "Labour" },
                                role = newRole.trim().ifEmpty { "Worker" },
                                standardDailyRate = rate,
                                dailyRate = rate,
                                phone = newPhone.trim()
                            )
                            viewModel.saveProfile(profile)
                            showAddWorkerDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBrownDark)
                ) {
                    Text(stringResource(R.string.btn_save))
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddWorkerDialog = false }) {
                    Text(stringResource(R.string.btn_cancel))
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddLabourPaymentDialog(
    allWorkers: List<LabourProfileEntity>,
    initialWorker: LabourProfileEntity?,
    onDismiss: () -> Unit,
    onSave: (PaymentEntryEntity) -> Unit
) {
    val today = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) }

    var selectedWorker by remember { mutableStateOf(initialWorker ?: allWorkers.firstOrNull()) }
    var workerDropdownExpanded by remember { mutableStateOf(false) }
    var amountText by remember { mutableStateOf("") }
    var dateText by remember { mutableStateOf(today) }
    var isAdvance by remember { mutableStateOf(false) }
    var noteText by remember { mutableStateOf("") }
    var paymentMethod by remember { mutableStateOf("Cash") }
    var errorMessage by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = stringResource(R.string.dialog_add_labour_payment_title),
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // 1. Worker Selector Dropdown
                ExposedDropdownMenuBox(
                    expanded = workerDropdownExpanded,
                    onExpandedChange = { workerDropdownExpanded = !workerDropdownExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedWorker?.let { "${it.name} (${it.role.ifEmpty { it.category }})" } ?: "",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text(stringResource(R.string.lbl_select_worker)) },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = workerDropdownExpanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = workerDropdownExpanded,
                        onDismissRequest = { workerDropdownExpanded = false }
                    ) {
                        allWorkers.forEach { w ->
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(w.name, fontWeight = FontWeight.Bold)
                                        Text("${w.role.ifEmpty { w.category }} • Rs. ${w.standardDailyRate.toInt()}/day", fontSize = 11.sp, color = TextMuted)
                                    }
                                },
                                onClick = {
                                    selectedWorker = w
                                    workerDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                // 2. Amount
                OutlinedTextField(
                    value = amountText,
                    onValueChange = {
                        amountText = it
                        errorMessage = ""
                    },
                    label = { Text(stringResource(R.string.lbl_amount_rs)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // 3. Date
                OutlinedTextField(
                    value = dateText,
                    onValueChange = { dateText = it },
                    label = { Text(stringResource(R.string.lbl_date)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // 4. Payment Type Toggle: Wage vs Advance
                Text(
                    text = stringResource(R.string.lbl_payment_type),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextDark
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = !isAdvance,
                        onClick = { isAdvance = false },
                        label = { Text(stringResource(R.string.type_wage)) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = EmeraldGreen,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = isAdvance,
                        onClick = { isAdvance = true },
                        label = { Text(stringResource(R.string.type_advance)) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = AmberGold,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.weight(1f)
                    )
                }

                // 5. Note / Description
                OutlinedTextField(
                    value = noteText,
                    onValueChange = { noteText = it },
                    label = { Text(stringResource(R.string.lbl_short_note)) },
                    placeholder = { Text(if (isAdvance) "e.g. advance for family expense" else "e.g. daily wage for pipe fitting") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMessage.isNotEmpty()) {
                    Text(
                        text = errorMessage,
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 12.sp
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val worker = selectedWorker
                    if (worker == null) {
                        errorMessage = "Please select a worker"
                        return@Button
                    }
                    val amt = amountText.toDoubleOrNull() ?: 0.0
                    if (amt <= 0) {
                        errorMessage = "Please enter a valid amount"
                        return@Button
                    }
                    val finalDate = dateText.trim().ifEmpty { today }
                    val typeLabel = if (isAdvance) "Advance" else "Wage"

                    val payment = PaymentEntryEntity(
                        id = "pay-${UUID.randomUUID()}",
                        date = finalDate,
                        labourId = worker.id,
                        workerId = worker.id,
                        workerName = worker.name,
                        recipient = worker.name,
                        amount = amt,
                        paymentType = paymentMethod,
                        paymentMethod = paymentMethod,
                        paymentKind = typeLabel,
                        category = "Labour",
                        isAdvance = isAdvance,
                        notes = noteText.trim(),
                        reason = noteText.trim().ifEmpty { if (isAdvance) "Advance Payment" else "Wage Payment" }
                    )
                    onSave(payment)
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen)
            ) {
                Text(stringResource(R.string.btn_save))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.btn_cancel))
            }
        }
    )
}
