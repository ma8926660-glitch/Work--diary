package com.myworkdiary.app

import android.app.Application
import com.myworkdiary.app.data.local.DiaryDatabase
import com.myworkdiary.app.data.local.LanguageManager
import com.myworkdiary.app.data.repository.DiaryRepository

class MyWorkDiaryApp : Application() {
    val database by lazy { DiaryDatabase.getDatabase(this) }
    val repository by lazy { DiaryRepository(database.diaryDao(), this) }

    override fun onCreate() {
        super.onCreate()
        LanguageManager.init(this)
    }
}
