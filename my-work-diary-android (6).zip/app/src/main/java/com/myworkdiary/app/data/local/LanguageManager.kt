package com.myworkdiary.app.data.local

import android.content.Context
import android.content.res.Configuration
import android.os.Build
import android.os.LocaleList
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

data class LanguageOption(
    val code: String,
    val displayName: String,
    val nativeName: String
)

object LanguageManager {
    private const val PREFS_NAME = "my_work_diary_language_prefs"
    private const val KEY_LANG = "selected_language"

    val SUPPORTED_LANGUAGES = listOf(
        LanguageOption("en", "English", "English (Default)"),
        LanguageOption("hi", "Hindi", "हिन्दी (Hindi)")
    )

    private val _currentLanguage = MutableStateFlow("en")
    val currentLanguage: StateFlow<String> = _currentLanguage.asStateFlow()

    fun init(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val savedLang = prefs.getString(KEY_LANG, "en") ?: "en"
        _currentLanguage.value = savedLang
    }

    fun setLanguage(context: Context, langCode: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_LANG, langCode).apply()
        _currentLanguage.value = langCode
    }

    /**
     * Creates a localized Context configured for the selected language code.
     * This allows Jetpack Compose stringResource(R.string.*) to dynamically resolve
     * to values/strings.xml or values-hi/strings.xml instantly!
     */
    fun createLocalizedContext(baseContext: Context, langCode: String): Context {
        val locale = Locale(langCode)
        Locale.setDefault(locale)

        val config = Configuration(baseContext.resources.configuration)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            config.setLocales(LocaleList(locale))
        } else {
            @Suppress("DEPRECATION")
            config.locale = locale
        }
        return baseContext.createConfigurationContext(config)
    }
}
