package com.myworkdiary.app.ui.screens

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.myworkdiary.app.R
import com.myworkdiary.app.data.local.entities.PhotoRecordEntity
import com.myworkdiary.app.ui.theme.*
import com.myworkdiary.app.viewmodel.DiaryViewModel
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Safe, crash-proof image loader component using Coil AsyncImage with
 * graceful placeholder, error fallback and null/offline safety.
 */
@Composable
fun SafePhotoThumbnail(
    filePath: String?,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop
) {
    val context = LocalContext.current
    val imageRequest = remember(filePath) {
        val clean = filePath?.trim().orEmpty()
        val data: Any? = when {
            clean.isEmpty() -> null
            clean.startsWith("http://") || clean.startsWith("https://") -> clean
            clean.startsWith("content://") || clean.startsWith("file://") -> try {
                Uri.parse(clean)
            } catch (_: Exception) {
                null
            }
            else -> try {
                val f = File(clean)
                if (f.exists()) f else null
            } catch (_: Exception) {
                null
            }
        }
        ImageRequest.Builder(context)
            .data(data)
            .crossfade(true)
            .error(R.drawable.ic_photo_error)
            .placeholder(R.drawable.ic_photo_placeholder)
            .fallback(R.drawable.ic_photo_placeholder)
            .build()
    }

    AsyncImage(
        model = imageRequest,
        contentDescription = contentDescription.orEmpty(),
        modifier = modifier,
        contentScale = contentScale,
        placeholder = painterResource(R.drawable.ic_photo_placeholder),
        error = painterResource(R.drawable.ic_photo_error),
        fallback = painterResource(R.drawable.ic_photo_placeholder)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhotosScreen(
    viewModel: DiaryViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val rawPhotos by viewModel.allPhotos.collectAsState()
    val rawOwners by viewModel.allOwners.collectAsState()
    val rawProfiles by viewModel.allProfiles.collectAsState()

    // Null-safe filtered lists
    val photos = remember(rawPhotos) { rawPhotos.filterNotNull() }
    val allOwners = remember(rawOwners) { rawOwners.filterNotNull() }
    val allProfiles = remember(rawProfiles) { rawProfiles.filterNotNull() }

    var showAttachDialog by remember { mutableStateOf(false) }
    var viewingPhoto by remember { mutableStateOf<PhotoRecordEntity?>(null) }
    var deletingPhoto by remember { mutableStateOf<PhotoRecordEntity?>(null) }

    // Dialog state (No URL field)
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var tempCameraFile by remember { mutableStateOf<File?>(null) }
    var caption by remember { mutableStateOf("") }
    var dateStr by remember { mutableStateOf("") }
    var linkedType by remember { mutableStateOf("None") } // "None", "Owner", "Labour"
    var selectedOwnerId by remember { mutableStateOf("") }
    var selectedWorkerId by remember { mutableStateOf("") }

    val toastSaved = stringResource(R.string.toast_photo_saved)
    val toastDeleted = stringResource(R.string.toast_photo_deleted)
    val permissionMsg = stringResource(R.string.msg_camera_permission_required)

    // Camera launcher
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        try {
            if (success && tempCameraFile != null && tempCameraFile!!.exists()) {
                selectedImageUri = Uri.fromFile(tempCameraFile)
            }
        } catch (e: Exception) {
            Toast.makeText(context, "Error processing camera capture: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun launchCameraIntent() {
        try {
            val cacheDir = File(context.cacheDir, "camera_temp").apply { mkdirs() }
            val file = File(cacheDir, "temp_capture_${System.currentTimeMillis()}.jpg")
            tempCameraFile = file
            val authority = "${context.packageName}.fileprovider"
            val uri = FileProvider.getUriForFile(context, authority, file)
            cameraLauncher.launch(uri)
        } catch (e: Exception) {
            Toast.makeText(context, "Error opening camera: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    // Permission launcher for camera
    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            launchCameraIntent()
        } else {
            Toast.makeText(context, permissionMsg, Toast.LENGTH_SHORT).show()
        }
    }

    fun requestCameraAndLaunch() {
        try {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                launchCameraIntent()
            } else {
                cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
            }
        } catch (e: Exception) {
            Toast.makeText(context, "Camera permission error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    // Gallery launcher
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        try {
            if (uri != null) {
                selectedImageUri = uri
            }
        } catch (e: Exception) {
            Toast.makeText(context, "Gallery selection error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun resetDialogForm() {
        selectedImageUri = null
        tempCameraFile = null
        caption = ""
        dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        linkedType = "None"
        selectedOwnerId = ""
        selectedWorkerId = ""
        showAttachDialog = false
    }

    fun savePhotoToInternalStorage() {
        val uri = selectedImageUri ?: return
        if (caption.trim().isEmpty()) return

        try {
            // 1. Create permanent directory in app's internal filesDir
            val imagesDir = File(context.filesDir, "photos").apply { mkdirs() }
            val destFile = File(imagesDir, "photo_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}.jpg")

            // 2. Copy image stream to internal storage so it persists even if deleted from gallery
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(destFile).use { output ->
                    input.copyTo(output)
                }
            } ?: run {
                if (uri.path != null) {
                    val src = File(uri.path!!)
                    if (src.exists()) {
                        src.copyTo(destFile, overwrite = true)
                    }
                }
            }

            // 3. Resolve linked entity name
            var linkedId = ""
            var linkedName = ""
            if (linkedType == "Owner") {
                val owner = allOwners.find { it.id == selectedOwnerId }
                if (owner != null) {
                    linkedId = owner.id
                    linkedName = "${owner.name} (${owner.code})"
                }
            } else if (linkedType == "Labour") {
                val worker = allProfiles.find { it.id == selectedWorkerId }
                if (worker != null) {
                    linkedId = worker.id
                    linkedName = worker.name
                }
            }

            // 4. Save entity into Room database with internal file path
            val photoEntity = PhotoRecordEntity(
                id = "photo-${UUID.randomUUID()}",
                filePath = destFile.absolutePath,
                caption = caption.trim(),
                date = dateStr.trim().ifEmpty { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) },
                linkedType = linkedType,
                linkedId = linkedId,
                linkedName = linkedName,
                createdAt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).format(Date())
            )

            viewModel.savePhoto(photoEntity)
            Toast.makeText(context, toastSaved, Toast.LENGTH_SHORT).show()
            resetDialogForm()
        } catch (e: Exception) {
            Toast.makeText(context, "Failed to save photo: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.title_site_photos), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                        showAttachDialog = true
                    }) {
                        Icon(Icons.Default.Add, contentDescription = stringResource(R.string.btn_attach_photo))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = PrimaryBrownDark,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                    showAttachDialog = true
                },
                containerColor = Color(0xFF0F766E),
                contentColor = Color.White,
                icon = { Icon(Icons.Default.CameraAlt, contentDescription = null) },
                text = { Text(stringResource(R.string.btn_attach_photo), fontWeight = FontWeight.Bold) }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(NotebookPaper)
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(R.string.photos_header),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextMuted,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "${photos.size} Photos",
                    fontSize = 11.sp,
                    color = TextMuted
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (photos.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.CameraAlt, contentDescription = null, tint = TextMuted, modifier = Modifier.size(54.dp))
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(stringResource(R.string.no_photos_yet), color = TextMuted, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(14.dp))
                        Button(
                            onClick = {
                                dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                                showAttachDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F766E)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(stringResource(R.string.btn_attach_photo), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(photos, key = { it.id }) { photo ->
                        Card(
                            shape = RoundedCornerShape(14.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewingPhoto = photo }
                        ) {
                            Column {
                                SafePhotoThumbnail(
                                    filePath = photo.safeFilePath,
                                    contentDescription = photo.safeCaption,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(140.dp)
                                        .clip(RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp)),
                                    contentScale = ContentScale.Crop
                                )
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        text = photo.safeCaption.ifEmpty { "Work Photo" },
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = TextDark,
                                        maxLines = 1
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = photo.safeDate,
                                            fontSize = 11.sp,
                                            color = TextMuted
                                        )
                                        if (photo.safeLinkedName.isNotEmpty()) {
                                            Surface(
                                                color = AmberLight,
                                                shape = RoundedCornerShape(4.dp)
                                            ) {
                                                Text(
                                                    text = photo.safeLinkedName,
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = PrimaryBrown,
                                                    maxLines = 1,
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // DIALOG: Attach Photo or Receipt (Two Buttons: Camera & Gallery, No URL Field)
    if (showAttachDialog) {
        AlertDialog(
            onDismissRequest = { resetDialogForm() },
            title = {
                Text(
                    text = stringResource(R.string.btn_attach_photo),
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Two Buttons: "Take Photo" & "Choose from Gallery"
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { requestCameraAndLaunch() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F766E)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(stringResource(R.string.btn_take_photo), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                try {
                                    galleryLauncher.launch("image/*")
                                } catch (e: Exception) {
                                    Toast.makeText(context, "Error opening gallery: ${e.message}", Toast.LENGTH_SHORT).show()
                                }
                            },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(stringResource(R.string.btn_choose_gallery), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Thumbnail Preview of Selected Image
                    if (selectedImageUri != null) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, BorderLight),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(130.dp)
                        ) {
                            AsyncImage(
                                model = ImageRequest.Builder(context)
                                    .data(selectedImageUri)
                                    .crossfade(true)
                                    .placeholder(R.drawable.ic_photo_placeholder)
                                    .error(R.drawable.ic_photo_error)
                                    .build(),
                                contentDescription = "Preview",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop,
                                placeholder = painterResource(R.drawable.ic_photo_placeholder),
                                error = painterResource(R.drawable.ic_photo_error)
                            )
                        }
                    } else {
                        Surface(
                            color = NotebookPaperDark,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(80.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = "Tap Camera or Gallery button above to capture/pick image",
                                    fontSize = 11.sp,
                                    color = TextMuted
                                )
                            }
                        }
                    }

                    // Caption Field
                    OutlinedTextField(
                        value = caption,
                        onValueChange = { caption = it },
                        label = { Text(stringResource(R.string.lbl_photo_caption)) },
                        placeholder = { Text(stringResource(R.string.hint_photo_caption)) },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Date Field
                    OutlinedTextField(
                        value = dateStr,
                        onValueChange = { dateStr = it },
                        label = { Text("Date (YYYY-MM-DD)") },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Link to Owner or Worker (Optional)
                    Text(stringResource(R.string.lbl_link_to_optional), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextDark)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilterChip(
                            selected = linkedType == "None",
                            onClick = { linkedType = "None" },
                            label = { Text(stringResource(R.string.link_none), fontSize = 10.sp) }
                        )
                        FilterChip(
                            selected = linkedType == "Owner",
                            onClick = {
                                linkedType = "Owner"
                                if (selectedOwnerId.isEmpty() && allOwners.isNotEmpty()) {
                                    selectedOwnerId = allOwners.first().id
                                }
                            },
                            label = { Text(stringResource(R.string.link_owner), fontSize = 10.sp) }
                        )
                        FilterChip(
                            selected = linkedType == "Labour",
                            onClick = {
                                linkedType = "Labour"
                                if (selectedWorkerId.isEmpty() && allProfiles.isNotEmpty()) {
                                    selectedWorkerId = allProfiles.first().id
                                }
                            },
                            label = { Text(stringResource(R.string.link_worker), fontSize = 10.sp) }
                        )
                    }

                    if (linkedType == "Owner" && allOwners.isNotEmpty()) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Text(stringResource(R.string.lbl_pick_owner), fontSize = 11.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            LazyRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                items(allOwners) { o ->
                                    FilterChip(
                                        selected = selectedOwnerId == o.id,
                                        onClick = { selectedOwnerId = o.id },
                                        label = { Text("${o.name} (${o.code})", fontSize = 10.sp) }
                                    )
                                }
                            }
                        }
                    } else if (linkedType == "Labour" && allProfiles.isNotEmpty()) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Text(stringResource(R.string.lbl_pick_labour), fontSize = 11.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            LazyRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                items(allProfiles) { w ->
                                    FilterChip(
                                        selected = selectedWorkerId == w.id,
                                        onClick = { selectedWorkerId = w.id },
                                        label = { Text("${w.name} - ${w.role}", fontSize = 10.sp) }
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { savePhotoToInternalStorage() },
                    enabled = selectedImageUri != null && caption.trim().isNotEmpty(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F766E)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(stringResource(R.string.btn_save))
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { resetDialogForm() }, shape = RoundedCornerShape(10.dp)) {
                    Text(stringResource(R.string.btn_cancel))
                }
            }
        )
    }

    // FULL-SCREEN PHOTO VIEWER DIALOG
    if (viewingPhoto != null) {
        val photo = viewingPhoto!!
        Dialog(
            onDismissRequest = { viewingPhoto = null },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.94f))
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Top Bar inside viewer
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { viewingPhoto = null }) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                        }

                        IconButton(
                            onClick = {
                                deletingPhoto = photo
                            }
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFF87171))
                        }
                    }

                    // Main Image (Large Display)
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        SafePhotoThumbnail(
                            filePath = photo.safeFilePath,
                            contentDescription = photo.safeCaption,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp)),
                            contentScale = ContentScale.Fit
                        )
                    }

                    // Bottom info sheet inside viewer
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.15f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = photo.safeCaption.ifEmpty { "Work Photo" },
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Date: ${photo.safeDate}",
                                    color = Color.White.copy(alpha = 0.75f),
                                    fontSize = 12.sp
                                )
                                if (photo.safeLinkedName.isNotEmpty()) {
                                    Surface(
                                        color = AmberGold,
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = "Linked: ${photo.safeLinkedName}",
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // DELETE PHOTO CONFIRMATION DIALOG
    if (deletingPhoto != null) {
        val target = deletingPhoto!!
        AlertDialog(
            onDismissRequest = { deletingPhoto = null },
            title = { Text(stringResource(R.string.title_delete_photo_confirm), fontWeight = FontWeight.Bold) },
            text = { Text(stringResource(R.string.msg_delete_photo_confirm)) },
            confirmButton = {
                Button(
                    onClick = {
                        try {
                            val f = File(target.safeFilePath)
                            if (f.exists()) {
                                f.delete()
                            }
                        } catch (_: Exception) {}
                        try {
                            viewModel.deletePhoto(target.id)
                        } catch (e: Exception) {
                            Toast.makeText(context, "Error deleting: ${e.message}", Toast.LENGTH_SHORT).show()
                        }
                        Toast.makeText(context, toastDeleted, Toast.LENGTH_SHORT).show()
                        deletingPhoto = null
                        if (viewingPhoto?.id == target.id) {
                            viewingPhoto = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                ) {
                    Text(stringResource(R.string.btn_delete))
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { deletingPhoto = null }) {
                    Text(stringResource(R.string.btn_cancel))
                }
            }
        )
    }
}
