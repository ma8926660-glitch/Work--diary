package com.myworkdiary.app.data.local.entities

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "owners",
    indices = [Index(value = ["code"], unique = true)]
)
data class OwnerEntity(
    @PrimaryKey
    val id: String = "",
    val name: String = "",
    val code: String = "", // Unique code word (case-insensitive lookup, e.g. HB01)
    val createdAt: String = ""
)
