# Proguard Rules for My Work Diary Release Build
-keepattributes *Annotation*
-keepattributes Signature
-keepattributes InnerClasses

# Room Database
-keep class * extends androidx.room.RoomDatabase
-dontwarn androidx.room.paging.**

# Gson
-keepattributes EnclosingMethod
-keepclassmembers class * {
    @com.google.gson.annotations.SerializedName <fields>;
}
-keep class com.myworkdiary.app.data.local.entities.** { *; }
-keep class com.myworkdiary.app.model.** { *; }

# Coil
-dontwarn coil.**
