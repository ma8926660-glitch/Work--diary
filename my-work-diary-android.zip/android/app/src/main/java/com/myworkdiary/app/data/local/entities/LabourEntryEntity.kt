package com.myworkdiary.app.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "labour_entries")
data class LabourEntryEntity(
    @PrimaryKey
    val id: String,
    val dayId: String,
    val date: String,
    val project: String,
    val location: String = "",
    val workerId: String = "",
    val workerName: String,
    val workerType: String = "Plumber",
    val workPerformed: String,
    val dailyPayment: Double,
    val advancePayment: Double = 0.0,
    val remainingPayment: Double = 0.0,
    val status: String = "Paid", // "Paid", "Partially Paid", "Unpaid"
    val paid: Boolean = true,
    val category: String = "Labour", // "Labour", "Material", "Other Expense"
    val paymentKind: String? = null, // "Daily Wage", "Advance", "Previous Balance", "Other"
    val linkedPaymentId: String? = null,
    val notes: String = "",
    val photoUrl: String? = null,
    val photosJson: String = "[]" // Serialized list of photos with captions
)
