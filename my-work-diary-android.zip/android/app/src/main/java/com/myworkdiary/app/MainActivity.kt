package com.myworkdiary.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.myworkdiary.app.ui.navigation.Screen
import com.myworkdiary.app.ui.screens.*
import com.myworkdiary.app.ui.theme.MyWorkDiaryTheme
import com.myworkdiary.app.viewmodel.DiaryViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: DiaryViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        // Install modern Android 12+ Splash Screen
        installSplashScreen()
        super.onCreate(savedInstanceState)

        setContent {
            MyWorkDiaryTheme {
                val navController = rememberNavController()

                NavHost(
                    navController = navController,
                    startDestination = Screen.Home.route
                ) {
                    // 1. Home Hub
                    composable(Screen.Home.route) {
                        HomeScreen(
                            viewModel = viewModel,
                            onNavigate = { route -> navController.navigate(route) }
                        )
                    }

                    // 2. Daily Notebook Screen
                    composable(Screen.DailyNotebook.route) {
                        DailyNotebookScreen(
                            viewModel = viewModel,
                            onNavigateToAddLine = { _ ->
                                navController.navigate(Screen.AddTodayWork.route)
                            },
                            onOpenWorkerProfile = { workerName ->
                                navController.navigate(Screen.LabourDetail.createRoute(workerName))
                            },
                            onOpenProjectAccount = { projectName ->
                                navController.navigate(Screen.ProjectAccount.createRoute(projectName))
                            },
                            onOpenClientPayments = {
                                navController.navigate(Screen.ClientPayments.route)
                            }
                        )
                    }

                    // 3. Add Today's Work Screen
                    composable(Screen.AddTodayWork.route) {
                        AddTodayWorkScreen(
                            viewModel = viewModel,
                            dayId = null,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    // 4. Labour Profiles & Attendance
                    composable(Screen.LabourProfiles.route) {
                        LabourProfilesScreen(
                            viewModel = viewModel,
                            onBack = { navController.popBackStack() },
                            onOpenWorkerLedger = { workerName ->
                                navController.navigate(Screen.LabourDetail.createRoute(workerName))
                            }
                        )
                    }

                    // 5. Worker Ledger & Transaction Detail
                    composable(
                        route = Screen.LabourDetail.route,
                        arguments = listOf(navArgument("workerName") { type = NavType.StringType })
                    ) { backStackEntry ->
                        val workerName = backStackEntry.arguments?.getString("workerName") ?: ""
                        LabourDetailScreen(
                            viewModel = viewModel,
                            workerName = workerName,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    // 6. 💰 Client Payments Received Screen
                    composable(Screen.ClientPayments.route) {
                        ClientPaymentsScreen(
                            viewModel = viewModel,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    // 7. Project Account & Financials
                    composable(
                        route = Screen.ProjectAccount.route,
                        arguments = listOf(navArgument("projectName") { type = NavType.StringType })
                    ) { backStackEntry ->
                        val projectName = backStackEntry.arguments?.getString("projectName") ?: ""
                        ProjectAccountScreen(
                            viewModel = viewModel,
                            projectName = projectName,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    // 8. Payment Records
                    composable(Screen.Payments.route) {
                        PaymentRecordsScreen(
                            viewModel = viewModel,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    // 9. Work Records
                    composable(Screen.WorkRecords.route) {
                        WorkRecordsScreen(
                            viewModel = viewModel,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    // 10. Site Photos & Receipts
                    composable(Screen.Photos.route) {
                        PhotosScreen(
                            viewModel = viewModel,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    // 11. Instant Search
                    composable(Screen.Search.route) {
                        SearchScreen(
                            viewModel = viewModel,
                            onBack = { navController.popBackStack() },
                            onOpenNotebookDay = { dayId ->
                                viewModel.selectDayId(dayId)
                                navController.navigate(Screen.DailyNotebook.route)
                            }
                        )
                    }

                    // 12. Monthly Summary
                    composable(Screen.Summary.route) {
                        MonthlySummaryScreen(
                            viewModel = viewModel,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    // 13. Offline Backup & Restore
                    composable(Screen.Backup.route) {
                        BackupScreen(
                            viewModel = viewModel,
                            onBack = { navController.popBackStack() }
                        )
                    }
                }
            }
        }
    }
}
