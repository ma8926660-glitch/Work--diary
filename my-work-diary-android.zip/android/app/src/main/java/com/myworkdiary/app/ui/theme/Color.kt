package com.myworkdiary.app.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryBrown = Color(0xFF5C2E14)
val PrimaryBrownDark = Color(0xFF3D1E0D)
val AmberGold = Color(0xFFD97706)
val AmberLight = Color(0xFFFEF3C7)
val EmeraldGreen = Color(0xFF047857)
val EmeraldDark = Color(0xFF064E3B)
val EmeraldLight = Color(0xFFD1FAE5)
val RoseDark = Color(0xFFBE123C)
val RoseLight = Color(0xFFFFE4E6)
val NotebookPaper = Color(0xFFFAF7EF)
val NotebookPaperDark = Color(0xFFEDE4D0)
val TextDark = Color(0xFF1C1917)
val TextMuted = Color(0xFF78716C)
val BorderLight = Color(0xFFE7E0D3)
