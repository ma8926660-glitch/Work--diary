package com.myworkdiary.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.myworkdiary.app.ui.theme.*
import com.myworkdiary.app.viewmodel.DiaryViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkRecordsScreen(
    viewModel: DiaryViewModel,
    onBack: () -> Unit
) {
    val workEntries by viewModel.allWorkEntries.collectAsState()
    val labourEntries by viewModel.allLabourEntries.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("🔧 Work Records", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = PrimaryBrownDark,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(NotebookPaper)
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Text(
                    text = "RECORDED SITE WORK JOBS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextMuted,
                    letterSpacing = 1.sp
                )
            }

            if (labourEntries.isEmpty() && workEntries.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                        Text("No site jobs logged yet.", color = TextMuted)
                    }
                }
            }

            items(labourEntries) { entry ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Build, contentDescription = null, tint = PrimaryBrown, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(entry.workDescription.ifBlank { "General Work" }, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("Worker: ${entry.workerName} · ${entry.date}", fontSize = 12.sp, color = TextMuted)
                                if (entry.project.isNotBlank()) {
                                    Text("Site: ${entry.project}", fontSize = 11.sp, color = AmberGold)
                                }
                            }
                        }
                        Text("Rs. ${entry.dailyPayment.toInt()}", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = TextDark)
                    }
                }
            }
        }
    }
}
