package com.myworkdiary.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.myworkdiary.app.ui.theme.*
import com.myworkdiary.app.viewmodel.DiaryViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
    viewModel: DiaryViewModel,
    onBack: () -> Unit,
    onOpenNotebookDay: (String) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val allDays by viewModel.allDays.collectAsState()
    val allLabour by viewModel.allLabourEntries.collectAsState()
    val allClientPayments by viewModel.allClientPayments.collectAsState()

    val filteredDays = remember(query, allDays) {
        if (query.isBlank()) emptyList()
        else allDays.filter {
            it.date.contains(query, ignoreCase = true) ||
                    it.project.contains(query, ignoreCase = true) ||
                    it.generalNotes.contains(query, ignoreCase = true) ||
                    it.location.contains(query, ignoreCase = true)
        }
    }

    val filteredLabour = remember(query, allLabour) {
        if (query.isBlank()) emptyList()
        else allLabour.filter {
            it.workerName.contains(query, ignoreCase = true) ||
                    it.workDescription.contains(query, ignoreCase = true) ||
                    it.project.contains(query, ignoreCase = true) ||
                    it.date.contains(query, ignoreCase = true)
        }
    }

    val filteredClient = remember(query, allClientPayments) {
        if (query.isBlank()) emptyList()
        else allClientPayments.filter {
            it.clientName.contains(query, ignoreCase = true) ||
                    it.project.contains(query, ignoreCase = true) ||
                    it.paymentMethod.contains(query, ignoreCase = true) ||
                    it.referenceId.contains(query, ignoreCase = true)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("🔍 Search Diary", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = PrimaryBrownDark,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(NotebookPaper)
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Search dates, workers, projects, notes...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextMuted) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White
                )
            )

            if (query.isBlank()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Type any worker name, project, date or note above to search.", color = TextMuted)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Labour Results
                    if (filteredLabour.isNotEmpty()) {
                        item {
                            Text("WORKERS & LABOUR (${filteredLabour.size})", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = TextMuted)
                        }
                        items(filteredLabour) { item ->
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onOpenNotebookDay(item.dayId) }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(item.workerName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Text("${item.workDescription} · ${item.date}", fontSize = 12.sp, color = TextMuted)
                                        if (item.project.isNotBlank()) {
                                            Text(item.project, fontSize = 11.sp, color = AmberGold)
                                        }
                                    }
                                    Text("Rs. ${item.dailyPayment.toInt()}", fontWeight = FontWeight.Bold, color = TextDark)
                                }
                            }
                        }
                    }

                    // Client Payments Results
                    if (filteredClient.isNotEmpty()) {
                        item {
                            Text("CLIENT PAYMENTS (${filteredClient.size})", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = TextMuted)
                        }
                        items(filteredClient) { item ->
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("Client: ${item.clientName}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Text("${item.project} · ${item.date} (${item.paymentMethod})", fontSize = 12.sp, color = TextMuted)
                                    }
                                    Text("Rs. ${item.amount.toInt()}", fontWeight = FontWeight.Bold, color = EmeraldGreen)
                                }
                            }
                        }
                    }

                    // Diary Pages Results
                    if (filteredDays.isNotEmpty()) {
                        item {
                            Text("DIARY PAGES (${filteredDays.size})", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = TextMuted)
                        }
                        items(filteredDays) { day ->
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onOpenNotebookDay(day.id) }
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(day.date, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text(day.project, fontSize = 12.sp, color = AmberGold)
                                    if (day.generalNotes.isNotBlank()) {
                                        Text(day.generalNotes, fontSize = 11.sp, color = TextMuted)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
