package com.myworkdiary.app.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "project_contracts")
data class ProjectContractEntity(
    @PrimaryKey
    val projectName: String,
    val contractAmount: Double
)
