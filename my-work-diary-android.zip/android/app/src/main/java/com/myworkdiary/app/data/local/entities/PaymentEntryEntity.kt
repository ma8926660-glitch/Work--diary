package com.myworkdiary.app.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "payments")
data class PaymentEntryEntity(
    @PrimaryKey
    val id: String,
    val date: String,
    val workerId: String = "",
    val workerName: String,
    val amount: Double,
    val paymentType: String = "Cash", // Cash, Bank, Online/UPI, Cheque, Other
    val paymentKind: String = "Daily Wage", // Daily Wage, Advance, Previous Balance, Other
    val category: String = "Labour", // Labour, Material, Other Expense
    val isAdvance: Boolean = false,
    val reason: String = "",
    val notes: String = "",
    val receiptPhoto: String? = null,
    val project: String = "",
    val linkedWorkLineId: String? = null // Prevents double counting
)
