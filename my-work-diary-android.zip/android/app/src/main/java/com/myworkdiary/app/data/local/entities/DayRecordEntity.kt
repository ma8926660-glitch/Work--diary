package com.myworkdiary.app.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "days")
data class DayRecordEntity(
    @PrimaryKey
    val id: String,
    val date: String, // YYYY-MM-DD
    val dayName: String,
    val project: String,
    val customerName: String = "",
    val location: String = "",
    val generalNotes: String = "",
    val createdAt: String = "",
    val updatedAt: String = ""
)
