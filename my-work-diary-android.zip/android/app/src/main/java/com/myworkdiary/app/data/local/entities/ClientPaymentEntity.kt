package com.myworkdiary.app.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "client_payments")
data class ClientPaymentEntity(
    @PrimaryKey
    val id: String,
    val project: String,
    val clientName: String,
    val date: String,
    val amount: Double,
    val paymentMethod: String = "Bank Transfer", // Bank Transfer, Easypaisa, JazzCash, Cash, Other
    val referenceId: String? = null,
    val notes: String? = null,
    val screenshotUrl: String? = null,
    val createdAt: String = ""
)
