package com.myworkdiary.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.myworkdiary.app.data.local.entities.DayRecordEntity
import com.myworkdiary.app.data.local.entities.LabourEntryEntity
import com.myworkdiary.app.ui.theme.*
import com.myworkdiary.app.viewmodel.DiaryViewModel

@Composable
fun DailyNotebookScreen(
    viewModel: DiaryViewModel,
    onNavigateToAddLine: (String) -> Unit,
    onOpenWorkerProfile: (String) -> Unit,
    onOpenProjectAccount: (String) -> Unit,
    onOpenClientPayments: () -> Unit
) {
    val days by viewModel.filteredDays.collectAsState()
    val allLabour by viewModel.allLabourEntries.collectAsState()
    val allPayments by viewModel.allPayments.collectAsState()
    val allClientPayments by viewModel.allClientPayments.collectAsState()
    val selectedDayId by viewModel.selectedDayId.collectAsState()

    val currentDay = days.find { it.id == selectedDayId } ?: days.firstOrNull()

    if (currentDay == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No diary pages found. Tap + Add Today's Work to begin.")
        }
        return
    }

    val dayLabour = allLabour.filter { it.dayId == currentDay.id || it.date == currentDay.date }
    val dayPayments = allPayments.filter { it.date == currentDay.date }
    val dayClientPayments = allClientPayments.filter {
        it.date == currentDay.date && (it.project.equals(currentDay.project, ignoreCase = true))
    }

    val dailyTotals = viewModel.getDailyTotals(dayLabour, dayPayments)
    val dailyClientMoney = dayClientPayments.sumOf { it.amount }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(NotebookPaper)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. Notebook Page Header (Lined Paper Header)
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = androidx.compose.foundation.BorderStroke(2.dp, BorderLight),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "DATE: ${currentDay.date} (${currentDay.dayName})",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryBrown
                        )
                        Surface(
                            color = AmberLight,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "DAILY NOTEBOOK",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = PrimaryBrown,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "📍 Site: ${currentDay.project}",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextDark
                        )
                        TextButton(
                            onClick = { onOpenProjectAccount(currentDay.project) },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text("Site Account", fontSize = 11.sp, color = AmberGold, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (currentDay.location.isNotEmpty()) {
                        Text(
                            text = "Location: ${currentDay.location}",
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }

                    if (currentDay.generalNotes.isNotEmpty()) {
                        Text(
                            text = "\"${currentDay.generalNotes}\"",
                            fontSize = 12.sp,
                            color = TextMuted,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }
        }

        // 2. Table-like Header
        item {
            Surface(
                color = NotebookPaperDark,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "No.", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(28.dp))
                    Text(text = "Labour", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.2f))
                    Text(text = "Work Done", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.5f))
                    Text(text = "Amount", fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
                    Text(text = "Paid", fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.width(55.dp))
                }
            }
        }

        // 3. Line-by-Line Notebook Entries (Horizontal ruled line style)
        itemsIndexed(dayLabour) { index, entry ->
            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderLight),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "${index + 1}.", fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(28.dp))
                        Text(
                            text = entry.workerName,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryBrown,
                            modifier = Modifier
                                .weight(1.2f)
                                .clickable { onOpenWorkerProfile(entry.workerName) }
                        )
                        Text(text = entry.workPerformed, fontSize = 12.sp, color = TextDark, modifier = Modifier.weight(1.5f))
                        Text(
                            text = "Rs. ${entry.dailyPayment.toInt()}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.End,
                            modifier = Modifier.weight(1f)
                        )
                        Surface(
                            color = if (entry.paid) EmeraldLight else RoseLight,
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .width(55.dp)
                                .padding(start = 4.dp)
                        ) {
                            Text(
                                text = if (entry.paid) "Paid" else "Unpaid",
                                color = if (entry.paid) EmeraldDark else RoseDark,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(vertical = 2.dp)
                            )
                        }
                    }

                    if (entry.notes.isNotEmpty()) {
                        Text(
                            text = "Note: ${entry.notes}",
                            fontSize = 10.sp,
                            color = TextMuted,
                            modifier = Modifier.padding(start = 28.dp, top = 2.dp)
                        )
                    }
                }
            }
        }

        // 4. Large "+ Add Line" Button
        item {
            OutlinedButton(
                onClick = { onNavigateToAddLine(currentDay.id) },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Add, contentDescription = null, tint = AmberGold)
                Spacer(modifier = Modifier.width(6.dp))
                Text("+ Add Line", fontWeight = FontWeight.Bold, color = AmberGold)
            }
        }

        // 5. 💰 PAYMENTS RECEIVED TODAY SECTION
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = EmeraldLight.copy(alpha = 0.35f)),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, EmeraldGreen.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "💰 PAYMENTS RECEIVED TODAY",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldDark
                        )
                        TextButton(
                            onClick = { onOpenClientPayments() },
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text("+ Record Client ₹", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = EmeraldDark)
                        }
                    }

                    if (dayClientPayments.isEmpty()) {
                        Text(
                            text = "No client payments recorded for this site on ${currentDay.date}.",
                            fontSize = 11.sp,
                            color = TextMuted,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    } else {
                        dayClientPayments.forEach { cp ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(text = "Client Payment Received", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Text(text = "${cp.project} · ${cp.paymentMethod} (${cp.clientName})", fontSize = 10.sp, color = TextMuted)
                                }
                                Text(text = "Rs. ${cp.amount.toInt()}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = EmeraldDark)
                            }
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), color = EmeraldGreen.copy(alpha = 0.2f))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Daily Money Received:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = EmeraldDark)
                        Text(text = "Rs. ${dailyClientMoney.toInt()}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = EmeraldDark)
                    }
                }
            }
        }

        // 6. DAILY TOTAL BOXES (All 7 metrics)
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = NotebookPaperDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "DAILY TOTAL",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextDark,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        DailyTotalBox("Labour", "Rs. ${dailyTotals.labourWorkTotal.toInt()}", modifier = Modifier.weight(1f))
                        DailyTotalBox("Material", "Rs. ${dailyTotals.materialTotal.toInt()}", modifier = Modifier.weight(1f))
                        DailyTotalBox("Other Exp.", "Rs. ${dailyTotals.otherExpenses.toInt()}", modifier = Modifier.weight(1f))
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        DailyTotalBox("Paid Today", "Rs. ${dailyTotals.paidToday.toInt()}", valueColor = EmeraldDark, modifier = Modifier.weight(1f))
                        DailyTotalBox("Unpaid", "Rs. ${dailyTotals.unpaidToday.toInt()}", valueColor = RoseDark, modifier = Modifier.weight(1f))
                        DailyTotalBox("Advance", "Rs. ${dailyTotals.advancePaidToday.toInt()}", valueColor = AmberGold, modifier = Modifier.weight(1f))
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Surface(
                        color = PrimaryBrownDark,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Grand Total", color = AmberLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("Rs. ${dailyTotals.grandTotal.toInt()}", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DailyTotalBox(label: String, amount: String, modifier: Modifier = Modifier, valueColor: Color = TextDark) {
    Surface(
        color = Color.White,
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderLight),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = label, fontSize = 9.sp, color = TextMuted, fontWeight = FontWeight.Medium)
            Text(text = amount, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = valueColor, maxLines = 1)
        }
    }
}
