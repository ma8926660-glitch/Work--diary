package com.myworkdiary.app.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "work_entries")
data class WorkEntryEntity(
    @PrimaryKey
    val id: String,
    val dayId: String,
    val workName: String,
    val description: String = "",
    val date: String,
    val project: String = "",
    val workCost: Double = 0.0,
    val labourCost: Double = 0.0,
    val otherExpenses: Double = 0.0,
    val totalCost: Double = 0.0,
    val notes: String = ""
)
