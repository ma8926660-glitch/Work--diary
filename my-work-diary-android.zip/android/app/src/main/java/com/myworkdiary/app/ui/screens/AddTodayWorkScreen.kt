package com.myworkdiary.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.myworkdiary.app.data.local.entities.DayRecordEntity
import com.myworkdiary.app.data.local.entities.LabourEntryEntity
import com.myworkdiary.app.data.local.entities.PaymentEntryEntity
import com.myworkdiary.app.ui.theme.*
import com.myworkdiary.app.viewmodel.DiaryViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class ComposeWorkLineDraft(
    val id: String = UUID.randomUUID().toString(),
    var workerName: String = "",
    var workDone: String = "",
    var amountText: String = "",
    var paid: Boolean = true,
    var category: String = "Labour",
    var notes: String = ""
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTodayWorkScreen(
    viewModel: DiaryViewModel,
    dayId: String?,
    onBack: () -> Unit
) {
    val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    val dayNameStr = SimpleDateFormat("EEEE", Locale.getDefault()).format(Date())

    var date by remember { mutableStateOf(todayStr) }
    var project by remember { mutableStateOf("Green Valley Villa 42") }
    var location by remember { mutableStateOf("Plot 42, Block B") }
    var generalNotes by remember { mutableStateOf("") }

    val lines = remember {
        mutableStateListOf(
            ComposeWorkLineDraft(workerName = "Ahmed", workDone = "Bathroom fitting", amountText = "2500", paid = true),
            ComposeWorkLineDraft(workerName = "Ali", workDone = "Pipe fitting", amountText = "2000", paid = true),
            ComposeWorkLineDraft(workerName = "Imran", workDone = "Tile work", amountText = "1800", paid = false)
        )
    }

    var errorMessage by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("+ Add Today's Work", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    TextButton(
                        onClick = {
                            if (project.trim().isEmpty()) {
                                errorMessage = "Please enter project / site name."
                                return@TextButton
                            }

                            val newDayId = dayId ?: "day-$date"
                            val dayEntity = DayRecordEntity(
                                id = newDayId,
                                date = date,
                                dayName = dayNameStr,
                                project = project.trim(),
                                location = location.trim(),
                                generalNotes = generalNotes.trim()
                            )
                            viewModel.saveDay(dayEntity)

                            lines.forEachIndexed { idx, line ->
                                if (line.workerName.trim().isNotEmpty() || line.workDone.trim().isNotEmpty()) {
                                    val amt = line.amountText.toDoubleOrNull() ?: 0.0
                                    val payId = "pay-$date-$idx-${UUID.randomUUID().toString().take(4)}"
                                    val labourId = line.id

                                    val labourEntity = LabourEntryEntity(
                                        id = labourId,
                                        dayId = newDayId,
                                        date = date,
                                        project = project.trim(),
                                        workerName = line.workerName.trim().ifEmpty { "Worker" },
                                        workPerformed = line.workDone.trim().ifEmpty { "Site work" },
                                        dailyPayment = amt,
                                        status = if (line.paid) "Paid" else "Unpaid",
                                        paid = line.paid,
                                        category = line.category,
                                        linkedPaymentId = if (line.paid && amt > 0) payId else null,
                                        notes = line.notes.trim()
                                    )
                                    viewModel.saveLabourEntry(labourEntity)

                                    // Automatically record payment if paid to prevent double counting
                                    if (line.paid && amt > 0) {
                                        val payment = PaymentEntryEntity(
                                            id = payId,
                                            date = date,
                                            workerName = line.workerName.trim().ifEmpty { "Worker" },
                                            amount = amt,
                                            paymentType = "Cash",
                                            paymentKind = "Daily Wage",
                                            category = line.category,
                                            reason = line.workDone.trim().ifEmpty { "Daily wage" },
                                            notes = line.notes.trim(),
                                            project = project.trim(),
                                            linkedWorkLineId = labourId
                                        )
                                        viewModel.savePayment(payment)
                                    }
                                }
                            }

                            onBack()
                        }
                    ) {
                        Text("SAVE DIARY", color = AmberLight, fontWeight = FontWeight.Bold)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = PrimaryBrownDark,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(NotebookPaper)
                .padding(padding)
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header Information (Date, Project, Location)
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (errorMessage.isNotEmpty()) {
                            Text(errorMessage, color = RoseDark, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = date,
                                onValueChange = { date = it },
                                label = { Text("Date (YYYY-MM-DD)") },
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = project,
                                onValueChange = { project = it },
                                label = { Text("Project / Site Name *") },
                                modifier = Modifier.weight(1.3f)
                            )
                        }

                        OutlinedTextField(
                            value = location,
                            onValueChange = { location = it },
                            label = { Text("Work Location / Plot") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = generalNotes,
                            onValueChange = { generalNotes = it },
                            label = { Text("General Day Notes") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "WORK ENTRIES (${lines.size} LINES)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextMuted
                    )
                }
            }

            // Multiple Line-by-Line Entries
            itemsIndexed(lines) { idx, line ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "Line #${idx + 1}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = PrimaryBrown)
                            if (lines.size > 1) {
                                IconButton(
                                    onClick = { lines.removeAt(idx) },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete Line", tint = RoseDark, modifier = Modifier.size(16.dp))
                                }
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(
                                value = line.workerName,
                                onValueChange = { line.workerName = it },
                                label = { Text("Labour Name") },
                                modifier = Modifier.weight(1.2f)
                            )
                            OutlinedTextField(
                                value = line.workDone,
                                onValueChange = { line.workDone = it },
                                label = { Text("Work Done") },
                                modifier = Modifier.weight(1.5f)
                            )
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = line.amountText,
                                onValueChange = { line.amountText = it },
                                label = { Text("Amount (Rs.)") },
                                modifier = Modifier.weight(1f)
                            )

                            FilterChip(
                                selected = line.paid,
                                onClick = { line.paid = !line.paid },
                                label = { Text(if (line.paid) "Paid" else "Unpaid") },
                                leadingIcon = {
                                    Icon(
                                        imageVector = if (line.paid) Icons.Default.Check else Icons.Default.Close,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp)
                                    )
                                },
                                modifier = Modifier.padding(top = 6.dp)
                            )
                        }

                        OutlinedTextField(
                            value = line.notes,
                            onValueChange = { line.notes = it },
                            label = { Text("Notes (optional)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            // Unlimited Lines "+ Add Line" button
            item {
                Button(
                    onClick = { lines.add(ComposeWorkLineDraft()) },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AmberGold),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("+ Add Another Line", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
