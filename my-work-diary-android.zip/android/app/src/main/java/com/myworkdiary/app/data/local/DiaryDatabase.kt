package com.myworkdiary.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.myworkdiary.app.data.local.dao.DiaryDao
import com.myworkdiary.app.data.local.entities.ClientPaymentEntity
import com.myworkdiary.app.data.local.entities.DayRecordEntity
import com.myworkdiary.app.data.local.entities.LabourEntryEntity
import com.myworkdiary.app.data.local.entities.LabourProfileEntity
import com.myworkdiary.app.data.local.entities.PaymentEntryEntity
import com.myworkdiary.app.data.local.entities.ProjectContractEntity
import com.myworkdiary.app.data.local.entities.WorkEntryEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        DayRecordEntity::class,
        LabourProfileEntity::class,
        LabourEntryEntity::class,
        WorkEntryEntity::class,
        PaymentEntryEntity::class,
        ClientPaymentEntity::class,
        ProjectContractEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class DiaryDatabase : RoomDatabase() {

    abstract fun diaryDao(): DiaryDao

    companion object {
        @Volatile
        private var INSTANCE: DiaryDatabase? = null

        fun getDatabase(context: Context): DiaryDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    DiaryDatabase::class.java,
                    "my_work_diary_db"
                )
                    .addCallback(DatabaseCallback())
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                // Seed initial data asynchronously
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        seedInitialData(database.diaryDao())
                    }
                }
            }

            private suspend fun seedInitialData(dao: DiaryDao) {
                // 1. Initial Profiles
                val profiles = listOf(
                    LabourProfileEntity(
                        id = "worker-ahmed",
                        name = "Ahmed",
                        category = "Plumber",
                        phone = "+92 300 1234567",
                        avatarType = "emoji",
                        avatarValue = "👨‍🔧",
                        dailyRate = 2500.0,
                        notes = "Master sanitary & concealed pipe fitting specialist. Very reliable."
                    ),
                    LabourProfileEntity(
                        id = "worker-ali",
                        name = "Ali",
                        category = "Tile Worker",
                        phone = "+92 302 9876543",
                        avatarType = "emoji",
                        avatarValue = "👷‍♂️",
                        dailyRate = 2000.0,
                        notes = "Expert pipe grooving and tile fitting worker."
                    ),
                    LabourProfileEntity(
                        id = "worker-tariq",
                        name = "Tariq Mason",
                        category = "Mason",
                        phone = "+92 333 4567890",
                        avatarType = "emoji",
                        avatarValue = "🧱",
                        dailyRate = 2200.0,
                        notes = "Brick masonry, plaster and wall chipping specialist."
                    ),
                    LabourProfileEntity(
                        id = "worker-kamran",
                        name = "Kamran",
                        category = "Helper",
                        phone = "+92 312 3456781",
                        avatarType = "emoji",
                        avatarValue = "🦺",
                        dailyRate = 1200.0,
                        notes = "Site cleaning, material shifting and plumbing helper."
                    )
                )
                dao.insertProfiles(profiles)

                // 2. Initial Days
                val days = listOf(
                    DayRecordEntity(
                        id = "day-2026-10-09",
                        date = "2026-10-09",
                        dayName = "Friday",
                        project = "Green Valley Villa 42",
                        customerName = "Mr. Hashim (Villa 42)",
                        location = "Plot 42, Block B, Green Valley",
                        generalNotes = "Given Rs. 1,000 cash advance to Ahmed for upcoming fittings and tested bathroom pressure."
                    ),
                    DayRecordEntity(
                        id = "day-2026-10-08",
                        date = "2026-10-08",
                        dayName = "Thursday",
                        project = "Green Valley Villa 42",
                        customerName = "Mr. Hashim (Villa 42)",
                        location = "Plot 42, Block B, Green Valley",
                        generalNotes = "Kitchen sink pipe fitting and tile cutting work underway."
                    ),
                    DayRecordEntity(
                        id = "day-2026-10-07",
                        date = "2026-10-07",
                        dayName = "Wednesday",
                        project = "Green Valley Villa 42",
                        customerName = "Mr. Hashim (Villa 42)",
                        location = "Plot 42, Block B, Green Valley",
                        generalNotes = "Started master bathroom concealed fitting and pipe rough-in."
                    )
                )
                dao.insertDays(days)

                // 3. Initial Labour Entries
                val labourEntries = listOf(
                    LabourEntryEntity(
                        id = "labour-1",
                        dayId = "day-2026-10-07",
                        date = "2026-10-07",
                        project = "Green Valley Villa 42",
                        workerId = "worker-ahmed",
                        workerName = "Ahmed",
                        workerType = "Plumber",
                        workPerformed = "Bathroom fitting",
                        dailyPayment = 2500.0,
                        status = "Paid",
                        paid = true,
                        category = "Labour",
                        paymentKind = "Daily Wage",
                        linkedPaymentId = "pay-1",
                        notes = "Bathroom concealed fitting completed with spirit level inspection."
                    ),
                    LabourEntryEntity(
                        id = "labour-ahmed-08",
                        dayId = "day-2026-10-08",
                        date = "2026-10-08",
                        project = "Green Valley Villa 42",
                        workerId = "worker-ahmed",
                        workerName = "Ahmed",
                        workerType = "Plumber",
                        workPerformed = "Pipe fitting",
                        dailyPayment = 2000.0,
                        status = "Paid",
                        paid = true,
                        category = "Labour",
                        paymentKind = "Daily Wage",
                        linkedPaymentId = "pay-ahmed-08",
                        notes = "Main pipe fitting and wall grooving completed."
                    ),
                    LabourEntryEntity(
                        id = "labour-2",
                        dayId = "day-2026-10-07",
                        date = "2026-10-07",
                        project = "Green Valley Villa 42",
                        workerId = "worker-ali",
                        workerName = "Ali",
                        workerType = "Plumber",
                        workPerformed = "Pipe fitting",
                        dailyPayment = 2000.0,
                        status = "Paid",
                        paid = true,
                        category = "Labour",
                        paymentKind = "Daily Wage",
                        linkedPaymentId = "pay-2",
                        notes = "Waste pipe sloping and joint welding completed."
                    ),
                    LabourEntryEntity(
                        id = "labour-3",
                        dayId = "day-2026-10-07",
                        date = "2026-10-07",
                        project = "Green Valley Villa 42",
                        workerId = "worker-tariq",
                        workerName = "Imran",
                        workerType = "Tile Worker",
                        workPerformed = "Tile work",
                        dailyPayment = 1800.0,
                        status = "Unpaid",
                        paid = false,
                        category = "Labour",
                        notes = "Floor tile alignment started."
                    )
                )
                dao.insertLabourEntries(labourEntries)

                // 4. Initial Payments
                val payments = listOf(
                    PaymentEntryEntity(
                        id = "pay-1",
                        date = "2026-10-07",
                        workerName = "Ahmed",
                        amount = 2500.0,
                        paymentType = "Cash",
                        paymentKind = "Daily Wage",
                        category = "Labour",
                        reason = "Bathroom fitting",
                        notes = "Daily wage payment on completion",
                        project = "Green Valley Villa 42",
                        linkedWorkLineId = "labour-1"
                    ),
                    PaymentEntryEntity(
                        id = "pay-ahmed-08",
                        date = "2026-10-08",
                        workerName = "Ahmed",
                        amount = 2000.0,
                        paymentType = "Cash",
                        paymentKind = "Daily Wage",
                        category = "Labour",
                        reason = "Pipe fitting",
                        notes = "Full day settlement",
                        project = "Green Valley Villa 42",
                        linkedWorkLineId = "labour-ahmed-08"
                    ),
                    PaymentEntryEntity(
                        id = "pay-ahmed-adv-09",
                        date = "2026-10-09",
                        workerName = "Ahmed",
                        amount = 1000.0,
                        paymentType = "Cash",
                        paymentKind = "Advance",
                        category = "Labour",
                        isAdvance = true,
                        reason = "Advance",
                        notes = "Advance given for weekly family expense",
                        project = "Green Valley Villa 42"
                    )
                )
                dao.insertPayments(payments)

                // 5. Initial Client Payments (Money Received from Client)
                val clientPayments = listOf(
                    ClientPaymentEntity(
                        id = "client-pay-1",
                        project = "Green Valley Villa 42",
                        clientName = "Mr. Hashim (Villa 42)",
                        date = "2026-10-07",
                        amount = 30000.0,
                        paymentMethod = "Bank Transfer",
                        referenceId = "HBL-9812401",
                        notes = "First advance installment received for concealed sanitary fitting."
                    ),
                    ClientPaymentEntity(
                        id = "client-pay-2",
                        project = "Green Valley Villa 42",
                        clientName = "Mr. Hashim (Villa 42)",
                        date = "2026-10-09",
                        amount = 20000.0,
                        paymentMethod = "Cash",
                        referenceId = "CASH-SITE-01",
                        notes = "Second progress installment paid on site for kitchen and bathroom plumbing."
                    )
                )
                dao.insertClientPayments(clientPayments)

                // 6. Initial Project Contract
                dao.insertContract(
                    ProjectContractEntity(
                        projectName = "Green Valley Villa 42",
                        contractAmount = 200000.0
                    )
                )
            }
        }
    }
}
