package com.myworkdiary.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.myworkdiary.app.data.local.entities.ClientPaymentEntity
import com.myworkdiary.app.ui.theme.*
import com.myworkdiary.app.viewmodel.DiaryViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClientPaymentsScreen(
    viewModel: DiaryViewModel,
    onBack: () -> Unit
) {
    val clientPayments by viewModel.filteredClientPayments.collectAsState()
    val allDays by viewModel.allDays.collectAsState()
    val currentProject by viewModel.currentProject.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }
    var editingPayment by remember { mutableStateOf<ClientPaymentEntity?>(null) }
    var deleteConfirmPayment by remember { mutableStateOf<ClientPaymentEntity?>(null) }

    val totalReceived = clientPayments.sumOf { it.amount }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("💰 Client Payments", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        editingPayment = null
                        showAddDialog = true
                    }) {
                        Icon(Icons.Default.Add, contentDescription = "Add Payment")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = EmeraldDark,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    editingPayment = null
                    showAddDialog = true
                },
                containerColor = EmeraldGreen,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Client Payment")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(NotebookPaper)
                .padding(padding)
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Summary Card
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = EmeraldDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "TOTAL CLIENT MONEY RECEIVED",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldLight
                        )
                        Text(
                            text = "Rs. ${totalReceived.toInt()}",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Site: $currentProject · ${clientPayments.size} Transactions",
                            fontSize = 11.sp,
                            color = EmeraldLight.copy(alpha = 0.8f)
                        )
                    }
                }
            }

            if (clientPayments.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("No client payments recorded yet.", color = TextMuted)
                    }
                }
            } else {
                items(clientPayments) { cp ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = androidx.compose.foundation.BorderStroke(1.dp, BorderLight),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Top
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(text = cp.date, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PrimaryBrown)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Surface(
                                            color = EmeraldLight,
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Text(
                                                text = cp.paymentMethod,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = EmeraldDark,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(text = "Site: ${cp.project}", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    Text(text = "Client: ${cp.clientName}", fontSize = 11.sp, color = TextMuted)
                                }

                                Text(
                                    text = "Rs. ${cp.amount.toInt()}",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldDark
                                )
                            }

                            if (!cp.referenceId.isNullOrEmpty()) {
                                Text(
                                    text = "Ref/TID: ${cp.referenceId}",
                                    fontSize = 10.sp,
                                    color = TextMuted,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }

                            if (!cp.notes.isNullOrEmpty()) {
                                Text(
                                    text = "\"${cp.notes}\"",
                                    fontSize = 11.sp,
                                    color = TextDark,
                                    modifier = Modifier.padding(top = 2.dp)
                                )
                            }

                            HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp), color = BorderLight)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                TextButton(
                                    onClick = {
                                        editingPayment = cp
                                        showAddDialog = true
                                    },
                                    contentPadding = PaddingValues(horizontal = 8.dp)
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Edit", fontSize = 11.sp)
                                }
                                TextButton(
                                    onClick = { deleteConfirmPayment = cp },
                                    colors = ButtonDefaults.textButtonColors(contentColor = RoseDark),
                                    contentPadding = PaddingValues(horizontal = 8.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Delete", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Add / Edit Client Payment Dialog with Duplicate Warning & Manual Amount Confirmation
    if (showAddDialog) {
        val existingProjects = allDays.map { it.project }.distinct().ifEmpty { listOf("Green Valley Villa 42") }
        AddClientPaymentDialog(
            existingProjects = existingProjects,
            initialPayment = editingPayment,
            onDismiss = { showAddDialog = false },
            onSave = { payment, force ->
                if (!force && viewModel.isDuplicateClientPayment(payment.project, payment.date, payment.amount, payment.paymentMethod, editingPayment?.id)) {
                    // Handled inside dialog
                } else {
                    viewModel.saveClientPayment(payment)
                    showAddDialog = false
                }
            },
            checkDuplicate = { p, d, a, m ->
                viewModel.isDuplicateClientPayment(p, d, a, m, editingPayment?.id)
            }
        )
    }

    // Delete Confirmation Dialog
    deleteConfirmPayment?.let { cp ->
        AlertDialog(
            onDismissRequest = { deleteConfirmPayment = null },
            title = { Text("Delete Client Payment?") },
            text = { Text("Are you sure you want to delete payment of Rs. ${cp.amount.toInt()} from ${cp.clientName}? This will automatically recalculate all project totals.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteClientPayment(cp.id)
                        deleteConfirmPayment = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoseDark)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { deleteConfirmPayment = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddClientPaymentDialog(
    existingProjects: List<String>,
    initialPayment: ClientPaymentEntity?,
    onDismiss: () -> Unit,
    onSave: (ClientPaymentEntity, Boolean) -> Unit,
    checkDuplicate: (String, String, Double, String) -> Boolean
) {
    val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

    var project by remember { mutableStateOf(initialPayment?.project ?: existingProjects.firstOrNull() ?: "Green Valley Villa 42") }
    var clientName by remember { mutableStateOf(initialPayment?.clientName ?: "") }
    var date by remember { mutableStateOf(initialPayment?.date ?: todayStr) }
    var amountText by remember { mutableStateOf(initialPayment?.amount?.toInt()?.toString() ?: "") }
    var paymentMethod by remember { mutableStateOf(initialPayment?.paymentMethod ?: "Bank Transfer") }
    var referenceId by remember { mutableStateOf(initialPayment?.referenceId ?: "") }
    var notes by remember { mutableStateOf(initialPayment?.notes ?: "") }

    var showDuplicateWarning by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }

    val methods = listOf("Bank Transfer", "Easypaisa", "JazzCash", "Cash", "Other")

    if (showDuplicateWarning) {
        AlertDialog(
            onDismissRequest = { showDuplicateWarning = false },
            title = { Text("⚠️ Potential Duplicate Payment") },
            text = {
                Text("A payment of Rs. $amountText via $paymentMethod for project '$project' on $date already exists.\n\nThis may be a duplicate payment. Do you want to continue?")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDuplicateWarning = false
                        val finalPayment = ClientPaymentEntity(
                            id = initialPayment?.id ?: UUID.randomUUID().toString(),
                            project = project.trim(),
                            clientName = clientName.trim().ifEmpty { "Project Client" },
                            date = date,
                            amount = amountText.toDoubleOrNull() ?: 0.0,
                            paymentMethod = paymentMethod,
                            referenceId = referenceId.trim().ifEmpty { null },
                            notes = notes.trim().ifEmpty { null }
                        )
                        onSave(finalPayment, true)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AmberGold)
                ) {
                    Text("Continue Anyway")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDuplicateWarning = false }) {
                    Text("Cancel / Review")
                }
            }
        )
        return
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(if (initialPayment != null) "Edit Client Payment" else "Add Client Payment", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (errorMessage.isNotEmpty()) {
                    Text(text = errorMessage, color = RoseDark, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                // Project
                OutlinedTextField(
                    value = project,
                    onValueChange = { project = it },
                    label = { Text("Project / Site Name *") },
                    modifier = Modifier.fillMaxWidth()
                )

                // Client Name
                OutlinedTextField(
                    value = clientName,
                    onValueChange = { clientName = it },
                    label = { Text("Client / Owner Name") },
                    modifier = Modifier.fillMaxWidth()
                )

                // Date & Amount
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = date,
                        onValueChange = { date = it },
                        label = { Text("Date *") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = amountText,
                        onValueChange = { amountText = it },
                        label = { Text("Amount (Rs.) *") },
                        modifier = Modifier.weight(1f)
                    )
                }

                // Payment Method Selector
                Text(text = "Payment Method:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    methods.take(3).forEach { m ->
                        FilterChip(
                            selected = paymentMethod == m,
                            onClick = { paymentMethod = m },
                            label = { Text(m, fontSize = 10.sp) }
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    methods.drop(3).forEach { m ->
                        FilterChip(
                            selected = paymentMethod == m,
                            onClick = { paymentMethod = m },
                            label = { Text(m, fontSize = 10.sp) }
                        )
                    }
                }

                // Reference ID
                OutlinedTextField(
                    value = referenceId,
                    onValueChange = { referenceId = it },
                    label = { Text("Reference / TID (optional)") },
                    modifier = Modifier.fillMaxWidth()
                )

                // Notes
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes (optional)") },
                    modifier = Modifier.fillMaxWidth()
                )

                // Important Note about screenshot and manual confirmation
                Surface(
                    color = EmeraldLight.copy(alpha = 0.4f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Notice: Enter or confirm the exact amount manually. The app stores payment records and receipts securely on your phone.",
                        fontSize = 10.sp,
                        color = EmeraldDark,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountText.toDoubleOrNull()
                    if (project.trim().isEmpty()) {
                        errorMessage = "Please enter project name."
                        return@Button
                    }
                    if (amt == null || amt <= 0) {
                        errorMessage = "Please enter valid amount."
                        return@Button
                    }

                    if (checkDuplicate(project.trim(), date, amt, paymentMethod)) {
                        showDuplicateWarning = true
                        return@Button
                    }

                    val finalPayment = ClientPaymentEntity(
                        id = initialPayment?.id ?: UUID.randomUUID().toString(),
                        project = project.trim(),
                        clientName = clientName.trim().ifEmpty { "Project Client" },
                        date = date,
                        amount = amt,
                        paymentMethod = paymentMethod,
                        referenceId = referenceId.trim().ifEmpty { null },
                        notes = notes.trim().ifEmpty { null }
                    )
                    onSave(finalPayment, false)
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen)
            ) {
                Text("Save Payment")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
