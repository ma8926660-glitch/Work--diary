package com.myworkdiary.app.data.repository

import android.content.Context
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.myworkdiary.app.data.local.dao.DiaryDao
import com.myworkdiary.app.data.local.entities.ClientPaymentEntity
import com.myworkdiary.app.data.local.entities.DayRecordEntity
import com.myworkdiary.app.data.local.entities.LabourEntryEntity
import com.myworkdiary.app.data.local.entities.LabourProfileEntity
import com.myworkdiary.app.data.local.entities.PaymentEntryEntity
import com.myworkdiary.app.data.local.entities.ProjectContractEntity
import com.myworkdiary.app.data.local.entities.WorkEntryEntity
import com.myworkdiary.app.model.DailyTotalsSummary
import com.myworkdiary.app.model.ProjectFinancialSummary
import com.myworkdiary.app.model.WorkerLedgerRow
import com.myworkdiary.app.model.WorkerLedgerSummary
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.io.File
import kotlin.math.max

class DiaryRepository(
    private val dao: DiaryDao,
    private val context: Context
) {
    private val gson: Gson = GsonBuilder().setPrettyPrinting().create()

    val allDays: Flow<List<DayRecordEntity>> = dao.getAllDays()
    val allProfiles: Flow<List<LabourProfileEntity>> = dao.getAllProfiles()
    val allLabourEntries: Flow<List<LabourEntryEntity>> = dao.getAllLabourEntries()
    val allWorkEntries: Flow<List<WorkEntryEntity>> = dao.getAllWorkEntries()
    val allPayments: Flow<List<PaymentEntryEntity>> = dao.getAllPayments()
    val allClientPayments: Flow<List<ClientPaymentEntity>> = dao.getAllClientPayments()
    val allContracts: Flow<List<ProjectContractEntity>> = dao.getAllContracts()

    suspend fun insertDay(day: DayRecordEntity) = dao.insertDay(day)
    suspend fun deleteDay(dayId: String) {
        dao.deleteDay(dayId)
        dao.deleteLabourEntriesByDay(dayId)
    }

    suspend fun insertProfile(profile: LabourProfileEntity) = dao.insertProfile(profile)
    suspend fun deleteProfile(profileId: String) = dao.deleteProfile(profileId)

    suspend fun insertLabourEntry(entry: LabourEntryEntity) = dao.insertLabourEntry(entry)
    suspend fun insertLabourEntries(entries: List<LabourEntryEntity>) = dao.insertLabourEntries(entries)
    suspend fun deleteLabourEntry(id: String) = dao.deleteLabourEntry(id)

    suspend fun insertWorkEntry(entry: WorkEntryEntity) = dao.insertWorkEntry(entry)
    suspend fun deleteWorkEntry(id: String) = dao.deleteWorkEntry(id)

    suspend fun insertPayment(payment: PaymentEntryEntity) = dao.insertPayment(payment)
    suspend fun deletePayment(id: String) = dao.deletePayment(id)

    suspend fun insertClientPayment(payment: ClientPaymentEntity) = dao.insertClientPayment(payment)
    suspend fun deleteClientPayment(id: String) = dao.deleteClientPayment(id)

    suspend fun updateContract(contract: ProjectContractEntity) = dao.insertContract(contract)

    /**
     * Calculates mathematical daily totals for a specific day.
     */
    fun calculateDailyTotals(
        dayLabour: List<LabourEntryEntity>,
        dayPayments: List<PaymentEntryEntity>
    ): DailyTotalsSummary {
        var labourWorkTotal = 0.0
        var materialTotal = 0.0
        var otherExpenses = 0.0
        var paidToday = 0.0
        var unpaidToday = 0.0
        var advancePaidToday = 0.0

        val linkedWorkLineIds = dayPayments.mapNotNull { it.linkedWorkLineId }.toSet()

        dayLabour.forEach { l ->
            val amount = l.dailyPayment
            when (l.category) {
                "Material" -> materialTotal += amount
                "Other Expense" -> otherExpenses += amount
                else -> labourWorkTotal += amount
            }

            if (l.paid || l.status == "Paid") {
                if (!linkedWorkLineIds.contains(l.id)) {
                    paidToday += amount
                }
            } else {
                unpaidToday += amount
            }
        }

        dayPayments.forEach { p ->
            paidToday += p.amount
            if (p.isAdvance || p.paymentKind == "Advance") {
                advancePaidToday += p.amount
            }
        }

        val grandTotal = labourWorkTotal + materialTotal + otherExpenses

        return DailyTotalsSummary(
            labourWorkTotal = labourWorkTotal,
            materialTotal = materialTotal,
            otherExpenses = otherExpenses,
            paidToday = paidToday,
            unpaidToday = unpaidToday,
            advancePaidToday = advancePaidToday,
            grandTotal = grandTotal
        )
    }

    /**
     * Calculates complete worker ledger without double-counting payments.
     */
    fun calculateWorkerLedger(
        workerName: String,
        allLabour: List<LabourEntryEntity>,
        allPaymentsList: List<PaymentEntryEntity>
    ): WorkerLedgerSummary {
        val norm = workerName.trim().lowercase()
        val wLabour = allLabour.filter { it.workerName.trim().lowercase() == norm }
        val wPayments = allPaymentsList.filter { it.workerName.trim().lowercase() == norm }

        val linkedWorkLineIds = wPayments.mapNotNull { it.linkedWorkLineId }.toSet()
        val history = mutableListOf<WorkerLedgerRow>()

        var totalWorkAmount = 0.0
        var totalPaid = 0.0
        var totalAdvance = 0.0

        // Process Labour entries
        wLabour.forEach { l ->
            val isAdv = l.paymentKind == "Advance" || l.workPerformed.contains("Advance", ignoreCase = true)
            val isPaid = l.paid || l.status == "Paid"

            if (isAdv) {
                totalAdvance += l.dailyPayment
                if (isPaid && !linkedWorkLineIds.contains(l.id)) {
                    totalPaid += l.dailyPayment
                }
            } else {
                totalWorkAmount += l.dailyPayment
                if (isPaid && !linkedWorkLineIds.contains(l.id)) {
                    totalPaid += l.dailyPayment
                }
            }

            history.add(
                WorkerLedgerRow(
                    id = "w-${l.id}",
                    date = l.date,
                    description = if (isAdv) "Advance: ${l.workPerformed}" else l.workPerformed.ifEmpty { "Daily Work" },
                    amount = l.dailyPayment,
                    status = if (isPaid) "Paid" else "Unpaid",
                    type = if (isAdv) "Advance" else "Work",
                    paymentKind = l.paymentKind,
                    isAdvance = isAdv
                )
            )
        }

        // Process separate explicit payment entries
        wPayments.forEach { p ->
            val isAdv = p.isAdvance || p.paymentKind == "Advance"
            val isLinked = !p.linkedWorkLineId.isNullOrEmpty()

            if (!isLinked) {
                totalPaid += p.amount
                if (isAdv) {
                    totalAdvance += p.amount
                }

                history.add(
                    WorkerLedgerRow(
                        id = "p-${p.id}",
                        date = p.date,
                        description = if (isAdv) "Cash Advance: ${p.reason}" else p.reason.ifEmpty { "Payment (${p.paymentType})" },
                        amount = p.amount,
                        status = "Paid",
                        type = if (isAdv) "Advance" else "Payment",
                        paymentKind = p.paymentKind,
                        isAdvance = isAdv
                    )
                )
            } else {
                totalPaid += p.amount
            }
        }

        // Sort history by date descending
        history.sortByDescending { it.date }

        val totalUnpaid = max(0.0, totalWorkAmount - (totalPaid - totalAdvance))
        val currentBalance = (totalWorkAmount) - totalPaid
        val daysWorked = wLabour.map { it.date }.toSet().size

        return WorkerLedgerSummary(
            workerName = workerName,
            totalWorkAmount = totalWorkAmount,
            totalPaid = totalPaid,
            totalAdvance = totalAdvance,
            totalUnpaid = totalUnpaid,
            currentBalance = currentBalance,
            daysWorked = daysWorked,
            history = history
        )
    }

    /**
     * Calculates project financial summary.
     */
    fun calculateProjectSummary(
        projectName: String,
        allLabour: List<LabourEntryEntity>,
        allPaymentsList: List<PaymentEntryEntity>,
        allWork: List<WorkEntryEntity>,
        allClientPaymentsList: List<ClientPaymentEntity>,
        allContractsList: List<ProjectContractEntity>
    ): ProjectFinancialSummary {
        val norm = projectName.trim().lowercase()

        val pLabour = allLabour.filter { it.project.trim().lowercase() == norm }
        val pPayments = allPaymentsList.filter { it.project.trim().lowercase() == norm }
        val pWork = allWork.filter { it.project.trim().lowercase() == norm }
        val pClient = allClientPaymentsList.filter { it.project.trim().lowercase() == norm }
        val contract = allContractsList.find { it.projectName.trim().lowercase() == norm }

        val linkedIds = pPayments.mapNotNull { it.linkedWorkLineId }.toSet()

        val totalLabourCost = pLabour
            .filter { it.category == "Labour" }
            .sumOf { it.dailyPayment }

        var totalLabourPaid = 0.0
        pLabour
            .filter { it.category == "Labour" }
            .forEach { l ->
                if ((l.paid || l.status == "Paid") && !linkedIds.contains(l.id)) {
                    totalLabourPaid += l.dailyPayment
                }
            }
        pPayments
            .filter { it.category == "Labour" }
            .forEach { totalLabourPaid += it.amount }

        val totalLabourUnpaid = max(0.0, totalLabourCost - totalLabourPaid)

        val totalMaterialCost = pLabour.filter { it.category == "Material" }.sumOf { it.dailyPayment } +
                pPayments.filter { it.category == "Material" && it.linkedWorkLineId.isNullOrEmpty() }.sumOf { it.amount } +
                pWork.sumOf { it.workCost }

        val totalOtherExpenses = pLabour.filter { it.category == "Other Expense" }.sumOf { it.dailyPayment } +
                pPayments.filter { it.category == "Other Expense" && it.linkedWorkLineId.isNullOrEmpty() }.sumOf { it.amount } +
                pWork.sumOf { it.otherExpenses }

        val grandTotalProjectCost = totalLabourCost + totalMaterialCost + totalOtherExpenses

        var totalPaidOut = totalLabourPaid
        pLabour.filter { it.category == "Material" || it.category == "Other Expense" }
            .forEach { l ->
                if ((l.paid || l.status == "Paid") && !linkedIds.contains(l.id)) {
                    totalPaidOut += l.dailyPayment
                }
            }
        pPayments.filter { it.category == "Material" || it.category == "Other Expense" }
            .forEach { totalPaidOut += it.amount }

        val totalRemainingDue = max(0.0, grandTotalProjectCost - totalPaidOut)

        val totalMoneyReceived = pClient.sumOf { it.amount }
        val contractAmount = contract?.contractAmount ?: 0.0
        val remainingClientBalance = if (contractAmount > 0) max(0.0, contractAmount - totalMoneyReceived) else 0.0
        val projectProfit = totalMoneyReceived - grandTotalProjectCost

        return ProjectFinancialSummary(
            projectName = projectName,
            totalLabourCost = totalLabourCost,
            totalLabourPaid = totalLabourPaid,
            totalLabourUnpaid = totalLabourUnpaid,
            totalMaterialCost = totalMaterialCost,
            totalOtherExpenses = totalOtherExpenses,
            grandTotalProjectCost = grandTotalProjectCost,
            totalPaidOut = totalPaidOut,
            totalRemainingDue = totalRemainingDue,
            contractAmount = contractAmount,
            totalMoneyReceived = totalMoneyReceived,
            remainingClientBalance = remainingClientBalance,
            projectProfit = projectProfit
        )
    }

    /**
     * Exports full database to JSON string for backup.
     */
    suspend fun exportBackupJson(): String {
        val backupMap = mapOf(
            "days" to dao.getAllDays().first(),
            "profiles" to dao.getAllProfiles().first(),
            "labourEntries" to dao.getAllLabourEntries().first(),
            "workEntries" to dao.getAllWorkEntries().first(),
            "payments" to dao.getAllPayments().first(),
            "clientPayments" to dao.getAllClientPayments().first(),
            "contracts" to dao.getAllContracts().first()
        )
        return gson.toJson(backupMap)
    }
}
