package com.myworkdiary.app.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "labour_profiles")
data class LabourProfileEntity(
    @PrimaryKey
    val id: String,
    val name: String,
    val category: String = "Plumber",
    val phone: String = "",
    val avatarType: String = "emoji", // "emoji" or "photo"
    val avatarValue: String = "👷‍♂️",
    val dailyRate: Double = 2000.0,
    val notes: String = "",
    val createdAt: String = ""
)
