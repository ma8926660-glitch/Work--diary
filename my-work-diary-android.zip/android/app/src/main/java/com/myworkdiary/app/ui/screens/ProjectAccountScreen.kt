package com.myworkdiary.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.myworkdiary.app.ui.theme.*
import com.myworkdiary.app.viewmodel.DiaryViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectAccountScreen(
    viewModel: DiaryViewModel,
    projectName: String,
    onBack: () -> Unit
) {
    val summary = viewModel.getProjectSummary(projectName)
    var showEditContractDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(projectName, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = PrimaryBrownDark,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(NotebookPaper)
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Contract & Received Header Card
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = PrimaryBrownDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("PROJECT CONTRACT & REVENUE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AmberGold)
                            IconButton(onClick = { showEditContractDialog = true }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.Edit, contentDescription = "Edit Contract", tint = AmberGold)
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("Total Contract / Due", fontSize = 11.sp, color = Color.White.copy(alpha = 0.8f))
                                Text(
                                    "Rs. ${summary.contractAmount.toInt()}",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Total Money Received", fontSize = 11.sp, color = EmeraldLight)
                                Text(
                                    "Rs. ${summary.totalMoneyReceived.toInt()}",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldLight
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = Color.White.copy(alpha = 0.15f))
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Remaining Client Balance:", fontSize = 12.sp, color = Color.White.copy(alpha = 0.9f))
                            Text(
                                "Rs. ${summary.remainingClientBalance.toInt()}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = AmberGold
                            )
                        }
                    }
                }
            }

            // Project Cost Breakdown Card
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("PROJECT EXPENSES", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                        SummaryRow("Total Labour Cost", "Rs. ${summary.totalLabourCost.toInt()}", TextDark)
                        SummaryRow("Total Labour Paid", "Rs. ${summary.totalLabourPaid.toInt()}", EmeraldGreen)
                        SummaryRow("Total Labour Unpaid", "Rs. ${summary.totalLabourUnpaid.toInt()}", Color(0xFFDC2626))
                        SummaryRow("Total Material Cost", "Rs. ${summary.totalMaterialCost.toInt()}", TextDark)
                        SummaryRow("Other Site Expenses", "Rs. ${summary.totalOtherExpenses.toInt()}", TextDark)
                        HorizontalDivider()
                        SummaryRow("Total Project Expenses", "Rs. ${summary.grandTotalProjectCost.toInt()}", Color(0xFFDC2626), isBold = true)
                    }
                }
            }

            // Profit Card
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (summary.projectProfit >= 0) EmeraldDark else Color(0xFF7F1D1D)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("PROJECT PROFIT / DIFFERENCE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White.copy(alpha = 0.8f))
                            Text(
                                "Rs. ${summary.projectProfit.toInt()}",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Black,
                                color = if (summary.projectProfit >= 0) EmeraldLight else Color(0xFFFCA5A5)
                            )
                        }
                    }
                }
            }
        }
    }

    if (showEditContractDialog) {
        var contractInput by remember { mutableStateOf(summary.contractAmount.toInt().toString()) }

        AlertDialog(
            onDismissRequest = { showEditContractDialog = false },
            title = { Text("Update Total Contract Amount", fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = contractInput,
                    onValueChange = { contractInput = it },
                    label = { Text("Total Contract / Amount Due (Rs.)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = contractInput.toDoubleOrNull() ?: 0.0
                        viewModel.updateContractAmount(projectName, amt)
                        showEditContractDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBrownDark)
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditContractDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
