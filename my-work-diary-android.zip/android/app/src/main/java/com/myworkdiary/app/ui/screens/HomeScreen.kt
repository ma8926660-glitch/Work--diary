package com.myworkdiary.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.myworkdiary.app.ui.theme.*
import com.myworkdiary.app.viewmodel.DiaryViewModel

@Composable
fun HomeScreen(
    viewModel: DiaryViewModel,
    onNavigate: (String) -> Unit
) {
    val days by viewModel.allDays.collectAsState()
    val profiles by viewModel.allProfiles.collectAsState()
    val labourEntries by viewModel.allLabourEntries.collectAsState()
    val payments by viewModel.allPayments.collectAsState()
    val clientPayments by viewModel.allClientPayments.collectAsState()

    val totalDays = days.size
    val totalWorkers = profiles.size
    val totalWagesEarned = labourEntries.sumOf { it.dailyPayment }
    val totalPaymentsOut = payments.sumOf { it.amount }
    val totalRemainingWages = maxOf(0.0, totalWagesEarned - totalPaymentsOut)
    val totalClientReceived = clientPayments.sumOf { it.amount }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(NotebookPaper)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Digital Notebook Cover Header
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = PrimaryBrownDark),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                listOf(PrimaryBrown, PrimaryBrownDark, Color(0xFF260E03))
                            )
                        )
                        .padding(16.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = Color.Black.copy(alpha = 0.4f),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = "CONTRACTOR NOTEBOOK",
                                    color = AmberGold,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                            Text(
                                text = "100% Offline",
                                color = EmeraldLight,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "My Work Diary",
                            color = Color.White,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Digital notebook for construction & plumbing",
                            color = AmberLight.copy(alpha = 0.85f),
                            fontSize = 12.sp
                        )

                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = Color.White.copy(alpha = 0.15f))
                        Spacer(modifier = Modifier.height(10.dp))

                        // Quick Glance 4 Stat Boxes
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            GlanceBox(title = "Days Logged", value = "$totalDays", modifier = Modifier.weight(1f))
                            GlanceBox(title = "Client Recv.", value = "Rs. ${totalClientReceived.toInt()}", valueColor = EmeraldLight, modifier = Modifier.weight(1.3f))
                            GlanceBox(title = "Wages Paid", value = "Rs. ${totalPaymentsOut.toInt()}", modifier = Modifier.weight(1.3f))
                            GlanceBox(title = "Remaining", value = "Rs. ${totalRemainingWages.toInt()}", valueColor = AmberGold, modifier = Modifier.weight(1.2f))
                        }
                    }
                }
            }
        }

        // 2. VERY LARGE AND EASY-TO-SEE BUTTON: "+ Add Today's Work"
        item {
            Button(
                onClick = { onNavigate("add_today_work") },
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = AmberGold,
                    contentColor = Color.White
                ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.25f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "+ Add Today's Work",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "Tap to enter date, workers, jobs & payments",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                }
            }
        }

        // 3. 💰 CLIENT PAYMENTS SECTION CARD
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = EmeraldDark),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigate("client_payments") }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.White.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccountBalanceWallet,
                                contentDescription = "Client Payments",
                                tint = EmeraldLight,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "💰 Client Payments",
                                    color = Color.White,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    color = Color.Black.copy(alpha = 0.3f),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = "Money In",
                                        color = EmeraldLight,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = "Total: Rs. ${totalClientReceived.toInt()} · ${clientPayments.size} Receipts",
                                color = EmeraldLight.copy(alpha = 0.9f),
                                fontSize = 11.sp
                            )
                        }
                    }
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = "Open",
                        tint = EmeraldLight
                    )
                }
            }
        }

        // 4. Notebook Sections
        item {
            Text(
                text = "NOTEBOOK SECTIONS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = TextMuted,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        item {
            MenuOptionCard(
                title = "1. 📖 Daily Diary",
                subtitle = "Read & edit lined notebook records",
                badge = "${days.size} Days",
                icon = Icons.Default.Book,
                iconBg = PrimaryBrown,
                onClick = { onNavigate("notebook") }
            )
        }

        item {
            MenuOptionCard(
                title = "2. 👷‍♂️ Labour Records",
                subtitle = "Worker attendance, ledger & profiles",
                badge = "$totalWorkers Workers",
                icon = Icons.Default.People,
                iconBg = Color(0xFF78350F),
                onClick = { onNavigate("labour_profiles") }
            )
        }

        item {
            MenuOptionCard(
                title = "3. 🔧 Work Records",
                subtitle = "Plumbing & construction jobs log",
                badge = "Site Jobs",
                icon = Icons.Default.Build,
                iconBg = Color(0xFF292524),
                onClick = { onNavigate("work_records") }
            )
        }

        item {
            MenuOptionCard(
                title = "4. 💵 Payment Records",
                subtitle = "Labour wages, advances & expense ledger",
                badge = "Rs. ${totalPaymentsOut.toInt()}",
                icon = Icons.Default.Payments,
                iconBg = EmeraldGreen,
                onClick = { onNavigate("payments") }
            )
        }

        item {
            MenuOptionCard(
                title = "5. 📸 Site Photos",
                subtitle = "Job site photos with captions",
                badge = "Gallery",
                icon = Icons.Default.CameraAlt,
                iconBg = Color(0xFF0F766E),
                onClick = { onNavigate("photos") }
            )
        }

        item {
            MenuOptionCard(
                title = "6. 🔍 Search",
                subtitle = "Find labour, date, work, project or notes",
                badge = "Instant",
                icon = Icons.Default.Search,
                iconBg = Color(0xFF3730A3),
                onClick = { onNavigate("search") }
            )
        }

        item {
            MenuOptionCard(
                title = "7. 📊 Monthly Summary",
                subtitle = "Wages, materials, advances & grand totals",
                badge = "Summary",
                icon = Icons.Default.BarChart,
                iconBg = Color(0xFF451A03),
                onClick = { onNavigate("summary") }
            )
        }

        item {
            MenuOptionCard(
                title = "8. 💾 Backup & Restore",
                subtitle = "Offline JSON export and import",
                badge = "Safety",
                icon = Icons.Default.Backup,
                iconBg = Color(0xFF475569),
                onClick = { onNavigate("backup") }
            )
        }
    }
}

@Composable
fun GlanceBox(title: String, value: String, modifier: Modifier = Modifier, valueColor: Color = Color.White) {
    Surface(
        color = Color.Black.copy(alpha = 0.25f),
        shape = RoundedCornerShape(10.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = title, fontSize = 9.sp, color = AmberGold, fontWeight = FontWeight.Medium)
            Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = valueColor, maxLines = 1)
        }
    }
}

@Composable
fun MenuOptionCard(
    title: String,
    subtitle: String,
    badge: String,
    icon: ImageVector,
    iconBg: Color,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(iconBg),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(text = title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextDark)
                    Text(text = subtitle, fontSize = 11.sp, color = TextMuted)
                }
            }
            Text(
                text = badge,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextMuted
            )
        }
    }
}
