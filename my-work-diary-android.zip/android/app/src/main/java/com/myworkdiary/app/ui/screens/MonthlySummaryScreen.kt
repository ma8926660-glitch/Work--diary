package com.myworkdiary.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.myworkdiary.app.ui.theme.*
import com.myworkdiary.app.viewmodel.DiaryViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MonthlySummaryScreen(
    viewModel: DiaryViewModel,
    onBack: () -> Unit
) {
    val allLabour by viewModel.allLabourEntries.collectAsState()
    val allPayments by viewModel.allPayments.collectAsState()
    val allClientPayments by viewModel.allClientPayments.collectAsState()

    val currentMonth = SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(Date())

    val totalLabourEarned = allLabour.filter { it.category == "Labour" }.sumOf { it.dailyPayment }
    val totalLabourPaid = allPayments.filter { it.category == "Labour" }.sumOf { it.amount }
    val totalMaterials = allLabour.filter { it.category == "Material" }.sumOf { it.dailyPayment } +
            allPayments.filter { it.category == "Material" }.sumOf { it.amount }
    val totalOtherExpenses = allLabour.filter { it.category == "Other Expense" }.sumOf { it.dailyPayment } +
            allPayments.filter { it.category == "Other Expense" }.sumOf { it.amount }
    val grandTotalExpenses = totalLabourEarned + totalMaterials + totalOtherExpenses
    val totalClientMoney = allClientPayments.sumOf { it.amount }
    val netProfit = totalClientMoney - grandTotalExpenses

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("📊 Monthly Summary", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = PrimaryBrownDark,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(NotebookPaper)
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = PrimaryBrownDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(currentMonth.uppercase(), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AmberGold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Financial Overview", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Spacer(modifier = Modifier.height(14.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("Client Money In", fontSize = 11.sp, color = Color.White.copy(alpha = 0.8f))
                                Text("Rs. ${totalClientMoney.toInt()}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = EmeraldLight)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Total Expenses", fontSize = 11.sp, color = Color.White.copy(alpha = 0.8f))
                                Text("Rs. ${grandTotalExpenses.toInt()}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                }
            }

            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("EXPENSE BREAKDOWN", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                        SummaryRow("Total Labour Cost", "Rs. ${totalLabourEarned.toInt()}", TextDark)
                        SummaryRow("Labour Paid Out", "Rs. ${totalLabourPaid.toInt()}", EmeraldGreen)
                        SummaryRow("Material Expenses", "Rs. ${totalMaterials.toInt()}", TextDark)
                        SummaryRow("Other Site Expenses", "Rs. ${totalOtherExpenses.toInt()}", TextDark)
                        HorizontalDivider()
                        SummaryRow("Grand Total Expenses", "Rs. ${grandTotalExpenses.toInt()}", Color(0xFFDC2626), isBold = true)
                    }
                }
            }

            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = if (netProfit >= 0) EmeraldDark else Color(0xFF7F1D1D)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("NET PROFIT / DIFFERENCE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White.copy(alpha = 0.8f))
                            Text(
                                "Rs. ${netProfit.toInt()}",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Black,
                                color = if (netProfit >= 0) EmeraldLight else Color(0xFFFCA5A5)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SummaryRow(title: String, amount: String, color: Color, isBold: Boolean = false) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(title, fontSize = 13.sp, color = TextDark, fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal)
        Text(amount, fontSize = 14.sp, fontWeight = if (isBold) FontWeight.Black else FontWeight.SemiBold, color = color)
    }
}
