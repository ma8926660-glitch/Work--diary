package com.myworkdiary.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.myworkdiary.app.MyWorkDiaryApp
import com.myworkdiary.app.data.local.entities.ClientPaymentEntity
import com.myworkdiary.app.data.local.entities.DayRecordEntity
import com.myworkdiary.app.data.local.entities.LabourEntryEntity
import com.myworkdiary.app.data.local.entities.LabourProfileEntity
import com.myworkdiary.app.data.local.entities.PaymentEntryEntity
import com.myworkdiary.app.data.local.entities.ProjectContractEntity
import com.myworkdiary.app.data.local.entities.WorkEntryEntity
import com.myworkdiary.app.model.DailyTotalsSummary
import com.myworkdiary.app.model.ProjectFinancialSummary
import com.myworkdiary.app.model.WorkerLedgerSummary
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class DiaryViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = (application as MyWorkDiaryApp).repository

    // Current Project Filter
    private val _currentProject = MutableStateFlow("ALL")
    val currentProject: StateFlow<String> = _currentProject.asStateFlow()

    // Selected Day ID for Notebook view
    private val _selectedDayId = MutableStateFlow<String?>(null)
    val selectedDayId: StateFlow<String?> = _selectedDayId.asStateFlow()

    val allDays = repository.allDays.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val allProfiles = repository.allProfiles.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val allLabourEntries = repository.allLabourEntries.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val allWorkEntries = repository.allWorkEntries.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val allPayments = repository.allPayments.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val allClientPayments = repository.allClientPayments.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val allContracts = repository.allContracts.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // Filtered by selected project
    val filteredDays = combine(allDays, currentProject) { days, proj ->
        if (proj == "ALL") days else days.filter { it.project.equals(proj, ignoreCase = true) }
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val filteredLabourEntries = combine(allLabourEntries, currentProject) { entries, proj ->
        if (proj == "ALL") entries else entries.filter { it.project.equals(proj, ignoreCase = true) }
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val filteredPayments = combine(allPayments, currentProject) { payments, proj ->
        if (proj == "ALL") payments else payments.filter { it.project.equals(proj, ignoreCase = true) }
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val filteredClientPayments = combine(allClientPayments, currentProject) { cpList, proj ->
        if (proj == "ALL") cpList else cpList.filter { it.project.equals(proj, ignoreCase = true) }
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun selectProject(project: String) {
        _currentProject.value = project
    }

    fun selectDayId(id: String) {
        _selectedDayId.value = id
    }

    // Mathematical calculations
    fun getDailyTotals(dayLabour: List<LabourEntryEntity>, dayPayments: List<PaymentEntryEntity>): DailyTotalsSummary {
        return repository.calculateDailyTotals(dayLabour, dayPayments)
    }

    fun getWorkerLedger(workerName: String): WorkerLedgerSummary {
        return repository.calculateWorkerLedger(workerName, allLabourEntries.value, allPayments.value)
    }

    fun getProjectSummary(projectName: String): ProjectFinancialSummary {
        return repository.calculateProjectSummary(
            projectName,
            allLabourEntries.value,
            allPayments.value,
            allWorkEntries.value,
            allClientPayments.value,
            allContracts.value
        )
    }

    // CRUD Handlers
    fun saveDay(day: DayRecordEntity) = viewModelScope.launch {
        repository.insertDay(day)
        _selectedDayId.value = day.id
    }

    fun deleteDay(dayId: String) = viewModelScope.launch {
        repository.deleteDay(dayId)
    }

    fun saveLabourEntry(entry: LabourEntryEntity) = viewModelScope.launch {
        repository.insertLabourEntry(entry)
    }

    fun deleteLabourEntry(id: String) = viewModelScope.launch {
        repository.deleteLabourEntry(id)
    }

    fun saveProfile(profile: LabourProfileEntity) = viewModelScope.launch {
        repository.insertProfile(profile)
    }

    fun deleteProfile(id: String) = viewModelScope.launch {
        repository.deleteProfile(id)
    }

    fun savePayment(payment: PaymentEntryEntity) = viewModelScope.launch {
        repository.insertPayment(payment)
        // If linked to a work line, mark that line as Paid
        if (!payment.linkedWorkLineId.isNullOrEmpty()) {
            val matching = allLabourEntries.value.find { it.id == payment.linkedWorkLineId }
            if (matching != null) {
                repository.insertLabourEntry(matching.copy(paid = true, status = "Paid", linkedPaymentId = payment.id))
            }
        }
    }

    fun deletePayment(id: String) = viewModelScope.launch {
        repository.deletePayment(id)
    }

    fun saveClientPayment(payment: ClientPaymentEntity) = viewModelScope.launch {
        repository.insertClientPayment(payment)
    }

    fun deleteClientPayment(id: String) = viewModelScope.launch {
        repository.deleteClientPayment(id)
    }

    fun updateContractAmount(projectName: String, amount: Double) = viewModelScope.launch {
        repository.updateContract(ProjectContractEntity(projectName, amount))
    }

    /**
     * Checks if a client payment is an exact duplicate before saving.
     */
    fun isDuplicateClientPayment(project: String, date: String, amount: Double, method: String, excludeId: String? = null): Boolean {
        return allClientPayments.value.any {
            if (excludeId != null && it.id == excludeId) false
            else it.project.equals(project, ignoreCase = true) &&
                    it.date == date &&
                    it.amount == amount &&
                    it.paymentMethod == method
        }
    }
}
