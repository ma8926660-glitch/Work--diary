package com.myworkdiary.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.myworkdiary.app.data.local.entities.PaymentEntryEntity
import com.myworkdiary.app.ui.theme.*
import com.myworkdiary.app.viewmodel.DiaryViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LabourDetailScreen(
    viewModel: DiaryViewModel,
    workerName: String,
    onBack: () -> Unit
) {
    val ledger = viewModel.getWorkerLedger(workerName)
    var showQuickPayDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("👷‍♂️ Ledger: $workerName", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = PrimaryBrownDark,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showQuickPayDialog = true },
                containerColor = EmeraldGreen,
                contentColor = Color.White,
                icon = { Icon(Icons.Default.Payments, contentDescription = null) },
                text = { Text("Pay / Give Advance") }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(NotebookPaper)
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Ledger Summary Card
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "ACCOUNT SUMMARY",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextMuted,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Total Work Done", fontSize = 12.sp, color = TextMuted)
                                Text(
                                    "Rs. ${ledger.totalWorkAmount.toInt()}",
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextDark
                                )
                            }
                            Column {
                                Text("Total Paid Out", fontSize = 12.sp, color = TextMuted)
                                Text(
                                    "Rs. ${ledger.totalPaid.toInt()}",
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldGreen
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Advance Given", fontSize = 12.sp, color = TextMuted)
                                Text(
                                    "Rs. ${ledger.totalAdvance.toInt()}",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = AmberGold
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Remaining Balance Due", fontSize = 12.sp, color = TextMuted)
                                Text(
                                    "Rs. ${ledger.totalUnpaid.toInt()}",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Black,
                                    color = if (ledger.totalUnpaid > 0) Color(0xFFDC2626) else EmeraldGreen
                                )
                            }
                        }
                    }
                }
            }

            // Work & Payment History Rows
            item {
                Text(
                    text = "TRANSACTION & WORK HISTORY",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextMuted,
                    letterSpacing = 1.sp
                )
            }

            if (ledger.history.isEmpty()) {
                item {
                    Text("No records found for this worker.", color = TextMuted, fontSize = 13.sp)
                }
            } else {
                items(ledger.history) { row ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(row.date, fontSize = 12.sp, color = TextMuted)
                                Text(row.description, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = TextDark)
                                if (row.project.isNotBlank()) {
                                    Text("Site: ${row.project}", fontSize = 11.sp, color = TextMuted)
                                }
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                val isPayment = row.type == "payment"
                                Text(
                                    text = if (isPayment) "- Rs. ${row.amount.toInt()}" else "+ Rs. ${row.amount.toInt()}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = if (isPayment) EmeraldGreen else TextDark
                                )
                                Text(
                                    text = row.status,
                                    fontSize = 10.sp,
                                    color = if (row.status == "Paid") EmeraldGreen else Color(0xFFDC2626),
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showQuickPayDialog) {
        var payAmount by remember { mutableStateOf(ledger.totalUnpaid.toInt().toString()) }
        var isAdvance by remember { mutableStateOf(false) }
        var payMethod by remember { mutableStateOf("Cash") }
        var notes by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showQuickPayDialog = false },
            title = { Text("Record Payment to $workerName", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = payAmount,
                        onValueChange = { payAmount = it },
                        label = { Text("Amount (Rs.) *") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = isAdvance, onCheckedChange = { isAdvance = it })
                        Text("This is an Advance Payment", fontSize = 13.sp)
                    }
                    OutlinedTextField(
                        value = payMethod,
                        onValueChange = { payMethod = it },
                        label = { Text("Payment Method (Cash, Easypaisa, JazzCash, Bank)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Notes / Description") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = payAmount.toDoubleOrNull() ?: 0.0
                        if (amt > 0) {
                            val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                            viewModel.savePayment(
                                PaymentEntryEntity(
                                    id = "pay-${UUID.randomUUID()}",
                                    date = today,
                                    recipient = workerName,
                                    amount = amt,
                                    paymentMethod = payMethod,
                                    category = "Labour",
                                    paymentKind = if (isAdvance) "Advance" else "Wage",
                                    isAdvance = isAdvance,
                                    project = "",
                                    notes = notes
                                )
                            )
                            showQuickPayDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen)
                ) {
                    Text("Save Payment")
                }
            },
            dismissButton = {
                TextButton(onClick = { showQuickPayDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
