package com.myworkdiary.app.ui.navigation

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object DailyNotebook : Screen("notebook")
    object AddTodayWork : Screen("add_today_work")
    object LabourProfiles : Screen("labour_profiles")
    object LabourDetail : Screen("labour_detail/{workerName}") {
        fun createRoute(workerName: String) = "labour_detail/$workerName"
    }
    object ClientPayments : Screen("client_payments")
    object ProjectAccount : Screen("project_account/{projectName}") {
        fun createRoute(projectName: String) = "project_account/$projectName"
    }
    object Payments : Screen("payments")
    object WorkRecords : Screen("work_records")
    object Photos : Screen("photos")
    object Search : Screen("search")
    object Summary : Screen("summary")
    object Backup : Screen("backup")
}
