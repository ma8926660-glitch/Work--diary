package com.myworkdiary.app.data.repository

import android.content.Context
import com.myworkdiary.app.data.local.dao.DiaryDao
import com.myworkdiary.app.data.local.entities.ClientPaymentEntity
import com.myworkdiary.app.data.local.entities.DayRecordEntity
import com.myworkdiary.app.data.local.entities.LabourEntryEntity
import com.myworkdiary.app.data.local.entities.LabourProfileEntity
import com.myworkdiary.app.data.local.entities.OwnerEntity
import com.myworkdiary.app.data.local.entities.PaymentEntryEntity
import com.myworkdiary.app.data.local.entities.PhotoRecordEntity
import com.myworkdiary.app.data.local.entities.ProjectContractEntity
import com.myworkdiary.app.data.local.entities.WorkEntryEntity
import com.myworkdiary.app.model.DailyTotalsSummary
import com.myworkdiary.app.model.ProjectFinancialSummary
import com.myworkdiary.app.model.WorkerLedgerRow
import com.myworkdiary.app.model.WorkerLedgerSummary
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DiaryRepository(
    private val dao: DiaryDao,
    private val context: Context
) {
    // Day Records
    val allDays: Flow<List<DayRecordEntity>> = dao.getAllDays()
    suspend fun insertDay(day: DayRecordEntity) = dao.insertDay(day)
    suspend fun deleteDay(id: String) = dao.deleteDay(id)

    // Labour Profiles
    val allProfiles: Flow<List<LabourProfileEntity>> = dao.getAllProfiles()
    suspend fun insertProfile(profile: LabourProfileEntity) = dao.insertProfile(profile)
    suspend fun deleteProfile(id: String) = dao.deleteProfile(id)

    // Labour Entries
    val allLabourEntries: Flow<List<LabourEntryEntity>> = dao.getAllLabourEntries()
    fun getLabourEntriesByDay(dayId: String): Flow<List<LabourEntryEntity>> = dao.getLabourEntriesByDay(dayId)
    suspend fun insertLabourEntry(entry: LabourEntryEntity) = dao.insertLabourEntry(entry)
    suspend fun deleteLabourEntry(id: String) = dao.deleteLabourEntry(id)

    // Work Entries
    val allWorkEntries: Flow<List<WorkEntryEntity>> = dao.getAllWorkEntries()
    suspend fun insertWorkEntry(entry: WorkEntryEntity) = dao.insertWorkEntry(entry)
    suspend fun deleteWorkEntry(id: String) = dao.deleteWorkEntry(id)

    // Payments
    val allPayments: Flow<List<PaymentEntryEntity>> = dao.getAllPayments()
    fun getPaymentsByLabourId(labourId: String): Flow<List<PaymentEntryEntity>> = dao.getPaymentsByLabourId(labourId)
    suspend fun insertPayment(payment: PaymentEntryEntity) = dao.insertPayment(payment)
    suspend fun updatePayment(payment: PaymentEntryEntity) = dao.updatePayment(payment)
    suspend fun deletePayment(id: String) = dao.deletePayment(id)

    // Owners
    val allOwners: Flow<List<OwnerEntity>> = dao.getAllOwners()
    suspend fun getOwnerByCode(code: String): OwnerEntity? = dao.getOwnerByCode(code.trim())
    suspend fun getOwnerById(id: String): OwnerEntity? = dao.getOwnerById(id)
    suspend fun insertOwner(owner: OwnerEntity) = dao.insertOwner(owner)
    suspend fun updateOwner(owner: OwnerEntity) = dao.updateOwner(owner)
    suspend fun deleteOwner(id: String) = dao.deleteOwner(id)

    // Client Payments
    val allClientPayments: Flow<List<ClientPaymentEntity>> = dao.getAllClientPayments()
    fun getClientPaymentsByOwner(ownerId: String): Flow<List<ClientPaymentEntity>> = dao.getClientPaymentsByOwner(ownerId)
    suspend fun insertClientPayment(payment: ClientPaymentEntity) = dao.insertClientPayment(payment)
    suspend fun updateClientPayment(payment: ClientPaymentEntity) = dao.updateClientPayment(payment)
    suspend fun deleteClientPayment(id: String) = dao.deleteClientPayment(id)

    // Project Contracts
    val allContracts: Flow<List<ProjectContractEntity>> = dao.getAllContracts()
    suspend fun updateContract(contract: ProjectContractEntity) = dao.insertContract(contract)

    // Photos
    val allPhotos: Flow<List<PhotoRecordEntity>> = dao.getAllPhotos()
        .catch { emit(emptyList()) }
    suspend fun insertPhoto(photo: PhotoRecordEntity) = try {
        dao.insertPhoto(photo)
    } catch (_: Exception) {}
    suspend fun deletePhoto(id: String) = try {
        dao.deletePhoto(id)
    } catch (_: Exception) {}

    fun calculateDailyTotals(
        dayLabour: List<LabourEntryEntity>,
        dayPayments: List<PaymentEntryEntity>
    ): DailyTotalsSummary {
        val labourTotal = dayLabour
            .filter { it.category == "Labour" }
            .sumOf { it.dailyPayment }
        val materialTotal = dayPayments
            .filter { it.category == "Material" }
            .sumOf { it.amount }
        val otherExpenses = dayPayments
            .filter { it.category == "Other Expense" }
            .sumOf { it.amount }
        val paidToday = dayPayments
            .filter { !it.isAdvance }
            .sumOf { it.amount }
        val advancePaidToday = dayPayments
            .filter { it.isAdvance }
            .sumOf { it.amount }
        val unpaidToday = dayLabour
            .filter { !it.paid && it.status != "Paid" }
            .sumOf { it.remainingPayment.takeIf { rem -> rem > 0 } ?: (it.dailyPayment - it.advancePayment) }

        return DailyTotalsSummary(
            labourWorkTotal = labourTotal,
            materialTotal = materialTotal,
            otherExpenses = otherExpenses,
            paidToday = paidToday,
            unpaidToday = maxOf(0.0, unpaidToday),
            advancePaidToday = advancePaidToday,
            grandTotal = labourTotal + materialTotal + otherExpenses
        )
    }

    fun calculateWorkerLedger(
        workerName: String,
        allLabour: List<LabourEntryEntity>,
        allPaymentsList: List<PaymentEntryEntity>
    ): WorkerLedgerSummary {
        val norm = workerName.trim().lowercase()
        val workerLabour = allLabour.filter { it.workerName.trim().lowercase() == norm }
        val workerPayments = allPaymentsList.filter {
            (it.workerName.trim().lowercase() == norm) || (it.recipient.trim().lowercase() == norm)
        }

        val history = mutableListOf<WorkerLedgerRow>()
        workerLabour.forEach { l ->
            val isAdv = l.advancePayment > 0 && l.dailyPayment == 0.0
            history.add(
                WorkerLedgerRow(
                    id = "w-${l.id}",
                    date = l.date,
                    description = if (isAdv) "Advance: ${l.workPerformed.ifEmpty { l.workDescription }}" else (l.workPerformed.ifEmpty { l.workDescription.ifEmpty { "Daily Work" } }),
                    amount = l.dailyPayment,
                    status = l.status,
                    type = if (isAdv) "Advance" else "Work",
                    paymentKind = l.paymentKind,
                    isAdvance = isAdv,
                    project = l.project
                )
            )
        }

        workerPayments.forEach { p ->
            history.add(
                WorkerLedgerRow(
                    id = "p-${p.id}",
                    date = p.date,
                    description = p.reason.ifEmpty { if (p.isAdvance) "Advance Payment" else "Wage Payment" },
                    amount = p.amount,
                    status = "Paid",
                    type = if (p.isAdvance) "Advance" else "Payment",
                    paymentKind = p.paymentKind,
                    isAdvance = p.isAdvance,
                    project = p.project
                )
            )
        }

        history.sortByDescending { it.date }
        val totalWork = workerLabour.sumOf { it.dailyPayment }
        val totalPaidOut = workerPayments.filter { !it.isAdvance }.sumOf { it.amount }
        val totalAdvance = workerPayments.filter { it.isAdvance }.sumOf { it.amount } +
                workerLabour.sumOf { it.advancePayment }
        val currentBal = maxOf(0.0, totalWork - (totalPaidOut + totalAdvance))

        return WorkerLedgerSummary(
            workerName = workerName,
            totalWorkAmount = totalWork,
            totalPaid = totalPaidOut,
            totalAdvance = totalAdvance,
            totalUnpaid = currentBal,
            currentBalance = currentBal,
            daysWorked = workerLabour.size,
            history = history
        )
    }

    fun calculateProjectSummary(
        projectName: String,
        allLabour: List<LabourEntryEntity>,
        allPaymentsList: List<PaymentEntryEntity>,
        allWork: List<WorkEntryEntity>,
        allClientPaymentsList: List<ClientPaymentEntity>,
        allContractsList: List<ProjectContractEntity>
    ): ProjectFinancialSummary {
        val norm = projectName.trim().lowercase()
        val pLabour = allLabour.filter { it.project.trim().lowercase() == norm }
        val pPayments = allPaymentsList.filter { it.project.trim().lowercase() == norm }
        val pWork = allWork.filter { it.project.trim().lowercase() == norm }
        val contract = allContractsList.find { it.projectName.trim().lowercase() == norm }
        val linkedIds = pPayments.mapNotNull { it.linkedWorkLineId }.toSet()

        val totalLabourCost = pLabour
            .filter { it.category == "Labour" }
            .sumOf { it.dailyPayment }

        var totalLabourPaid = 0.0
        pLabour
            .filter { it.category == "Labour" }
            .forEach { l ->
                if ((l.paid || l.status == "Paid") && !linkedIds.contains(l.id)) {
                    totalLabourPaid += l.dailyPayment
                }
            }
        pPayments.forEach { p ->
            totalLabourPaid += p.amount
        }

        val totalMaterialCost = pWork.sumOf { it.workCost } +
                pPayments.filter { it.category == "Material" }.sumOf { it.amount }
        val totalOtherExpenses = pWork.sumOf { it.otherExpenses } +
                pPayments.filter { it.category == "Other Expense" }.sumOf { it.amount }
        val grandTotalCost = totalLabourCost + totalMaterialCost + totalOtherExpenses
        val totalPaidOut = totalLabourPaid + totalMaterialCost + totalOtherExpenses
        val totalRemainingDue = maxOf(0.0, grandTotalCost - totalPaidOut)

        val contractAmount = contract?.contractAmount ?: 0.0
        val totalMoneyReceived = allClientPaymentsList.sumOf { it.amount }
        val remainingClientBalance = if (contractAmount > 0) maxOf(0.0, contractAmount - totalMoneyReceived) else 0.0
        val profit = if (contractAmount > 0) (contractAmount - grandTotalCost) else 0.0

        return ProjectFinancialSummary(
            projectName = projectName,
            totalLabourCost = totalLabourCost,
            totalLabourPaid = totalLabourPaid,
            totalLabourUnpaid = maxOf(0.0, totalLabourCost - totalLabourPaid),
            totalMaterialCost = totalMaterialCost,
            totalOtherExpenses = totalOtherExpenses,
            grandTotalProjectCost = grandTotalCost,
            totalPaidOut = totalPaidOut,
            totalRemainingDue = totalRemainingDue,
            contractAmount = contractAmount,
            totalMoneyReceived = totalMoneyReceived,
            remainingClientBalance = remainingClientBalance,
            projectProfit = profit
        )
    }

    suspend fun exportBackupJson(): String {
        val root = JSONObject()
        root.put("version", 3)
        root.put("exportedAt", SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).format(Date()))
        root.put("currencySymbol", "Rs.")

        val daysArray = JSONArray()
        dao.getAllDays().first().forEach { d ->
            val obj = JSONObject()
            obj.put("id", d.id)
            obj.put("date", d.date)
            obj.put("dayName", d.dayName)
            obj.put("project", d.project)
            obj.put("customerName", d.customerName)
            obj.put("location", d.location)
            obj.put("generalNotes", d.generalNotes)
            daysArray.put(obj)
        }
        root.put("days", daysArray)

        val ownersArray = JSONArray()
        dao.getAllOwners().first().forEach { o ->
            val obj = JSONObject()
            obj.put("id", o.id)
            obj.put("name", o.name)
            obj.put("code", o.code)
            obj.put("createdAt", o.createdAt)
            ownersArray.put(obj)
        }
        root.put("owners", ownersArray)

        val clientPaymentsArray = JSONArray()
        dao.getAllClientPayments().first().forEach { cp ->
            val obj = JSONObject()
            obj.put("id", cp.id)
            obj.put("ownerId", cp.ownerId)
            obj.put("date", cp.date)
            obj.put("amount", cp.amount)
            obj.put("notes", cp.notes)
            obj.put("createdAt", cp.createdAt)
            clientPaymentsArray.put(obj)
        }
        root.put("clientPayments", clientPaymentsArray)

        return root.toString(2)
    }
}
