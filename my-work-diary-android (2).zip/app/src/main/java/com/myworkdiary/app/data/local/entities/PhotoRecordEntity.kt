package com.myworkdiary.app.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "photos")
data class PhotoRecordEntity(
    @PrimaryKey
    val id: String = "",
    val filePath: String = "",
    val caption: String = "",
    val date: String = "",
    val linkedType: String = "None", // "None", "Owner", "Labour"
    val linkedId: String = "",
    val linkedName: String = "",
    val createdAt: String = ""
)
