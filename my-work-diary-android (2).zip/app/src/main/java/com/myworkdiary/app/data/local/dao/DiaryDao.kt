package com.myworkdiary.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.myworkdiary.app.data.local.entities.ClientPaymentEntity
import com.myworkdiary.app.data.local.entities.DayRecordEntity
import com.myworkdiary.app.data.local.entities.LabourEntryEntity
import com.myworkdiary.app.data.local.entities.LabourProfileEntity
import com.myworkdiary.app.data.local.entities.OwnerEntity
import com.myworkdiary.app.data.local.entities.PaymentEntryEntity
import com.myworkdiary.app.data.local.entities.PhotoRecordEntity
import com.myworkdiary.app.data.local.entities.ProjectContractEntity
import com.myworkdiary.app.data.local.entities.WorkEntryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface DiaryDao {
    // Day Records
    @Query("SELECT * FROM days ORDER BY date DESC")
    fun getAllDays(): Flow<List<DayRecordEntity>>

    @Query("SELECT * FROM days WHERE id = :id LIMIT 1")
    suspend fun getDayById(id: String): DayRecordEntity?

    @Query("SELECT * FROM days WHERE date = :date LIMIT 1")
    suspend fun getDayByDate(date: String): DayRecordEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDay(day: DayRecordEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDays(days: List<DayRecordEntity>)

    @Query("DELETE FROM days WHERE id = :id")
    suspend fun deleteDay(id: String)

    // Labour Profiles
    @Query("SELECT * FROM labour_profiles ORDER BY name ASC")
    fun getAllProfiles(): Flow<List<LabourProfileEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: LabourProfileEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfiles(profiles: List<LabourProfileEntity>)

    @Query("DELETE FROM labour_profiles WHERE id = :id")
    suspend fun deleteProfile(id: String)

    // Labour Entries
    @Query("SELECT * FROM labour_entries ORDER BY date DESC")
    fun getAllLabourEntries(): Flow<List<LabourEntryEntity>>

    @Query("SELECT * FROM labour_entries WHERE dayId = :dayId")
    fun getLabourEntriesByDay(dayId: String): Flow<List<LabourEntryEntity>>

    @Query("SELECT * FROM labour_entries WHERE workerName = :name ORDER BY date DESC")
    fun getLabourEntriesByWorker(name: String): Flow<List<LabourEntryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLabourEntry(entry: LabourEntryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLabourEntries(entries: List<LabourEntryEntity>)

    @Query("DELETE FROM labour_entries WHERE id = :id")
    suspend fun deleteLabourEntry(id: String)

    @Query("DELETE FROM labour_entries WHERE dayId = :dayId")
    suspend fun deleteLabourEntriesByDay(dayId: String)

    // Work Entries
    @Query("SELECT * FROM work_entries ORDER BY date DESC")
    fun getAllWorkEntries(): Flow<List<WorkEntryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkEntry(entry: WorkEntryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkEntries(entries: List<WorkEntryEntity>)

    @Query("DELETE FROM work_entries WHERE id = :id")
    suspend fun deleteWorkEntry(id: String)

    // Payments
    @Query("SELECT * FROM payments ORDER BY date DESC")
    fun getAllPayments(): Flow<List<PaymentEntryEntity>>

    @Query("SELECT * FROM payments WHERE (labourId = :labourId OR workerId = :labourId) ORDER BY date DESC")
    fun getPaymentsByLabourId(labourId: String): Flow<List<PaymentEntryEntity>>

    @Query("SELECT * FROM payments WHERE workerName = :name ORDER BY date DESC")
    fun getPaymentsByWorker(name: String): Flow<List<PaymentEntryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(payment: PaymentEntryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayments(payments: List<PaymentEntryEntity>)

    @Update
    suspend fun updatePayment(payment: PaymentEntryEntity)

    @Query("DELETE FROM payments WHERE id = :id")
    suspend fun deletePayment(id: String)

    // Owners
    @Query("SELECT * FROM owners ORDER BY name ASC")
    fun getAllOwners(): Flow<List<OwnerEntity>>

    @Query("SELECT * FROM owners WHERE id = :id LIMIT 1")
    suspend fun getOwnerById(id: String): OwnerEntity?

    @Query("SELECT * FROM owners WHERE LOWER(code) = LOWER(:code) LIMIT 1")
    suspend fun getOwnerByCode(code: String): OwnerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOwner(owner: OwnerEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOwners(owners: List<OwnerEntity>)

    @Update
    suspend fun updateOwner(owner: OwnerEntity)

    @Query("DELETE FROM owners WHERE id = :id")
    suspend fun deleteOwner(id: String)

    // Client Payments
    @Query("SELECT * FROM client_payments ORDER BY date DESC")
    fun getAllClientPayments(): Flow<List<ClientPaymentEntity>>

    @Query("SELECT * FROM client_payments WHERE ownerId = :ownerId ORDER BY date DESC")
    fun getClientPaymentsByOwner(ownerId: String): Flow<List<ClientPaymentEntity>>

    @Query("SELECT * FROM client_payments WHERE date = :date")
    fun getClientPaymentsByDate(date: String): Flow<List<ClientPaymentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClientPayment(payment: ClientPaymentEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClientPayments(payments: List<ClientPaymentEntity>)

    @Update
    suspend fun updateClientPayment(payment: ClientPaymentEntity)

    @Query("DELETE FROM client_payments WHERE id = :id")
    suspend fun deleteClientPayment(id: String)

    @Query("DELETE FROM client_payments WHERE ownerId = :ownerId")
    suspend fun deleteClientPaymentsByOwner(ownerId: String)

    // Project Contracts
    @Query("SELECT * FROM project_contracts")
    fun getAllContracts(): Flow<List<ProjectContractEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContract(contract: ProjectContractEntity)

    // Clear all for restore
    @Query("DELETE FROM days")
    suspend fun clearDays()

    @Query("DELETE FROM labour_profiles")
    suspend fun clearProfiles()

    @Query("DELETE FROM labour_entries")
    suspend fun clearLabourEntries()

    @Query("DELETE FROM work_entries")
    suspend fun clearWorkEntries()

    @Query("DELETE FROM payments")
    suspend fun clearPayments()

    @Query("DELETE FROM owners")
    suspend fun clearOwners()

    @Query("DELETE FROM client_payments")
    suspend fun clearClientPayments()

    // Photos
    @Query("SELECT * FROM photos ORDER BY date DESC, createdAt DESC")
    fun getAllPhotos(): Flow<List<PhotoRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPhoto(photo: PhotoRecordEntity)

    @Query("DELETE FROM photos WHERE id = :id")
    suspend fun deletePhoto(id: String)

    @Query("DELETE FROM photos")
    suspend fun clearPhotos()
}
