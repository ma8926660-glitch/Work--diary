package com.myworkdiary.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.myworkdiary.app.data.local.dao.DiaryDao
import com.myworkdiary.app.data.local.entities.ClientPaymentEntity
import com.myworkdiary.app.data.local.entities.DayRecordEntity
import com.myworkdiary.app.data.local.entities.LabourEntryEntity
import com.myworkdiary.app.data.local.entities.LabourProfileEntity
import com.myworkdiary.app.data.local.entities.OwnerEntity
import com.myworkdiary.app.data.local.entities.PaymentEntryEntity
import com.myworkdiary.app.data.local.entities.PhotoRecordEntity
import com.myworkdiary.app.data.local.entities.ProjectContractEntity
import com.myworkdiary.app.data.local.entities.WorkEntryEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        DayRecordEntity::class,
        LabourProfileEntity::class,
        LabourEntryEntity::class,
        WorkEntryEntity::class,
        PaymentEntryEntity::class,
        OwnerEntity::class,
        ClientPaymentEntity::class,
        ProjectContractEntity::class,
        PhotoRecordEntity::class
    ],
    version = 5,
    exportSchema = false
)
abstract class DiaryDatabase : RoomDatabase() {
    abstract fun diaryDao(): DiaryDao

    companion object {
        @Volatile
        private var INSTANCE: DiaryDatabase? = null

        fun getDatabase(context: Context): DiaryDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    DiaryDatabase::class.java,
                    "my_work_diary_db"
                )
                    .fallbackToDestructiveMigration()
                    .addCallback(DatabaseCallback())
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        seedInitialData(database.diaryDao())
                    }
                }
            }

            private suspend fun seedInitialData(dao: DiaryDao) {
                // 1. Initial Days
                val days = listOf(
                    DayRecordEntity(
                        id = "day-2026-10-09",
                        date = "2026-10-09",
                        dayName = "Friday",
                        project = "Green Valley Villa 42",
                        customerName = "Mr. Hashim (Villa 42)",
                        location = "Plot 42, Block B, Green Valley",
                        generalNotes = "Given Rs. 1,000 cash advance to Ahmed for upcoming fittings and tested bathroom pressure.",
                        createdAt = "2026-10-09T08:00:00Z",
                        updatedAt = "2026-10-09T18:00:00Z"
                    ),
                    DayRecordEntity(
                        id = "day-2026-10-08",
                        date = "2026-10-08",
                        dayName = "Thursday",
                        project = "Green Valley Villa 42",
                        customerName = "Mr. Hashim (Villa 42)",
                        location = "Plot 42, Block B, Green Valley",
                        generalNotes = "Kitchen sink pipe fitting and tile cutting work underway.",
                        createdAt = "2026-10-08T08:00:00Z",
                        updatedAt = "2026-10-08T18:00:00Z"
                    )
                )
                dao.insertDays(days)

                // 2. Initial Labour Profiles
                val profiles = listOf(
                    LabourProfileEntity(
                        id = "worker-ahmed",
                        name = "Ahmed",
                        category = "Plumber",
                        role = "Master Sanitary Specialist",
                        standardDailyRate = 2500.0,
                        address = "Lahore",
                        phone = "+92 300 1234567",
                        dailyRate = 2500.0,
                        notes = "Concealed pipe fitting specialist."
                    ),
                    LabourProfileEntity(
                        id = "worker-ali",
                        name = "Ali",
                        category = "Tile Worker",
                        role = "Tile & Pipe Groover",
                        standardDailyRate = 2000.0,
                        address = "Lahore",
                        phone = "+92 302 9876543",
                        dailyRate = 2000.0,
                        notes = "Expert pipe grooving and tile fitting worker."
                    ),
                    LabourProfileEntity(
                        id = "worker-kamran",
                        name = "Kamran",
                        category = "Helper",
                        role = "General Helper",
                        standardDailyRate = 1200.0,
                        address = "Lahore",
                        phone = "+92 312 3456781",
                        dailyRate = 1200.0,
                        notes = "Site cleaning and helper."
                    )
                )
                dao.insertProfiles(profiles)

                // 3. Initial Labour Attendance
                val labourEntries = listOf(
                    LabourEntryEntity(
                        id = "labour-1",
                        dayId = "day-2026-10-09",
                        workerId = "worker-ahmed",
                        workerName = "Ahmed",
                        workerType = "Plumber",
                        workPerformed = "Finalized cold and hot water pressure test",
                        workDescription = "Finalized cold and hot water pressure test",
                        dailyPayment = 2500.0,
                        advancePayment = 1000.0,
                        remainingPayment = 1500.0,
                        status = "Partially Paid",
                        paid = false,
                        category = "Labour",
                        paymentKind = "Daily Wage",
                        date = "2026-10-09",
                        project = "Green Valley Villa 42"
                    ),
                    LabourEntryEntity(
                        id = "labour-2",
                        dayId = "day-2026-10-09",
                        workerId = "worker-kamran",
                        workerName = "Kamran",
                        workerType = "Helper",
                        workPerformed = "Cleaned debris and helped pipe insulation",
                        workDescription = "Cleaned debris and helped pipe insulation",
                        dailyPayment = 1200.0,
                        advancePayment = 0.0,
                        remainingPayment = 0.0,
                        status = "Paid",
                        paid = true,
                        category = "Labour",
                        paymentKind = "Daily Wage",
                        date = "2026-10-09",
                        project = "Green Valley Villa 42"
                    )
                )
                dao.insertLabourEntries(labourEntries)

                // 4. Initial Payments
                val payments = listOf(
                    PaymentEntryEntity(
                        id = "pay-1",
                        date = "2026-10-09",
                        labourId = "worker-kamran",
                        workerId = "worker-kamran",
                        workerName = "Kamran",
                        recipient = "Kamran",
                        amount = 1200.0,
                        category = "Labour",
                        paymentKind = "Wage",
                        isAdvance = false,
                        reason = "Daily Wage",
                        project = "Green Valley Villa 42"
                    ),
                    PaymentEntryEntity(
                        id = "pay-2",
                        date = "2026-10-09",
                        labourId = "worker-ahmed",
                        workerId = "worker-ahmed",
                        workerName = "Ahmed",
                        recipient = "Ahmed",
                        amount = 1000.0,
                        category = "Labour",
                        paymentKind = "Advance",
                        isAdvance = true,
                        reason = "Advance",
                        project = "Green Valley Villa 42"
                    )
                )
                dao.insertPayments(payments)

                // 5. Initial Owners
                val owners = listOf(
                    OwnerEntity(
                        id = "owner-1",
                        name = "Haji Bashir",
                        code = "HB01",
                        createdAt = "2026-10-01T08:00:00Z"
                    ),
                    OwnerEntity(
                        id = "owner-2",
                        name = "Chaudhry Akram",
                        code = "CA02",
                        createdAt = "2026-10-02T08:00:00Z"
                    ),
                    OwnerEntity(
                        id = "owner-3",
                        name = "Malik Tariq",
                        code = "MT03",
                        createdAt = "2026-10-03T08:00:00Z"
                    )
                )
                dao.insertOwners(owners)

                // 6. Initial Client Payments
                val clientPayments = listOf(
                    ClientPaymentEntity(
                        id = "client-pay-1",
                        ownerId = "owner-1",
                        date = "2026-10-07",
                        amount = 30000.0,
                        notes = "First advance installment received for sanitary fitting.",
                        createdAt = "2026-10-07T10:30:00Z"
                    ),
                    ClientPaymentEntity(
                        id = "client-pay-2",
                        ownerId = "owner-1",
                        date = "2026-10-09",
                        amount = 20000.0,
                        notes = "Second progress installment paid on site.",
                        createdAt = "2026-10-09T16:00:00Z"
                    ),
                    ClientPaymentEntity(
                        id = "client-pay-3",
                        ownerId = "owner-2",
                        date = "2026-10-10",
                        amount = 45000.0,
                        notes = "Initial booking advance for project work.",
                        createdAt = "2026-10-10T12:00:00Z"
                    )
                )
                dao.insertClientPayments(clientPayments)

                dao.insertContract(
                    ProjectContractEntity(
                        projectName = "Green Valley Villa 42",
                        contractAmount = 200000.0
                    )
                )
            }
        }
    }
}
