package com.myworkdiary.app.data.local.entities

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "client_payments",
    indices = [Index(value = ["ownerId"])]
)
data class ClientPaymentEntity(
    @PrimaryKey
    val id: String = "",
    val ownerId: String = "", // Links directly to OwnerEntity.id
    val date: String = "", // YYYY-MM-DD (तारीख)
    val amount: Double = 0.0, // रकम
    val notes: String = "", // छोटा नोट
    val createdAt: String = ""
)
