package com.myworkdiary.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.myworkdiary.app.data.local.dao.DiaryDao
import com.myworkdiary.app.data.local.entities.ClientPaymentEntity
import com.myworkdiary.app.data.local.entities.DayRecordEntity
import com.myworkdiary.app.data.local.entities.LabourEntryEntity
import com.myworkdiary.app.data.local.entities.LabourProfileEntity
import com.myworkdiary.app.data.local.entities.OwnerEntity
import com.myworkdiary.app.data.local.entities.PaymentEntryEntity
import com.myworkdiary.app.data.local.entities.ProjectContractEntity
import com.myworkdiary.app.data.local.entities.WorkEntryEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        DayRecordEntity::class,
        LabourProfileEntity::class,
        LabourEntryEntity::class,
        WorkEntryEntity::class,
        PaymentEntryEntity::class,
        OwnerEntity::class,
        ClientPaymentEntity::class,
        ProjectContractEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class DiaryDatabase : RoomDatabase() {

    abstract fun diaryDao(): DiaryDao

    companion object {
        @Volatile
        private var INSTANCE: DiaryDatabase? = null

        fun getDatabase(context: Context): DiaryDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    DiaryDatabase::class.java,
                    "my_work_diary_db"
                )
                    .fallbackToDestructiveMigration()
                    .addCallback(DatabaseCallback())
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                // Seed initial data asynchronously
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        seedInitialData(database.diaryDao())
                    }
                }
            }

            private suspend fun seedInitialData(dao: DiaryDao) {
                // 1. Initial Days
                val days = listOf(
                    DayRecordEntity(
                        id = "day-2026-10-09",
                        date = "2026-10-09",
                        dayName = "Friday",
                        project = "Green Valley Villa 42",
                        customerName = "Mr. Hashim (Villa 42)",
                        location = "Plot 42, Block B, Green Valley",
                        generalNotes = "Given Rs. 1,000 cash advance to Ahmed for upcoming fittings and tested bathroom pressure.",
                        createdAt = "2026-10-09T08:00:00Z",
                        updatedAt = "2026-10-09T18:00:00Z"
                    ),
                    DayRecordEntity(
                        id = "day-2026-10-08",
                        date = "2026-10-08",
                        dayName = "Thursday",
                        project = "Green Valley Villa 42",
                        customerName = "Mr. Hashim (Villa 42)",
                        location = "Plot 42, Block B, Green Valley",
                        generalNotes = "Kitchen sink pipe fitting and tile cutting work underway.",
                        createdAt = "2026-10-08T08:00:00Z",
                        updatedAt = "2026-10-08T18:00:00Z"
                    ),
                    DayRecordEntity(
                        id = "day-2026-10-07",
                        date = "2026-10-07",
                        dayName = "Wednesday",
                        project = "Green Valley Villa 42",
                        customerName = "Mr. Hashim (Villa 42)",
                        location = "Plot 42, Block B, Green Valley",
                        generalNotes = "Started master bathroom concealed fitting and pipe rough-in.",
                        createdAt = "2026-10-07T08:00:00Z",
                        updatedAt = "2026-10-07T18:00:00Z"
                    ),
                    DayRecordEntity(
                        id = "day-2026-10-06",
                        date = "2026-10-06",
                        dayName = "Tuesday",
                        project = "Green Valley Villa 42",
                        customerName = "Mr. Hashim (Villa 42)",
                        location = "Plot 42, Block B, Green Valley",
                        generalNotes = "Chipping walls for pipe grooving and material shifting.",
                        createdAt = "2026-10-06T08:00:00Z",
                        updatedAt = "2026-10-06T17:30:00Z"
                    )
                )
                dao.insertDays(days)

                // 2. Initial Labour Profiles
                val profiles = listOf(
                    LabourProfileEntity(
                        id = "worker-ahmed",
                        name = "Ahmed",
                        category = "Plumber",
                        role = "Master Sanitary Specialist",
                        standardDailyRate = 2500.0,
                        address = "Lahore, Pakistan",
                        phone = "+92 300 1234567",
                        avatarType = "emoji",
                        avatarValue = "👨‍🔧",
                        dailyRate = 2500.0,
                        notes = "Master sanitary & concealed pipe fitting specialist. Very reliable.",
                        createdAt = "2026-10-01T00:00:00Z"
                    ),
                    LabourProfileEntity(
                        id = "worker-ali",
                        name = "Ali",
                        category = "Tile Worker",
                        role = "Tile & Pipe Groover",
                        standardDailyRate = 2000.0,
                        address = "Lahore, Pakistan",
                        phone = "+92 302 9876543",
                        avatarType = "emoji",
                        avatarValue = "👷‍♂️",
                        dailyRate = 2000.0,
                        notes = "Expert pipe grooving and tile fitting worker.",
                        createdAt = "2026-10-01T00:00:00Z"
                    ),
                    LabourProfileEntity(
                        id = "worker-tariq",
                        name = "Tariq Mason",
                        category = "Mason",
                        role = "Masonry & Plaster Master",
                        standardDailyRate = 2200.0,
                        address = "Lahore, Pakistan",
                        phone = "+92 333 4567890",
                        avatarType = "emoji",
                        avatarValue = "🧱",
                        dailyRate = 2200.0,
                        notes = "Brick masonry, plaster and wall chipping specialist.",
                        createdAt = "2026-10-02T00:00:00Z"
                    ),
                    LabourProfileEntity(
                        id = "worker-kamran",
                        name = "Kamran",
                        category = "Helper",
                        role = "General Helper",
                        standardDailyRate = 1200.0,
                        address = "Lahore, Pakistan",
                        phone = "+92 312 3456781",
                        avatarType = "emoji",
                        avatarValue = "🦺",
                        dailyRate = 1200.0,
                        notes = "Site cleaning, material shifting and plumbing helper.",
                        createdAt = "2026-10-03T00:00:00Z"
                    )
                )
                dao.insertProfiles(profiles)

                // 3. Initial Labour Attendance Entries
                val labourEntries = listOf(
                    LabourEntryEntity(
                        id = "labour-1",
                        dayId = "day-2026-10-09",
                        workerId = "worker-ahmed",
                        workerName = "Ahmed",
                        workerType = "Plumber",
                        workPerformed = "Finalized cold and hot water pressure test",
                        workDescription = "Finalized cold and hot water pressure test",
                        role = "Master Sanitary Specialist",
                        standardDailyRate = 2500.0,
                        address = "Lahore, Pakistan",
                        dailyPayment = 2500.0,
                        advancePayment = 1000.0,
                        remainingPayment = 1500.0,
                        status = "Partially Paid",
                        paid = false,
                        category = "Labour",
                        paymentKind = "Daily Wage",
                        paymentMethod = "Cash",
                        notes = "Advance of Rs. 1000 paid at 1 PM.",
                        date = "2026-10-09",
                        project = "Green Valley Villa 42"
                    ),
                    LabourEntryEntity(
                        id = "labour-2",
                        dayId = "day-2026-10-09",
                        workerId = "worker-kamran",
                        workerName = "Kamran",
                        workerType = "Helper",
                        workPerformed = "Cleaned bathroom debris and helped pipe insulation",
                        workDescription = "Cleaned bathroom debris and helped pipe insulation",
                        role = "General Helper",
                        standardDailyRate = 1200.0,
                        address = "Lahore, Pakistan",
                        dailyPayment = 1200.0,
                        advancePayment = 0.0,
                        remainingPayment = 0.0,
                        status = "Paid",
                        paid = true,
                        category = "Labour",
                        paymentKind = "Daily Wage",
                        paymentMethod = "Cash",
                        notes = "Full day helper wage paid in cash on departure.",
                        date = "2026-10-09",
                        project = "Green Valley Villa 42"
                    ),
                    LabourEntryEntity(
                        id = "labour-3",
                        dayId = "day-2026-10-08",
                        workerId = "worker-ahmed",
                        workerName = "Ahmed",
                        workerType = "Plumber",
                        workPerformed = "Installed PVC drain lines for kitchen sink & dishwasher",
                        workDescription = "Installed PVC drain lines for kitchen sink & dishwasher",
                        role = "Master Sanitary Specialist",
                        standardDailyRate = 2500.0,
                        address = "Lahore, Pakistan",
                        dailyPayment = 2500.0,
                        advancePayment = 0.0,
                        remainingPayment = 0.0,
                        status = "Paid",
                        paid = true,
                        category = "Labour",
                        paymentKind = "Daily Wage",
                        paymentMethod = "Cash",
                        notes = "Clean joint work completed.",
                        date = "2026-10-08",
                        project = "Green Valley Villa 42"
                    )
                )
                dao.insertLabourEntries(labourEntries)

                // 4. Initial Work Entries
                val workEntries = listOf(
                    WorkEntryEntity(
                        id = "work-1",
                        dayId = "day-2026-10-09",
                        workName = "Master Bathroom Concealed PPR Pipe Rough-in",
                        description = "Complete hot & cold piping rough-in with brass fittings",
                        workDescription = "Complete hot & cold piping rough-in with brass fittings",
                        date = "2026-10-09",
                        project = "Green Valley Villa 42",
                        customerName = "Mr. Hashim (Villa 42)",
                        labourInvolved = "Ahmed (Plumber), Kamran (Helper)",
                        materialUsed = "PPR pipes 25mm, brass elbows, stop valves",
                        workCost = 3500.0,
                        labourCost = 3700.0,
                        otherExpenses = 500.0,
                        totalCost = 7700.0,
                        notes = "Pressure held stable at 10 bar."
                    )
                )
                dao.insertWorkEntries(workEntries)

                // 5. Initial Payment Entries (Wages / Advances Paid Out)
                val payments = listOf(
                    PaymentEntryEntity(
                        id = "pay-1",
                        date = "2026-10-09",
                        workerName = "Kamran",
                        recipient = "Kamran",
                        amount = 1200.0,
                        paymentType = "Cash",
                        paymentMethod = "Cash",
                        paymentKind = "Daily Wage",
                        category = "Labour",
                        isAdvance = false,
                        reason = "Daily Wage",
                        notes = "Full day helper wage paid in cash on departure",
                        project = "Green Valley Villa 42"
                    ),
                    PaymentEntryEntity(
                        id = "pay-2",
                        date = "2026-10-09",
                        workerName = "Ahmed",
                        recipient = "Ahmed",
                        amount = 1000.0,
                        paymentType = "Cash",
                        paymentMethod = "Cash",
                        paymentKind = "Advance",
                        category = "Labour",
                        isAdvance = true,
                        reason = "Advance",
                        notes = "Advance given for weekly family expense",
                        project = "Green Valley Villa 42"
                    )
                )
                dao.insertPayments(payments)

                // 6. Initial Owners (मालिक)
                val owners = listOf(
                    OwnerEntity(
                        id = "owner-1",
                        name = "Haji Bashir",
                        code = "HB01",
                        createdAt = "2026-10-01T08:00:00Z"
                    ),
                    OwnerEntity(
                        id = "owner-2",
                        name = "Chaudhry Akram",
                        code = "CA02",
                        createdAt = "2026-10-02T08:00:00Z"
                    ),
                    OwnerEntity(
                        id = "owner-3",
                        name = "Malik Tariq",
                        code = "MT03",
                        createdAt = "2026-10-03T08:00:00Z"
                    )
                )
                dao.insertOwners(owners)

                // 7. Initial Client Payments (मालिक-वार पेमेंट्स)
                val clientPayments = listOf(
                    ClientPaymentEntity(
                        id = "client-pay-1",
                        ownerId = "owner-1",
                        date = "2026-10-07",
                        amount = 30000.0,
                        notes = "First advance installment received for sanitary fitting.",
                        createdAt = "2026-10-07T10:30:00Z"
                    ),
                    ClientPaymentEntity(
                        id = "client-pay-2",
                        ownerId = "owner-1",
                        date = "2026-10-09",
                        amount = 20000.0,
                        notes = "Second progress installment paid on site.",
                        createdAt = "2026-10-09T16:00:00Z"
                    ),
                    ClientPaymentEntity(
                        id = "client-pay-3",
                        ownerId = "owner-2",
                        date = "2026-10-10",
                        amount = 45000.0,
                        notes = "Initial booking advance for project work.",
                        createdAt = "2026-10-10T12:00:00Z"
                    )
                )
                dao.insertClientPayments(clientPayments)

                // 8. Initial Project Contract
                dao.insertContract(
                    ProjectContractEntity(
                        projectName = "Green Valley Villa 42",
                        contractAmount = 200000.0
                    )
                )
            }
        }
    }
}
