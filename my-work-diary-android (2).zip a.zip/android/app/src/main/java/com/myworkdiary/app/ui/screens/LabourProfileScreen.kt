package com.myworkdiary.app.ui.screens

import androidx.compose.runtime.Composable
import com.myworkdiary.app.viewmodel.DiaryViewModel

@Composable
fun LabourProfileScreen(
    viewModel: DiaryViewModel,
    onBack: () -> Unit,
    onOpenWorkerLedger: (String) -> Unit
) {
    LabourProfilesScreen(
        viewModel = viewModel,
        onBack = onBack,
        onOpenWorkerLedger = onOpenWorkerLedger
    )
}
