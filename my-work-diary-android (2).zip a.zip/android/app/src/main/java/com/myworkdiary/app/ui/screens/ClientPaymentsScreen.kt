package com.myworkdiary.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.myworkdiary.app.data.local.entities.ClientPaymentEntity
import com.myworkdiary.app.data.local.entities.OwnerEntity
import com.myworkdiary.app.ui.theme.*
import com.myworkdiary.app.viewmodel.DiaryViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClientPaymentsScreen(
    viewModel: DiaryViewModel,
    onBack: () -> Unit
) {
    val allOwners by viewModel.allOwners.collectAsState()
    val allClientPayments by viewModel.allClientPayments.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedOwnerId by remember { mutableStateOf<String?>(null) }

    // Dialog states
    var showAddPaymentDialog by remember { mutableStateOf(false) }
    var prefilledOwnerCode by remember { mutableStateOf("") }

    var showAddOwnerDialog by remember { mutableStateOf(false) }

    var editingPayment by remember { mutableStateOf<ClientPaymentEntity?>(null) }
    var deletingPayment by remember { mutableStateOf<ClientPaymentEntity?>(null) }
    var deletingOwner by remember { mutableStateOf<OwnerEntity?>(null) }

    // 6. Home पर Client Received सभी मालिकों की कुल रकम दिखाए
    val totalReceivedAll = allClientPayments.sumOf { it.amount }

    // Selected owner details
    val selectedOwner = selectedOwnerId?.let { id -> allOwners.find { it.id == id } }
    val selectedOwnerPayments = remember(selectedOwnerId, allClientPayments) {
        if (selectedOwnerId == null) emptyList()
        else allClientPayments
            .filter { it.ownerId == selectedOwnerId }
            .sortedByDescending { it.date }
    }

    // Filtered owners by search query
    val filteredOwners = remember(searchQuery, allOwners, allClientPayments) {
        val q = searchQuery.trim().lowercase()
        if (q.isEmpty()) allOwners
        else allOwners.filter { o ->
            o.name.lowercase().contains(q) ||
                    o.code.lowercase().contains(q) ||
                    allClientPayments.any { cp -> cp.ownerId == o.id && cp.notes.lowercase().contains(q) }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = if (selectedOwner != null) selectedOwner.name else "💰 मालिक-वार पेमेंट",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp
                        )
                        Text(
                            text = if (selectedOwner != null) "कोड: ${selectedOwner.code} · पेमेंट्स लिस्ट" else "Owners & Client Payments",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = {
                        if (selectedOwnerId != null) {
                            selectedOwnerId = null
                        } else {
                            onBack()
                        }
                    }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        prefilledOwnerCode = selectedOwner?.code ?: ""
                        showAddPaymentDialog = true
                    }) {
                        Icon(Icons.Default.Add, contentDescription = "Add Payment")
                    }
                    IconButton(onClick = { showAddOwnerDialog = true }) {
                        Icon(Icons.Default.PersonAdd, contentDescription = "Add Owner")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = EmeraldDark,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    prefilledOwnerCode = selectedOwner?.code ?: ""
                    showAddPaymentDialog = true
                },
                containerColor = EmeraldGreen,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Payment")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(NotebookPaper)
                .padding(padding)
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // TOP SUMMARY CARD
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = EmeraldDark),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = Color.Black.copy(alpha = 0.35f),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = "मालिक-वार हिसाब",
                                    color = EmeraldLight,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                            Text(
                                text = "${allOwners.size} कुल मालिक",
                                color = Color.White.copy(alpha = 0.9f),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "कुल मिली रकम (All Owners)",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.85f),
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "Rs. ${totalReceivedAll.toInt()}",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "${allClientPayments.size} पेमेंट्स दर्ज हैं",
                            fontSize = 11.sp,
                            color = EmeraldLight
                        )

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = Color.White.copy(alpha = 0.15f))
                        Spacer(modifier = Modifier.height(10.dp))

                        // Quick buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    prefilledOwnerCode = selectedOwner?.code ?: ""
                                    showAddPaymentDialog = true
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = EmeraldLight,
                                    contentColor = PrimaryBrownDark
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("+ पेमेंट जोड़ें", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }

                            OutlinedButton(
                                onClick = { showAddOwnerDialog = true },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(Color.White.copy(alpha = 0.6f))),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("+ मालिक जोड़ें", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // IF AN OWNER IS SELECTED: SHOW OWNER DETAIL & DATE-WISE PAYMENTS (5. टैप करने पर उसकी सारी पेमेंट तारीख-वार)
            if (selectedOwner != null) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(
                            onClick = { selectedOwnerId = null },
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Icon(Icons.Default.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp), tint = EmeraldDark)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("सभी मालिकों की लिस्ट", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = EmeraldDark)
                        }

                        IconButton(
                            onClick = { deletingOwner = selectedOwner },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete Owner", tint = Color.Red.copy(alpha = 0.7f), modifier = Modifier.size(18.dp))
                        }
                    }
                }

                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Top
                            ) {
                                Column {
                                    Surface(
                                        color = EmeraldLight.copy(alpha = 0.3f),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = "कोड: ${selectedOwner.code}",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = EmeraldDark,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = selectedOwner.name,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TextDark
                                    )
                                    Text(
                                        text = "${selectedOwnerPayments.size} पेमेंट्स मिली हैं",
                                        fontSize = 11.sp,
                                        color = TextMuted
                                    )
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(text = "कुल प्राप्त", fontSize = 10.sp, color = TextMuted)
                                    Text(
                                        text = "Rs. ${selectedOwnerPayments.sumOf { it.amount }.toInt()}",
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = EmeraldGreen
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = {
                                    prefilledOwnerCode = selectedOwner.code
                                    showAddPaymentDialog = true
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("इस मालिक की पेमेंट जोड़ें (+ Payment)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                item {
                    Text(
                        text = "तारीख-वार पेमेंट्स (${selectedOwnerPayments.size})",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextMuted,
                        letterSpacing = 0.5.sp
                    )
                }

                if (selectedOwnerPayments.isEmpty()) {
                    item {
                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "इस मालिक की अभी कोई पेमेंट नहीं है।",
                                    fontSize = 12.sp,
                                    color = TextMuted
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Button(
                                    onClick = {
                                        prefilledOwnerCode = selectedOwner.code
                                        showAddPaymentDialog = true
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text("+ पहली पेमेंट जोड़ें", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                } else {
                    items(selectedOwnerPayments, key = { it.id }) { payment ->
                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            Icons.Default.CalendarToday,
                                            contentDescription = null,
                                            modifier = Modifier.size(14.dp),
                                            tint = TextMuted
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = payment.date,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = TextDark
                                        )
                                    }

                                    Text(
                                        text = "Rs. ${payment.amount.toInt()}",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = EmeraldGreen
                                    )
                                }

                                if (payment.notes.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "\"${payment.notes}\"",
                                        fontSize = 12.sp,
                                        color = TextMuted
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))
                                HorizontalDivider(color = Color(0xFFF1EFEA))
                                Spacer(modifier = Modifier.height(6.dp))

                                // 5. पेमेंट बदलने और delete करने का option
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    TextButton(
                                        onClick = { editingPayment = payment },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp), tint = PrimaryBrown)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("बदलें (Edit)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = PrimaryBrown)
                                    }

                                    Spacer(modifier = Modifier.width(8.dp))

                                    TextButton(
                                        onClick = { deletingPayment = payment },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.Red)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("हटाएं (Delete)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Red)
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                // ALL OWNERS LIST VIEW (5. "Owners" लिस्ट: हर मालिक का नाम, कोड और कुल मिली रकम)
                item {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("मालिक का नाम, कोड या नोट से खोजें...", fontSize = 12.sp) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear", modifier = Modifier.size(16.dp))
                                }
                            }
                        },
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White,
                            focusedBorderColor = EmeraldGreen,
                            unfocusedBorderColor = Color(0xFFDDD6C9)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "मालिकों की लिस्ट (${filteredOwners.size})",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextMuted,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = "पेमेंट देखने के लिए टैप करें",
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }
                }

                if (filteredOwners.isEmpty()) {
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(28.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(CircleShape)
                                        .background(EmeraldLight.copy(alpha = 0.3f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Person, contentDescription = null, tint = EmeraldDark)
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "कोई मालिक नहीं मिला",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextDark
                                )
                                Text(
                                    text = "नया मालिक जोड़ें और उसका कोड बनाएं।",
                                    fontSize = 11.sp,
                                    color = TextMuted
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Button(
                                    onClick = { showAddOwnerDialog = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text("+ नया मालिक जोड़ें", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                } else {
                    items(filteredOwners, key = { it.id }) { owner ->
                        val ownerPayments = allClientPayments.filter { it.ownerId == owner.id }
                        val ownerTotalReceived = ownerPayments.sumOf { it.amount }

                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedOwnerId = owner.id }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(EmeraldLight.copy(alpha = 0.35f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = owner.name.take(1).uppercase(),
                                            fontSize = 18.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = EmeraldDark
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = owner.name,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = TextDark
                                        )
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Surface(
                                                color = Color(0xFFF1EFEA),
                                                shape = RoundedCornerShape(4.dp)
                                            ) {
                                                Text(
                                                    text = "कोड: ${owner.code}",
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = TextDark,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "${ownerPayments.size} पेमेंट्स",
                                                fontSize = 11.sp,
                                                color = TextMuted
                                            )
                                        }
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "कुल मिली रकम",
                                        fontSize = 10.sp,
                                        color = TextMuted
                                    )
                                    Text(
                                        text = "Rs. ${ownerTotalReceived.toInt()}",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = EmeraldGreen
                                    )
                                    Icon(
                                        Icons.Default.ChevronRight,
                                        contentDescription = "Open",
                                        tint = TextMuted,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // 3. "Add Payment" स्क्रीन / Dialog
    if (showAddPaymentDialog) {
        AddPaymentDialog(
            viewModel = viewModel,
            prefilledCode = prefilledOwnerCode,
            onDismiss = {
                showAddPaymentDialog = false
                prefilledOwnerCode = ""
            },
            onSave = { payment ->
                viewModel.saveClientPayment(payment)
                showAddPaymentDialog = false
                prefilledOwnerCode = ""
            },
            onOpenAddOwner = {
                showAddPaymentDialog = false
                showAddOwnerDialog = true
            }
        )
    }

    // 4. "Add Owner" स्क्रीन / Dialog
    if (showAddOwnerDialog) {
        AddOwnerDialog(
            viewModel = viewModel,
            onDismiss = { showAddOwnerDialog = false },
            onSave = { owner ->
                viewModel.saveOwner(owner)
                showAddOwnerDialog = false
            }
        )
    }

    // Edit Payment Dialog
    if (editingPayment != null) {
        val payment = editingPayment!!
        val owner = allOwners.find { it.id == payment.ownerId }
        EditPaymentDialog(
            payment = payment,
            ownerName = owner?.name ?: "मालिक",
            ownerCode = owner?.code ?: "",
            onDismiss = { editingPayment = null },
            onSave = { updated ->
                viewModel.saveClientPayment(updated)
                editingPayment = null
            }
        )
    }

    // Delete Payment Confirmation Dialog
    if (deletingPayment != null) {
        val payment = deletingPayment!!
        AlertDialog(
            onDismissRequest = { deletingPayment = null },
            title = { Text("पेमेंट हटाएं?", fontWeight = FontWeight.Bold) },
            text = {
                Text("क्या आप ${payment.date} की Rs. ${payment.amount.toInt()} की यह पेमेंट हटाना चाहते हैं?")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteClientPayment(payment.id)
                        deletingPayment = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                ) {
                    Text("हटाएं (Delete)")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { deletingPayment = null }) {
                    Text("रद्द करें")
                }
            }
        )
    }

    // Delete Owner Confirmation Dialog
    if (deletingOwner != null) {
        val owner = deletingOwner!!
        AlertDialog(
            onDismissRequest = { deletingOwner = null },
            title = { Text("मालिक हटाएं?", fontWeight = FontWeight.Bold) },
            text = {
                Text("क्या आप \"${owner.name}\" (कोड: ${owner.code}) को हटाना चाहते हैं?")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteOwner(owner.id)
                        deletingOwner = null
                        selectedOwnerId = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                ) {
                    Text("मालिक हटाएं")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { deletingOwner = null }) {
                    Text("रद्द करें")
                }
            }
        )
    }
}

/**
 * 3. "Add Payment" स्क्रीन: ऊपर कोड लिखने का box, नीचे रकम, तारीख (आज की डिफ़ॉल्ट) और नोट।
 * कोड लिखते ही मालिक का नाम दिखे। कोड सही हो तो सेव पर पेमेंट उसी मालिक में जुड़े।
 * कोड न मिले तो "यह कोड नहीं मिला" लिखो और सेव मत होने दो।
 */
@Composable
fun AddPaymentDialog(
    viewModel: DiaryViewModel,
    prefilledCode: String,
    onDismiss: () -> Unit,
    onSave: (ClientPaymentEntity) -> Unit,
    onOpenAddOwner: () -> Unit
) {
    val today = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }

    var code by remember { mutableStateOf(prefilledCode) }
    var amountText by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(today) }
    var notes by remember { mutableStateOf("") }

    // Live owner lookup by code (case-insensitive)
    val matchedOwner = remember(code) {
        viewModel.findOwnerByCode(code)
    }

    val isCodeEntered = code.trim().isNotEmpty()
    val isCodeNotFound = isCodeEntered && matchedOwner == null
    val isAmountValid = (amountText.toDoubleOrNull() ?: 0.0) > 0.0

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Add Payment (पेमेंट जोड़ें)", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                TextButton(onClick = onOpenAddOwner, contentPadding = PaddingValues(0.dp)) {
                    Text("+ नया मालिक", fontSize = 11.sp, color = EmeraldDark, fontWeight = FontWeight.Bold)
                }
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // 1. TOP: CODE WORD INPUT BOX
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("मालिक का कोड वर्ड (Owner Code) *", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = code,
                        onValueChange = { code = it.uppercase() },
                        placeholder = { Text("उदा. HB01, CA02") },
                        isError = isCodeNotFound,
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Live owner display or error message
                    if (matchedOwner != null) {
                        Surface(
                            color = Color(0xFFE8F5E9),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldGreen, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "मालिक: ${matchedOwner.name} (पहचान हो गई)",
                                    color = EmeraldDark,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    } else if (isCodeNotFound) {
                        Text(
                            text = "यह कोड नहीं मिला",
                            color = Color.Red,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // 2. AMOUNT INPUT (रकम)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("रकम (Amount in Rs.) *", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = amountText,
                        onValueChange = { amountText = it },
                        placeholder = { Text("उदा. 30000") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // 3. DATE INPUT (तारीख - आज की डिफ़ॉल्ट)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("तारीख (Date) *", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = date,
                        onValueChange = { date = it },
                        placeholder = { Text("YYYY-MM-DD") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // 4. NOTE INPUT (छोटा नोट)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("छोटा नोट (Short Note)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        placeholder = { Text("उदा. एडवांस किश्त, नल फिटिंग के लिए") },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            // Save allowed ONLY if code is found and amount is valid
            Button(
                onClick = {
                    if (matchedOwner != null && isAmountValid) {
                        val payment = ClientPaymentEntity(
                            id = "client-pay-${UUID.randomUUID()}",
                            ownerId = matchedOwner.id,
                            date = date.trim().ifEmpty { today },
                            amount = amountText.toDoubleOrNull() ?: 0.0,
                            notes = notes.trim(),
                            createdAt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).format(Date())
                        )
                        onSave(payment)
                    }
                },
                enabled = matchedOwner != null && isAmountValid,
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("पेमेंट सेव करें (Save)")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss, shape = RoundedCornerShape(10.dp)) {
                Text("रद्द करें")
            }
        }
    )
}

/**
 * 4. "Add Owner" स्क्रीन: नाम और कोड वर्ड। वही कोड दोबारा न बनने दो।
 */
@Composable
fun AddOwnerDialog(
    viewModel: DiaryViewModel,
    onDismiss: () -> Unit,
    onSave: (OwnerEntity) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }

    val cleanCode = code.trim().uppercase()
    val isCodeDuplicate = remember(cleanCode) {
        viewModel.isOwnerCodeDuplicate(cleanCode)
    }

    val isValid = name.trim().isNotBlank() && cleanCode.isNotBlank() && !isCodeDuplicate

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Owner (मालिक जोड़ें)", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("मालिक का नाम (Owner Name) *", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        placeholder = { Text("उदा. Haji Bashir, Chaudhry Akram") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("कोड वर्ड (Unique Code) *", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = code,
                        onValueChange = { code = it.uppercase() },
                        placeholder = { Text("उदा. HB01, CA02") },
                        isError = isCodeDuplicate,
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (isCodeDuplicate) {
                        Text(
                            text = "यह कोड पहले से मौजूद है! कृपया अलग कोड चुनें।",
                            color = Color.Red,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    } else {
                        Text(
                            text = "बड़े-छोटे अक्षर का फ़र्क़ नहीं होगा।",
                            color = TextMuted,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (isValid) {
                        val owner = OwnerEntity(
                            id = "owner-${UUID.randomUUID()}",
                            name = name.trim(),
                            code = cleanCode,
                            createdAt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).format(Date())
                        )
                        onSave(owner)
                    }
                },
                enabled = isValid,
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("मालिक सेव करें")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss, shape = RoundedCornerShape(10.dp)) {
                Text("रद्द करें")
            }
        }
    )
}

/**
 * Edit Payment Dialog (5. पेमेंट बदलने का option)
 */
@Composable
fun EditPaymentDialog(
    payment: ClientPaymentEntity,
    ownerName: String,
    ownerCode: String,
    onDismiss: () -> Unit,
    onSave: (ClientPaymentEntity) -> Unit
) {
    var amountText by remember { mutableStateOf(payment.amount.toString()) }
    var date by remember { mutableStateOf(payment.date) }
    var notes by remember { mutableStateOf(payment.notes) }

    val isAmountValid = (amountText.toDoubleOrNull() ?: 0.0) > 0.0

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("पेमेंट बदलें (Edit Payment)", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    color = Color(0xFFF1EFEA),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text("मालिक: $ownerName", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("कोड: $ownerCode", fontSize = 11.sp, color = TextMuted)
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("रकम (Amount in Rs.) *", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = amountText,
                        onValueChange = { amountText = it },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("तारीख (Date) *", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = date,
                        onValueChange = { date = it },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("छोटा नोट (Short Note)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (isAmountValid) {
                        onSave(
                            payment.copy(
                                date = date.trim(),
                                amount = amountText.toDoubleOrNull() ?: payment.amount,
                                notes = notes.trim()
                            )
                        )
                    }
                },
                enabled = isAmountValid,
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("बदलाव सेव करें")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss, shape = RoundedCornerShape(10.dp)) {
                Text("रद्द करें")
            }
        }
    )
}
