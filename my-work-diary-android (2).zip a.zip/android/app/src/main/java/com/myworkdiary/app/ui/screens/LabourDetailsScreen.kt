package com.myworkdiary.app.ui.screens

import androidx.compose.runtime.Composable
import com.myworkdiary.app.viewmodel.DiaryViewModel

@Composable
fun LabourDetailsScreen(
    viewModel: DiaryViewModel,
    workerName: String,
    onBack: () -> Unit
) {
    LabourDetailScreen(
        viewModel = viewModel,
        workerName = workerName,
        onBack = onBack
    )
}
